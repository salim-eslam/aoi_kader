<!DOCTYPE html>
<?php if(app()->getLocale() == 'ar'): ?>
<html dir="rtl" lang="ar">
<?php else: ?>
<html lang="en">
<?php endif; ?>
<?php echo $__env->make('front.layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>
<?php echo $__env->make('front.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>    
<?php echo $__env->make('front.layouts.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>    
    <!--/ End Header -->
    <?php echo $__env->yieldContent('main-content'); ?>
    <?php echo $__env->make('front.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH /home/alsaifcoksa/public_html/onlinestore.alsaifco-ksa.com/resources/views/front/layouts/master.blade.php ENDPATH**/ ?>