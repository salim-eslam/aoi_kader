 <!-- NAVIGATION -->
 <nav id="navigation"
        style="box-shadow: 0 3px 1px -2px rgba(0,0,0,.2), 0 2px 2px 0 rgba(0,0,0,.14), 0 1px 5px 0 rgba(0,0,0,.12);">
        <!-- container -->
        <div class="container">
            <!-- responsive-nav -->
            <div id="responsive-nav">
                <!-- NAV -->
                <?php
                            $categories = DB::table('categories')
                                ->where('status', 'active')
                                ->orderBy('created_at')
                                ->get();
                        ?> 
                        <?php if(app()->getLocale() == 'ar'): ?>
                        <ul class="main-nav nav navbar-nav">
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php 
                                $childCategories = \App\Models\Category::getChildByParentIDAr($category->id);                   
                            ?>                  
                            <?php if(count($childCategories) > 0 && $category->parent_id == null): ?>                    
                                <li class="dropdown dd-main"><a href="#" class="dropdown-toggle" data-toggle="dropdown"><?php echo e($category->title_ar); ?></a>
                            <ul class="dropdown-menu dropdown-menu-custom">
                                <?php $__currentLoopData = $childCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $childCat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php                        
                                $child_child_categories = \App\Models\Category::getChildByParentIDAr($key);
                                ?>
                                <?php if(count($child_child_categories) > 0): ?>
                                <li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown"><?php echo e($childCat); ?></a>
                                <ul class="dropdown-menu dropdown-menu-custom-sub">
                                <?php $__currentLoopData = $child_child_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $child_child_cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(route('product-grids',$key)); ?>"><?php echo e($child_child_cat); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>		
                            </ul>
                            </li>	
                                <?php else: ?>
                                
                                <li><a href="<?php echo e(route('product-grids',$key)); ?>"><?php echo e($childCat); ?></a></li>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                            </li>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                   
                        </ul>
                        <?php else: ?>                        
                        <ul class="main-nav nav navbar-nav">
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php 
                                $childCategories = \App\Models\Category::getChildByParentID($category->id);                   
                            ?>                  
                            <?php if(count($childCategories) > 0 && $category->parent_id == null): ?>                    
                                <li class="dropdown dd-main"><a href="#" class="dropdown-toggle" data-toggle="dropdown"><?php echo e($category->title); ?></a>
                            <ul class="dropdown-menu dropdown-menu-custom">
                                <?php $__currentLoopData = $childCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $childCat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php                        
                                $child_child_categories = \App\Models\Category::getChildByParentID($key);
                                ?>
                                <?php if(count($child_child_categories) > 0): ?>
                                <li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown"><?php echo e($childCat); ?></a>
                                <ul class="dropdown-menu dropdown-menu-custom-sub">
                                <?php $__currentLoopData = $child_child_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $child_child_cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(route('product-grids',$key)); ?>"><?php echo e($child_child_cat); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>		
                            </ul>
                            </li>	
                                <?php else: ?>
                                
                                <li><a href="<?php echo e(route('product-grids',$key)); ?>"><?php echo e($childCat); ?></a></li>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                            </li>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                   
                        </ul>
                        <?php endif; ?>
                <!-- /NAV -->
            </div>
            <!-- /responsive-nav -->
        </div>
        <!-- /container -->
    </nav>
    <!-- /NAVIGATION --><?php /**PATH /home/alsaifcoksa/public_html/onlinestore.alsaifco-ksa.com/resources/views/front/layouts/navigation.blade.php ENDPATH**/ ?>