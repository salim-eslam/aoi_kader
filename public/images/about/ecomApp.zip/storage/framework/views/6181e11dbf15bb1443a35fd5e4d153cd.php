<header class="header shop">
    <!-- Topbar -->
    <div class="topbar">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-12 col-12">
                    <!-- Top Left -->
                    <div class="top-left">
                        <ul class="list-main">
                            <?php
                                $settings = DB::table('settings')->get();

                            ?>

                            <li><i class="ti-headphone-alt"></i>
                                <?php $__currentLoopData = $settings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a href="tel:<?php echo e($data->phone); ?>"><?php echo e($data->phone); ?></a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </li>

                            <li><i class="ti-email"></i>
                                <?php $__currentLoopData = $settings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a href="mailto:<?php echo e($data->email); ?>">&nbsp;<?php echo e($data->email); ?>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> </a>
                            </li>

                        </ul>
                    </div>
                    <!--/ End Top Left -->
                </div>
                <div class="col-lg-6 col-md-12 col-12">
                    <!-- Top Right -->
                    <div class="right-content">
                        <ul class="list-main">
                            <li><i class="ti-location-pin"></i> <a href="<?php echo e(route('order.track')); ?>"> تتبع طلبك </a>
                            </li>
                            
                            <?php if(auth()->guard()->check()): ?>
                                <?php if(Auth::user()->role == 'admin'): ?>
                                    <li><i class="ti-user"></i> <a href="<?php echo e(route('admin')); ?>" target="_blank"> المنصة </a>
                                    </li>
                                <?php else: ?>
                                    <li><i class="ti-user"></i> <a href="<?php echo e(route('user')); ?>" target="_blank"> المنصة </a>
                                    </li>
                                <?php endif; ?>
                                <li><i class="ti-power-off"></i> <a href="<?php echo e(route('user.logout')); ?>"> تسجيل خروج </a></li>
                            <?php else: ?>
                                <li><i class="ti-power-off"></i><a href="<?php echo e(route('login.form')); ?>"> تسجيل الدخول /</a> <a
                                        href="<?php echo e(route('register.form')); ?>"> انشاء حساب </a></li>
                            <?php endif; ?>
                        </ul>
                    </div>
                    <!-- End Top Right -->
                </div>
            </div>
        </div>
    </div>
    <!-- End Topbar -->

    <!-- Header Inner -->
    
    <!--/ End Header Inner -->



    <div class="middle-inner">
        <div class="container">
            <div class="row">
                <div class="col-lg-2 col-md-2 col-12">
                    <!-- Logo -->
                    <div class="logo">
                        <?php
                            $settings = DB::table('settings')->get();
                        ?>
                        <a href="<?php echo e(route('home')); ?>"><img
                                src="https://alsaifco-ksa.com/Dashboard/assets/Front/assets/img/alsaif.png"
                                alt="logo" width="70" height="55"></a>
                    </div>
                    <!--/ End Logo -->
                    <!-- Search Form -->
                    <div class="search-top">
                        <div class="top-search"><a href="#0"><i class="ti-search"></i></a></div>
                        <!-- Search Form -->
                        <div class="search-top">
                            <form class="search-form">
                                <input type="text" placeholder="Search here..." name="search">
                                <button value="search" type="submit"><i class="ti-search"></i></button>
                            </form>
                        </div>
                        <!--/ End Search Form -->
                    </div>
                    <!--/ End Search Form -->
                    <div class="mobile-nav"></div>
                </div>
                <div class="col-lg-8 col-md-7 col-12">
                    <div class="search-bar-top">
                        <div class="search-bar">
                            <select>
                                <option> الاقسام </option>
                                <?php $__currentLoopData = Helper::getAllCategory(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option><?php echo e($cat->title); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <form method="GET" action="<?php echo e(route('product.search')); ?>">
                                <?php echo csrf_field(); ?>
                                <input name="search" placeholder=" ابحث عن منتجك..... " type="search">
                                <button class="btnn" type="submit"><i class="ti-search"></i></button>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="col-lg-2 col-md-3 col-12">
                    <div class="right-bar">
                        <!-- Search Form -->
                        <div class="sinlge-bar shopping">
                            <?php
                                $total_prod = 0;
                                $total_amount = 0;
                            ?>
                            <?php if(session('wishlist')): ?>
                                <?php $__currentLoopData = session('wishlist'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wishlist_items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $total_prod += $wishlist_items['quantity'];
                                        $total_amount += $wishlist_items['amount'];
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            <a href="<?php echo e(route('wishlist')); ?>" class="single-icon"><svg
                                    xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="currentColor"
                                    class="bi bi-heart" viewBox="0 0 16 16">
                                    <path
                                        d="m8 2.748-.717-.737C5.6.281 2.514.878 1.4 3.053c-.523 1.023-.641 2.5.314 4.385.92 1.815 2.834 3.989 6.286 6.357 3.452-2.368 5.365-4.542 6.286-6.357.955-1.886.838-3.362.314-4.385C13.486.878 10.4.28 8.717 2.01zM8 15C-7.333 4.868 3.279-3.04 7.824 1.143c.06.055.119.112.176.171a3.12 3.12 0 0 1 .176-.17C12.72-3.042 23.333 4.867 8 15" />
                                </svg>
                                <span class="total-count"><?php echo e(Helper::wishlistCount()); ?></span></a>
                            <!-- Shopping Item -->
                            <?php if(auth()->guard()->check()): ?>
                                <div class="shopping-item">
                                    <div class="dropdown-cart-header">
                                        <span><?php echo e(count(Helper::getAllProductFromWishlist())); ?> Items</span>
                                        <a href="<?php echo e(route('wishlist')); ?>">View Wishlist</a>
                                    </div>
                                    <ul class="shopping-list">
                                        
                                        <?php $__currentLoopData = Helper::getAllProductFromWishlist(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                                $photo = explode(',', $data->product['photo']);
                                            ?>
                                            <li>
                                                <a href="<?php echo e(route('wishlist-delete', $data->id)); ?>" class="remove"
                                                    title="Remove this item"><i class="fa fa-remove"></i></a>
                                                <a class="cart-img" href="#"><img src="<?php echo e($photo[0]); ?>"></a>
                                                <h4><a href="<?php echo e(route('product-detail', $data->product['slug'])); ?>"
                                                        target="_blank"><?php echo e($data->product['title']); ?></a></h4>
                                                <p class="quantity"><?php echo e($data->quantity); ?> x - <span
                                                        class="amount">$<?php echo e(number_format($data->price, 2)); ?></span></p>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                    <div class="bottom">
                                        <div class="total">
                                            <span>Total</span>
                                            <span
                                                class="total-amount">$<?php echo e(number_format(Helper::totalWishlistPrice(), 2)); ?></span>
                                        </div>
                                        <a href="<?php echo e(route('cart')); ?>" class="btn animate">Cart</a>
                                    </div>
                                </div>
                            <?php endif; ?>
                            <!--/ End Shopping Item -->
                        </div>
                        
                        <div class="sinlge-bar shopping">
                            <a href="<?php echo e(route('cart')); ?>" class="single-icon"><svg xmlns="http://www.w3.org/2000/svg"
                                    width="30" height="30" fill="currentColor" class="bi bi-cart"
                                    viewBox="0 0 16 16">
                                    <path
                                        d="M0 1.5A.5.5 0 0 1 .5 1H2a.5.5 0 0 1 .485.379L2.89 3H14.5a.5.5 0 0 1 .491.592l-1.5 8A.5.5 0 0 1 13 12H4a.5.5 0 0 1-.491-.408L2.01 3.607 1.61 2H.5a.5.5 0 0 1-.5-.5M3.102 4l1.313 7h8.17l1.313-7H3.102zM5 12a2 2 0 1 0 0 4 2 2 0 0 0 0-4m7 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4m-7 1a1 1 0 1 1 0 2 1 1 0 0 1 0-2m7 0a1 1 0 1 1 0 2 1 1 0 0 1 0-2" />
                                </svg>
                                <span class="total-count"><?php echo e(Helper::cartCount()); ?></span></a>
                            <!-- Shopping Item -->
                            <?php if(auth()->guard()->check()): ?>
                                <div class="shopping-item">
                                    <div class="dropdown-cart-header">
                                        <span><?php echo e(count(Helper::getAllProductFromCart())); ?> Items</span>
                                        <a href="<?php echo e(route('cart')); ?>">View Cart</a>
                                    </div>
                                    <ul class="shopping-list">
                                        
                                        <?php $__currentLoopData = Helper::getAllProductFromCart(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                                $photo = explode(',', $data->product['photo']);
                                            ?>
                                            <li>
                                                <a href="<?php echo e(route('cart-delete', $data->id)); ?>" class="remove"
                                                    title="Remove this item"><i class="fa fa-remove"></i></a>
                                                <a class="cart-img" href="#"><img src="<?php echo e($photo[0]); ?>"
                                                        alt="<?php echo e($photo[0]); ?>"></a>
                                                <h4><a href="<?php echo e(route('product-detail', $data->product['slug'])); ?>"
                                                        target="_blank"><?php echo e($data->product['title']); ?></a></h4>
                                                <p class="quantity"><?php echo e($data->quantity); ?> x - <span
                                                        class="amount">$<?php echo e(number_format($data->price, 2)); ?></span></p>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                    <div class="bottom">
                                        <div class="total">
                                            <span>Total</span>
                                            <span
                                                class="total-amount">$<?php echo e(number_format(Helper::totalCartPrice(), 2)); ?></span>
                                        </div>
                                        <a href="<?php echo e(route('checkout')); ?>" class="btn animate">Checkout</a>
                                    </div>
                                </div>
                            <?php endif; ?>
                            <!--/ End Shopping Item -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-12">
            <div class="product-info">
                <div class="nav-main" style="text-align: center;">
                    <!-- Tab Nav -->
                    <ul class="nav nav-tabs filter-tope-group" style="display: inline-block; padding: 0;"
                        id="myTab" role="tablist">
                        <?php
                            $categories = DB::table('categories')
                                ->where('status', 'active')
                                ->orderBy('created_at')
                                ->get();
                        ?>
                        <?php if($categories): ?>
                            <button class="btn" style="background:black" data-filter="*">
                                جميع المنتجات
                            </button>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <button class="btn" style="background:none;color:black;"
                                    data-filter=".<?php echo e($cat->id); ?>">
                                    <?php echo e($cat->title); ?>

                                </button>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </ul>
                    <!--/ End Tab Nav -->
                </div>
                <div class="tab-content isotope-grid" id="myTabContent">
                    <!-- Start Single Tab -->
                    <?php if($product_lists): ?>
                        <?php $__currentLoopData = $product_lists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-sm-6 col-md-4 col-lg-3 p-b-35 isotope-item <?php echo e($product->cat_id); ?>">
                                <div class="single-product">
                                    <div class="product-img">
                                        <a href="<?php echo e(route('product-detail', $product->slug)); ?>">
                                            <?php
                                                $photo = explode(',', $product->photo);
                                            ?>
                                            <img class="default-img" src="<?php echo e(asset($photo[0])); ?>"
                                                alt="<?php echo e(asset($photo[0])); ?>">
                                            <img class="hover-img" src="<?php echo e(asset($photo[0])); ?>"
                                                alt="<?php echo e(asset($photo[0])); ?>">
                                            <?php if($product->stock <= 0): ?>
                                                <span class="out-of-stock">Sale out</span>
                                            <?php elseif($product->condition == 'new'): ?>
                                            <span class="new">New</span <?php elseif($product->condition == 'hot'): ?>
                                                    <span class="hot">Hot</span>
                                            <?php else: ?>
                                                <!-- <span class="price-dec"><?php echo e($product->discount); ?>% Off</span> -->
                                            <?php endif; ?>


                                        </a>
                                        <div class="button-head">
                                            <div class="product-action">
                                                <a data-toggle="modal" data-target="#<?php echo e($product->id); ?>"
                                                    title="Quick View" href="#"><i
                                                        class=" ti-eye"></i><span>Quick
                                                        Shop</span></a>
                                                <a title="Wishlist"
                                                    href="<?php echo e(route('add-to-wishlist', $product->slug)); ?>"><i
                                                        class=" ti-heart "></i><span>Add to Wishlist</span></a>
                                            </div>
                                            <div class="product-action-2">
                                                <a title="Add to cart"
                                                    href="<?php echo e(route('add-to-cart', $product->slug)); ?>">Add to
                                                    cart</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="product-content">
                                        <h3><a
                                                href="<?php echo e(route('product-detail', $product->slug)); ?>"><?php echo e($product->title); ?></a>
                                        </h3>
                                        <div class="product-price">
                                            <?php
                                                $after_discount = $product->price - ($product->price * $product->discount) / 100;
                                            ?>
                                            <span> <?php echo e(number_format($after_discount, 2)); ?> </span>
                                            <!-- <del style="padding-left:4%;">$<?php echo e(number_format($product->price, 2)); ?></del> -->
                                        </div>sr
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <!--/ End Single Tab -->
                    <?php endif; ?>

                    <!--/ End Single Tab -->

                </div>
            </div>
        </div>
    </div>


    <script></script>
</header>
<?php /**PATH /home/alsaifcoksa/public_html/onlinestore.alsaifco-ksa.com/resources/views/frontend/layouts/header.blade.php ENDPATH**/ ?>