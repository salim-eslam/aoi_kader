<?php $__env->startSection('main-content'); ?>

<div class="card">
    <h5 class="card-header">Add Product</h5>
    <div class="card-body">
      <form method="post" action="<?php echo e(route('product.store')); ?>" enctype="multipart/form-data" >
        <?php echo e(csrf_field()); ?>

        <div class="form-group">
          <label for="inputTitle" class="col-form-label">Title <span class="text-danger">*</span></label>
          <input id="inputTitle" type="text" name="title" placeholder="Enter title"  value="<?php echo e(old('title')); ?>" class="form-control">
          <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <span class="text-danger"><?php echo e($message); ?></span>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group">
          <label for="inputTitle" class="col-form-label">Arabic Title <span class="text-danger">*</span></label>
          <input id="inputTitle" type="text" name="title_ar" placeholder="Enter title"  value="<?php echo e(old('title_ar')); ?>" class="form-control">
          <?php $__errorArgs = ['title_ar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <span class="text-danger"><?php echo e($message); ?></span>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-group">
          <label for="summary" class="col-form-label">Summary <span class="text-danger">*</span></label>
          <textarea class="form-control" id="summary" name="summary"><?php echo e(old('summary')); ?></textarea>
          <?php $__errorArgs = ['summary'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <span class="text-danger"><?php echo e($message); ?></span>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group">
          <label for="summary" class="col-form-label">Arabic Summary <span class="text-danger">*</span></label>
          <textarea class="form-control" id="summary_ar" name="summary_ar"><?php echo e(old('summary_ar')); ?></textarea>
          <?php $__errorArgs = ['summary_ar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <span class="text-danger"><?php echo e($message); ?></span>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group">
          <label for="brand_id">Product Brand</label>
          <select name="brand_id" id="brand_id" class="form-control">
              <option value="">--Select brand --</option>
              <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value='<?php echo e($brand->id); ?>'><?php echo e($brand->title); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
          </select>
        </div>

      
              

        <div class="form-group">
          <label for="cat_id">Category <span class="text-danger">*</span></label>
          <select name="cat_id" id="cat_id" class="form-control">
              <option value="">--Select any category--</option>
              <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$cat_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php $hasChildren = \App\Models\Category::getAllParentWithChild(); ?>
              <?php if($cat_data->parent_id == null): ?>
                  <option value='<?php echo e($cat_data->id); ?>'><?php echo e($cat_data->title); ?></option>
              <?php endif; ?>      
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>

        <div class="form-group d-none" id="child_cat_div">
          <label for="child_cat_id">Sub Category</label>
          <select name="child_cat_id" id="child_cat_id" class="form-control">
              <option value="">--Select any category--</option>
              
          </select>
        </div>
          <div class="form-group d-none" id="child_child_cat_div">
          <label for="child_child_cat_id">Sub Sub Category</label>
          <select name="child_child_cat_id" id="child_child_cat_id" class="form-control">
              <option value="">--Select Sub Sub category--</option>
              
          </select>
        </div>
         <div class="form-group d-none" id="display_types_div">
          <label for="display_type_id">Display Types</label>
          <select name="display_type_id" id="display_type_id" class="form-control">
              <option value="">--Select any type--</option>
              <?php $__currentLoopData = $displayTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $displayType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value='<?php echo e($displayType->id); ?>'><?php echo e($displayType->title); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>
        <div class="form-group d-none" id="conn_tech_div">
          <label for="conn_tech_id">Connectivity Technologies</label>
          <select name="conn_tech_id" id="conn_tech_id" class="form-control">
              <option value="">--Select any technology--</option>
              <?php $__currentLoopData = $connectivityTechnologies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $connectivityTechnology): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value='<?php echo e($connectivityTechnology->id); ?>'><?php echo e($connectivityTechnology->title); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
          </select>
        </div>
        <div class="form-group d-none" id="native_resolution_div">
          <label for="native_resolution_id">Native Resolutions</label>
          <select name="native_resolution_id" id="native_resolution_id" class="form-control">
              <option value="">--Select any --</option>
               <?php $__currentLoopData = $nativeResolutions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nativeResolution): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value='<?php echo e($nativeResolution->id); ?>'><?php echo e($nativeResolution->title); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
          </select>
        </div>
        <div class="form-group d-none" id="inc_comp_div">
          <label for="inc_comp_id">Include Components</label>
          <select name="inc_comp_id" id="inc_comp_id" class="form-control">
              <option value="">--Select any --</option>
               <?php $__currentLoopData = $includeComponents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $includeComponent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value='<?php echo e($includeComponent->id); ?>'><?php echo e($includeComponent->title); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
          </select>
        </div>
        <div class="form-group d-none" id="display_res_div">
          <label for="display_res_id ">Display Resolutions</label>
          <select name="display_res_id " id="display_res_id " class="form-control">
              <option value="">--Select any --</option>
               <?php $__currentLoopData = $displayResolutions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $displayResolution): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value='<?php echo e($displayResolution->id); ?>'><?php echo e($displayResolution->title); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
          </select>
        </div>
        <div class="form-group d-none" id="screen_size_div">
          <label for="screen_size_id">Screen Sizes</label>
          <select name="screen_size_id" id="screen_size_id" class="form-control">
              <option value="">--Select any --</option>
               <?php $__currentLoopData = $screenSizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $screenSize): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value='<?php echo e($screenSize->id); ?>'><?php echo e($screenSize->title); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
          </select>
        </div>
        <div class="form-group d-none" id="monitor_feature_div">
          <label for="monitor_feature_id">Monitor Features</label>
          <select name="monitor_feature_id" id="monitor_feature_id" class="form-control">
              <option value="">--Select any --</option>
               <?php $__currentLoopData = $monitorFeatures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $monitorFeature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value='<?php echo e($monitorFeature->id); ?>'><?php echo e($monitorFeature->title); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
          </select>
        </div>

        
        <div class="form-group d-none" id="product_length_div">
          <label for="product_length_id">Product Length</label>
          <select name="product_length_id" id="product_length_id" class="form-control">
              <option value="">--Select any --</option>
               <?php $__currentLoopData = $productLengths; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productLength): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value='<?php echo e($productLength->id); ?>'><?php echo e($productLength->title); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
          </select>
        </div>
        <div class="form-group d-none" id="os_div">
          <label for="os_id">Operating System</label>
          <select name="os_id" id="os_id" class="form-control">
              <option value="">--Select any --</option>
               <?php $__currentLoopData = $operatingSystems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operatingSystem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value='<?php echo e($operatingSystem->id); ?>'><?php echo e($operatingSystem->title); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
          </select>
        </div>
        <div class="form-group d-none" id="cpu_type_div">
          <label for="cpu_type_id">CPU Type</label>
          <select name="cpu_type_id" id="cpu_type_id" class="form-control">
              <option value="">--Select any --</option>
               <?php $__currentLoopData = $cpuTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cpuType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value='<?php echo e($cpuType->id); ?>'><?php echo e($cpuType->title); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
          </select>
        </div>
        <div class="form-group d-none" id="hard_type_div">
          <label for="hard_type_id">Hard Drive Type</label>
          <select name="hard_type_id" id="hard_type_id" class="form-control">
              <option value="">--Select any --</option>
               <?php $__currentLoopData = $hardTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hardType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value='<?php echo e($hardType->id); ?>'><?php echo e($hardType->title); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
          </select>
        </div>
        <div class="form-group d-none" id="graphics_corprocessor_div">
          <label for="graphics_corprocessor_id">Graphics Coprocessor</label>
          <select name="graphics_corprocessor_id" id="graphics_corprocessor_id" class="form-control">
              <option value="">--Select any --</option>
               <?php $__currentLoopData = $graphicsCoprocessors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $graphicsCoprocessor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value='<?php echo e($graphicsCoprocessor->id); ?>'><?php echo e($graphicsCoprocessor->title); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
          </select>
        </div>

       
        <div class="form-group d-none" id="installed_ram_div">
          <label for="installed_ram_id">Installed RAM</label>
          <select name="installed_ram_id" id="installed_ram_id" class="form-control">
              <option value="">--Select any --</option>
               <?php $__currentLoopData = $installedRAMs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $installedRAM): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value='<?php echo e($installedRAM->id); ?>'><?php echo e($installedRAM->title); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
          </select>
        </div>
        <div class="form-group d-none" id="hard_capacity_div">
          <label for="hard_capacity_id">Hard Drive Capacity</label>
          <select name="hard_capacity_id" id="hard_capacity_id" class="form-control">
              <option value="">--Select any --</option>
               <?php $__currentLoopData = $hardCapacities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hardCapacity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value='<?php echo e($hardCapacity->id); ?>'><?php echo e($hardCapacity->title); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
          </select>
        </div>
          <div class="form-group d-none" id="dedicated_graphics_memory_div">
          <label for="dedicated_graphics_memory_id">Dedicated Graphics Memory</label>
          <select name="dedicated_graphics_memory_id" id="dedicated_graphics_memory_id" class="form-control">
              <option value="">--Select any --</option>
               <?php $__currentLoopData = $dedicatedGraphicsMemories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dedicatedGraphicsMemory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value='<?php echo e($dedicatedGraphicsMemory->id); ?>'><?php echo e($dedicatedGraphicsMemory->title); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
          </select>
        </div>
          <div class="form-group d-none" id="lab_screen_size_div">
          <label for="lab_screen_size_id">Labtop Screen Size</label>
          <select name="lab_screen_size_id" id="lab_screen_size_id" class="form-control">
              <option value="">--Select any --</option>
               <?php $__currentLoopData = $laptopScreenSizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $laptopScreenSize): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value='<?php echo e($laptopScreenSize->id); ?>'><?php echo e($laptopScreenSize->title); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
          </select>
        </div>
          <div class="form-group d-none" id="wa_res_level_div">
          <label for="wa_res_level_id">Water Resistance Level</label>
          <select name="wa_res_level_id" id="wa_res_level_id" class="form-control">
              <option value="">--Select any --</option>
               <?php $__currentLoopData = $waterResistanceLevels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $waterResistanceLevel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value='<?php echo e($waterResistanceLevel->id); ?>'><?php echo e($waterResistanceLevel->title); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
          </select>
        </div>
        <div class="form-group d-none" id="night_vision_range_div">
          <label for="night_vision_range_id">Night Vision Ranges</label>
          <select name="night_vision_range_id" id="night_vision_range_id" class="form-control">
              <option value="">--Select any --</option>
               <?php $__currentLoopData = $nightVisionRanges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nightVisionRange): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value='<?php echo e($nightVisionRange->id); ?>'><?php echo e($nightVisionRange->title); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
          </select>
        </div>
         <div class="form-group d-none" id="usage_div">
          <label for="usage_id">Camera Usage</label>
          <select name=usage_id" id="usage_id" class="form-control">
              <option value="">--Select any --</option>
               <?php $__currentLoopData = $usages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value='<?php echo e($usage->id); ?>'><?php echo e($usage->title); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
          </select>
        </div>



        <div class="form-group">
          <label for="price" class="col-form-label">Price(NRS) <span class="text-danger">*</span></label>
          <input id="price" type="number" name="price" placeholder="Enter price"  value="<?php echo e(old('price')); ?>" class="form-control">
          <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <span class="text-danger"><?php echo e($message); ?></span>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-group">
          <label for="discount" class="col-form-label">Discount(%)</label>
          <input id="discount" type="number" name="discount" min="0" max="100" placeholder="Enter discount"  value="<?php echo e(old('discount')); ?>" class="form-control">
          <?php $__errorArgs = ['discount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <span class="text-danger"><?php echo e($message); ?></span>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    
        <div class="form-group">
          <label for="condition">Condition</label>
          <select name="condition" class="form-control">
              <option value="">--Select Condition--</option>
              <option value="default">Default</option>
              <option value="new">New</option>
              <option value="hot">Special</option>
          </select>
        </div>

        <div class="form-group">
          <label for="stock">Quantity <span class="text-danger">*</span></label>
          <input id="quantity" type="number" name="stock" min="0" placeholder="Enter quantity"  value="<?php echo e(old('stock')); ?>" class="form-control">
          <?php $__errorArgs = ['stock'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <span class="text-danger"><?php echo e($message); ?></span>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group">
          <label for="inputPhoto" class="col-form-label">Photo <span class="text-danger">*</span></label>
          <div class="input-group">
              <!-- <span class="input-group-btn">
                  <a id="lfm" data-input="thumbnail" data-preview="holder" class="btn btn-primary">
                  <i class="fa fa-picture-o"></i> Choose
                  </a>
              </span> -->
          <input id="thumbnail" class="form-control" type="file" name="photo" value="<?php echo e(old('photo')); ?>">
        </div>
        <div id="holder" style="margin-top:15px;max-height:100px;"></div>
          <?php $__errorArgs = ['photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <span class="text-danger"><?php echo e($message); ?></span>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        
        <div class="form-group">
          <label for="status" class="col-form-label">Status <span class="text-danger">*</span></label>
          <select name="status" class="form-control">
              <option value="active">Active</option>
              <option value="inactive">Inactive</option>
          </select>
          <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <span class="text-danger"><?php echo e($message); ?></span>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group mb-3">
          <button type="reset" class="btn btn-warning">Reset</button>
           <button class="btn btn-success" type="submit">Submit</button>
        </div>
      </form>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('backend/summernote/summernote.min.css')); ?>">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.1/css/bootstrap-select.css" />
<?php $__env->stopPush(); ?>
<?php $__env->startPush('scripts'); ?>
<script src="/vendor/laravel-filemanager/js/stand-alone-button.js"></script>
<script src="<?php echo e(asset('backend/summernote/summernote.min.js')); ?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.1/js/bootstrap-select.min.js"></script>

<script>
    $('#lfm').filemanager('image');

    $(document).ready(function() {
      $('#summary').summernote({
        placeholder: "Write short description.....",
          tabsize: 2,
          height: 100
      });
    });
$(document).ready(function() {
      $('#summary_ar').summernote({
        placeholder: "Write short description.....",
          tabsize: 2,
          height: 100
      });
    });
    $(document).ready(function() {
      $('#description').summernote({
        placeholder: "Write detail description.....",
          tabsize: 2,
          height: 150
      });
    });
    // $('select').selectpicker();

</script>

<script>
  $('#cat_id').change(function(){
    var cat_id=$(this).val();
    // alert(cat_id);
    if(cat_id !=null){
      // Ajax call
      $.ajax({
        url:"/admin/category/"+cat_id+"/child",
        data:{
          _token:"<?php echo e(csrf_token()); ?>",
          id:cat_id
        },
        type:"POST",
        success:function(response){
          if(typeof(response) !='object'){
            response=$.parseJSON(response)
          }
          // console.log(response);
          var html_option="<option value=''>----Select sub category----</option>"
          if(response.status){
            var data=response.data;
            // alert(data);
            if(response.data){
              $('#child_cat_div').removeClass('d-none');
              $.each(data,function(id,title){
                html_option +="<option value='"+id+"'>"+title+"</option>"
              });
            }
            else{
            }
          }
          else{
            $('#child_cat_div').addClass('d-none');
          }
          $('#child_cat_id').html(html_option);
        }
      });
    }
    else{
    }
  })
</script>
<script>
  $('#child_cat_id').change(function(){
    var child_cat_id=$(this).val();
    // alert(cat_id);
    if(cat_id !=null){
      // Ajax call
      $.ajax({
        url:"/admin/get-category/",
        data:{
          _token:"<?php echo e(csrf_token()); ?>",
          id:child_cat_id
        },
        type:"GET",
        success:function(response){
          if(typeof(response) !='object'){
            response=$.parseJSON(response)
          }  
          var title = response.data.title.toLowerCase(); 
          console.log(title);       
          if(response.status){
            if(title == "monitors")
            {
              $('#display_res_div').removeClass('d-none');
              $('#conn_tech_div').removeClass('d-none');
              $('#screen_size_div').removeClass('d-none');
              $('#monitor_feature_div').removeClass('d-none');
            }
            else
            {
              $('#display_res_div').addClass('d-none');
              // $('#conn_tech_div').addClass('d-none');
              $('#screen_size_div').addClass('d-none');
              $('#monitor_feature_div').addClass('d-none');
            }
            if(title == "projector")
            {
              $('#display_types_div').removeClass('d-none');
              $('#conn_tech_div').removeClass('d-none');
              $('#native_resolution_div').removeClass('d-none');
              $('#inc_comp_div').removeClass('d-none');
            }
            else
            {
              $('#display_types_div').addClass('d-none');
              // $('#conn_tech_div').addClass('d-none');
              $('#native_resolution_div').addClass('d-none');
              $('#inc_comp_div').addClass('d-none');
            }
            if(title == "labtop & notebook")
            {
              $('#os_div').removeClass('d-none'); 
              $('#cpu_type_div').removeClass('d-none');
              $('#hard_type_div').removeClass('d-none');
              $('#graphics_corprocessor_div').removeClass('d-none');
             // $('#dedicated_graphics_memory_div').removeClass('d-none');
              $('#installed_ram_div').removeClass('d-none');             
            }
            else
            {
             // $('#os_div').addClass('d-none'); 
              $('#cpu_type_div').addClass('d-none');
              //$('#hard_type_div').addClass('d-none');
              $('#graphics_corprocessor_div').addClass('d-none');
              $('#dedicated_graphics_memory_div').addClass('d-none');
             // $('#installed_ram_div').addClass('d-none');          
            }
            if(title == "desktop")
            {
              $('#os_div').removeClass('d-none'); 
              $('#hard_capacity_div').removeClass('d-none');
              $('#hard_type_div').removeClass('d-none');
              $('#installed_ram_div').removeClass('d-none');
            } 
            else
            {
              //$('#os_div').addClass('d-none'); 
              $('#hard_capacity_div').addClass('d-none');
             // $('#hard_type_div').addClass('d-none');
              //$('#installed_ram_div').addClass('d-none');
            } 
            if(title == "lab top bags")
            {
              $('#lab_screen_size_div').removeClass('d-none');
              $('#wa_res_level_div').removeClass('d-none');
            } 
            else
            {
              $('#lab_screen_size_div').addClass('d-none');
              $('#wa_res_level_div').addClass('d-none');
            }                   
            if(title == "power extension")
            {
              $('#product_length_div').removeClass('d-none');
            }   
            else
            {
              $('#product_length_div').addClass('d-none');
            }
            if(title == "cabels")
            {
              $('#product_length_div').removeClass('d-none');
            }   
            else
            {
              $('#product_length_div').addClass('d-none');
            } 
             if(title == "surveillance camera")
            {
              $('#night_vision_range_div').removeClass('d-none');
              $('#conn_tech_div').removeClass('d-none');
              $('#usage_div').removeClass('d-none');
            }   
            else
            {
              $('#night_vision_range_div').addClass('d-none');
              $('#usage_div').addClass('d-none');
            }   
          }
          else{
            $('#child_cat_div').addClass('d-none');
          }          
        }
      });
    }
    else{
    }
  })
</script>
<script>
    $('#child_cat_id').change(function(){
    var child_catt_id=$(this).val();
    //  alert(child_catt_id);
    if(cat_id !=null){
      // Ajax call
      $.ajax({
        url:"/admin/get-child-category/",
         data:{
          _token:"<?php echo e(csrf_token()); ?>",
          id:child_catt_id
        },
        type:"GET",
        success:function(response){
          if(typeof(response) !='object'){
            response=$.parseJSON(response)
          }
          // console.log(response);
          var html_option="<option value=''>----Select sub sub category----</option>"
          if(response.status){
            var data=response.data;
            // alert(data);
            if(response.data){
              $('#child_child_cat_div').removeClass('d-none');
              $.each(data,function(id,title){
                html_option +="<option value='"+id+"'>"+title+"</option>"
              });
            }
            else{
            }
          }
          else{
            $('#child_child_cat_div').addClass('d-none');
          }
          $('#child_child_cat_id').html(html_option);
        }
      });
    }
    else{
    }
  })
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alsaifcoksa/public_html/onlinestore.alsaifco-ksa.com/resources/views/backend/product/create.blade.php ENDPATH**/ ?>