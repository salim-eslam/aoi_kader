<head>
    <meta charset="utf-8">
    <meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="icon" type="image/png" href="<?php echo e(asset('front/img/alsaif.png')); ?>">
    <title>AlSaif - Ecommerce</title>
    <!-- Google font -->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,500,700" rel="stylesheet">

    <!-- Bootstrap -->
    <link href="https://www.jqueryscript.net/demo/Highly-Customizable-Range-Slider-Plugin-For-Bootstrap-Bootstrap-Slider/dist/css/bootstrap-slider.css" rel="stylesheet" type="text/css">

    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"/>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css"/>
     <?php if(app()->getLocale() == 'ar'): ?>
     <link type="text/css" rel="stylesheet" href="<?php echo e(asset('front/rtlcss/bootstrap.min.css')); ?>" />
     <?php else: ?>
    <link type="text/css" rel="stylesheet" href="<?php echo e(asset('front/css/bootstrap.min.css')); ?>" />
    <?php endif; ?>
    <!-- Slick -->
    <link type="text/css" rel="stylesheet" href="<?php echo e(asset('front/css/slick.css')); ?>" />
    <link type="text/css" rel="stylesheet" href="<?php echo e(asset('front/css/slick-theme.css')); ?>" />

    <!-- nouislider -->
    <link type="text/css" rel="stylesheet" href="<?php echo e(asset('front/css/nouislider.min.css')); ?>" />

    <!-- Font Awesome Icon -->
    <link rel="stylesheet" href="<?php echo e(asset('front/css/font-awesome.min.css')); ?>">
   
    <!-- Custom stlylesheet -->
    <?php if(app()->getLocale() == 'ar'): ?>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.4/css/all.min.css">
     <link type="text/css" rel="stylesheet" href="<?php echo e(asset('front/rtlcss/style.css')); ?>" />
    <?php else: ?>
    <link type="text/css" rel="stylesheet" href="<?php echo e(asset('front/css/style.css')); ?>" />
    <?php endif; ?>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
    <script>
        $(document).ready(function() {
            $(".wish-icon i").click(function() {
                $(this).toggleClass("fa-heart fa-heart-o");
            });
        });
    </script>
    <?php if(app()->getLocale() == 'ar'): ?>
    <style>
 .accordion {
  /*width: 60%;*/
  max-width: 1000px;
  /*margin: 2rem 10rem;*/
  position: relative;
    border-bottom-width: 1px;
  --tw-border-opacity: 1;
    border-color: rgba(229, 232, 236, var(--tw-border-opacity));
    /* padding-right: 20px; */
}

.accordion-item {
  /* background-color: #fff; */
  color: #111;
  margin: 1rem 0;
  /* border-radius: 0.5rem; */
 
}

.accordion-item-header {
  padding: 0.5rem 3rem 0.5rem 1rem;
  min-height: 4.5rem;
  line-height: 1.25rem;
  font-weight: bold;
  display: flex;
  align-items: center;
  position: relative;
  cursor: pointer;
}

.accordion-item-header::after {
  content: "\002B";
  font-size: 34px;
  font-weight:300;
  position: absolute;
  left: 1rem;
}

.accordion-item-header.active::after {
  content: "\2212";
}

.accordion-item-body {
  max-height: 0;
  overflow: hidden;
  transition: max-height 0.2s ease-out;
}

.accordion-item-body-content {
  padding: 1rem;
  line-height: 1.5rem;
  border-top: 1px solid;
  border-image: linear-gradient(to right, transparent, #34495e, transparent) 1;
   /*max-height: 390px;*/
   /*overflow: scroll;*/
   /*overflow-x: hidden;*/
}

.current-value {
	position: absolute;
	top: -2.5em;
	left: 50%;
	width: 60px;
	height: 1em;
	text-align: center;
	color: #81b5cc;
	font-weight: bold;
	white-space: nowrap;
}
.range {
	position: relative;
	float: left;
	width: 80vw;
	padding: 0 0.9375rem;
}
 @media (min-width: 1024px) and (max-width: 2560px){
           .accordion
           {
               width: 69%;
               margin: 2rem 6rem;
           }
        }
/* Create two equal columns that floats next to each other */
.column {
  float: right;
  /*width: 100%;*/
  padding: 10px;
}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}
/* Style the buttons */
.btn {
  border: none;
  outline: none;
  padding: 12px 16px;
  border:1px solid #E4E7ED;
  /*background-color: #f1f1f1;*/
  cursor: pointer;
}

.btn:hover {
  background-color: #f5f5f5;
}

.btn.active {
  /*background-color: #ddd;*/
  border:1px solid #E4E7ED;
  box-shadow: none;
  /*color: white;*/
}
   </style>
    <?php else: ?>
   <style>
 .accordion {
   max-width: 1000px;
  /*margin: 2rem auto;*/
  position: relative;
    border-bottom-width: 1px;
  --tw-border-opacity: 1;
    border-color: rgba(229, 232, 236, var(--tw-border-opacity));
}

.accordion-item {
  /* background-color: #fff; */
  color: #111;
  margin: 1rem 0;
  /* border-radius: 0.5rem; */
 
}

.accordion-item-header {
  padding: 0.5rem 3rem 0.5rem 1rem;
  min-height: 4.5rem;
  line-height: 1.25rem;
  font-weight: bold;
  display: flex;
  align-items: center;
  position: relative;
  cursor: pointer;
}

.accordion-item-header::after {
  content: "\002B";
  font-size: 34px;
  font-weight:300;
  position: absolute;
  right: 1rem;
}

.accordion-item-header.active::after {
  content: "\2212";
}

.accordion-item-body {
  max-height: 0;
  overflow: hidden;
  transition: max-height 0.2s ease-out;
}

.accordion-item-body-content {
  padding: 1rem;
  line-height: 1.5rem;
  border-top: 1px solid;
  border-image: linear-gradient(to right, transparent, #34495e, transparent) 1;
   /*max-height: 390px;*/
   /*overflow: scroll;*/
   /*overflow-x: hidden;*/
}

.current-value {
	position: absolute;
	top: -2.5em;
	left: 50%;
	width: 60px;
	height: 1em;
	text-align: center;
	color: #81b5cc;
	font-weight: bold;
	white-space: nowrap;
}
.range {
	position: relative;
	float: left;
	width: 80vw;
	padding: 0 0.9375rem;
}
   @media (min-width: 1024px) and (max-width: 2560px){
           .accordion
           {
               width: 69%;
               margin: 2rem 6rem;
           }
        }
 .CategoryPage__filters--close{
  position: absolute;
  bottom: 140px;
  left: 120px;
  margin: 0 auto;
  cursor: pointer;
}

.CategoryPage__filters__item--close{
  background: #e6e6e6;
  border-radius: 15px;
}

.item--close-1 {
  transform: rotate(45deg);
  top: 0px;
  position: absolute;
}

.item--close-2 {
  transform: rotate(-45deg);
  top: 0px;
  position: absolute;
}
/* Create two equal columns that floats next to each other */
.column {
  float: left;
  /*width: 100%;*/
  padding: 10px;
}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}
/* Style the buttons */
.btn {
  border: none;
  outline: none;
  padding: 12px 16px;
  border:1px solid #E4E7ED;
  /*background-color: #f1f1f1;*/
  cursor: pointer;
}

.btn:hover {
  background-color: #f5f5f5;
}

.btn.active {
  /*background-color: #ddd;*/
  border:1px solid #E4E7ED;
  box-shadow: none;
  /*color: white;*/
}

   </style>
   
   <?php endif; ?>
   <style>
       .wrapper {
  /*width: 400px;*/
  /*background: #fff;*/
  /*border-radius: 10px;*/
  /*padding: 20px 25px 40px;*/
  /*box-shadow: 0 12px 35px rgba(0, 0, 0, 0.1);*/
}

.price-input {
  width: 100%;
  display: flex;
  margin: 30px 0 35px;
}
.price-input .field {
  /*display: flex;*/
  width: 100%;
  height: 27px;
  align-items: center;
}
.field input {
  width: 55%;
  height: 100%;
  outline: none;
  font-size: 19px;
  /*margin-left: 12px;*/
  border-radius: 5px;
  text-align: center;
  border: 1px solid rgb(153 153 153 / 25%);
  -moz-appearance: textfield;
}
input[type="number"]::-webkit-outer-spin-button,
input[type="number"]::-webkit-inner-spin-button {
  -webkit-appearance: none;
}
.price-input .separator {
  width: 130px;
  display: flex;
  font-size: 19px;
  align-items: center;
  justify-content: center;
}
.slider {
  height: 5px;
  position: relative;
  background: #ddd;
  border-radius: 5px;
}
.slider .progress {
  height: 100%;
  left: 0;
  right: 0;
  position: absolute;
  border-radius: 5px;
  background:#642221;
}
input[type=range] {
  accent-color:rgba(100, 34, 33,1);
}
.range-input {
  position: relative;
}
.range-input input {
  position: absolute;
  width: 100%;
  height: 5px;
  /*top: -5px;*/
  background: none;
  pointer-events: none;
  /*-webkit-appearance: none;*/
  /*-moz-appearance: none;*/
}
input[type="range"]::-webkit-slider-thumb {
  height: 17px;
  width: 17px;
  border-radius: 50%;
  background: #17a2b8;
  pointer-events: auto;
  -webkit-appearance: none;
  box-shadow: 0 0 6px rgba(0, 0, 0, 0.05);
}
input[type="range"]::-moz-range-thumb {
  height: 17px;
  width: 17px;
  border: none;
  border-radius: 50%;
  background: #17a2b8;
  pointer-events: auto;
  -moz-appearance: none;
  box-shadow: 0 0 6px rgba(0, 0, 0, 0.05);
}

/* Support */
.support-box {
  top: 2rem;
  position: relative;
  bottom: 0;
  text-align: center;
  display: block;
}
.b-btn {
  color: white;
  text-decoration: none;
  font-weight: bold;
}
.b-btn.paypal i {
  color: blue;
}
.b-btn:hover {
  text-decoration: none;
  font-weight: bold;
}
.b-btn i {
  font-size: 20px;
  color: yellow;
  margin-top: 2rem;
}

input[type=checkbox]
{
    height: 1.25rem;
    width: 1.25rem;
    cursor: pointer;
    border-radius: 0.25rem;
    border-width: 1px;
    border-color: rgba(0, 28, 70, 1);
    background-color: transparent;
}
   </style>
</head><?php /**PATH /home/alsaifcoksa/public_html/onlinestore.alsaifco-ksa.com/resources/views/front/layouts/head.blade.php ENDPATH**/ ?>