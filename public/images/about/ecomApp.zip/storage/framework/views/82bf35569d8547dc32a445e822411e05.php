<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

    <!-- Sidebar - Brand -->
    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="<?php echo e(route('admin')); ?>">
      <div class="sidebar-brand-icon rotate-n-15">
        <i class="fas fa-laugh-wink"></i>
      </div>
      <div class="sidebar-brand-text mx-3">Admin</div>
    </a>

    <!-- Divider -->
    <hr class="sidebar-divider my-0">

    <!-- Nav Item - Dashboard -->
    <li class="nav-item active">
      <a class="nav-link" href="<?php echo e(route('admin')); ?>">
        <i class="fas fa-fw fa-tachometer-alt"></i>
        <span>Dashboard</span></a>
    </li>

    <!-- Divider -->
    <hr class="sidebar-divider">

    <!-- Heading -->
    <div class="sidebar-heading">
        Banner
    </div>

    <!-- Nav Item - Pages Collapse Menu -->
    <!-- Nav Item - Charts -->
    <!-- <li class="nav-item">  
        <a class="nav-link" href="<?php echo e(route('file-manager')); ?>">
            <i class="fas fa-fw fa-chart-area"></i>
            <span>Media Manager</span></a>
    </li> -->

    <li class="nav-item">
      <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
        <i class="fas fa-image"></i>
        <span>Banners</span>
      </a>
      <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
        <div class="bg-white py-2 collapse-inner rounded">
          <h6 class="collapse-header">Banner Options:</h6>
          <a class="collapse-item" href="<?php echo e(route('banner.index')); ?>">Banners</a>
          <a class="collapse-item" href="<?php echo e(route('banner.create')); ?>">Add Banners</a>
        </div>
      </div>
    </li>
    <!-- Divider -->
    <hr class="sidebar-divider">
        <!-- Heading -->
        <div class="sidebar-heading">
            Shop
        </div>

    <!-- Categories -->
    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#categoryCollapse" aria-expanded="true" aria-controls="categoryCollapse">
          <i class="fas fa-sitemap"></i>
          <span>Category</span>
        </a>
        <div id="categoryCollapse" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Category Options:</h6>
            <a class="collapse-item" href="<?php echo e(route('category.index')); ?>">Category</a>
            <a class="collapse-item" href="<?php echo e(route('category.create')); ?>">Add Category</a>
          </div>
        </div>
    </li>
    
    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#productCollapse" aria-expanded="true" aria-controls="productCollapse">
          <i class="fas fa-cubes"></i>
          <span>Products</span>
        </a>
        <div id="productCollapse" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Product Options:</h6>
            <a class="collapse-item" href="<?php echo e(route('product.index')); ?>">Products</a>
            <a class="collapse-item" href="<?php echo e(route('product.create')); ?>">Add Product</a>
          </div>
        </div>
    </li>

    <!-- -->
    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#brandCollapse" aria-expanded="true" aria-controls="brandCollapse">
          <i class="fas fa-table"></i>
          <span>Brands</span>
        </a>
        <div id="brandCollapse" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Brand Options:</h6>
            <a class="collapse-item" href="<?php echo e(route('brand.index')); ?>">Brands</a>
            <a class="collapse-item" href="<?php echo e(route('brand.create')); ?>">Add Brand</a>
          </div>
        </div>
    </li> 

    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#osCollapse" aria-expanded="true" aria-controls="osCollapse">
          <i class="fas fa-table"></i>
          <span>Operating Systems</span>
        </a>
        <div id="osCollapse" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Operating System Options:</h6>
            <a class="collapse-item" href="<?php echo e(route('os.index')); ?>">Operating Systems</a>
            <a class="collapse-item" href="<?php echo e(route('os.create')); ?>">Add Operating System</a>
          </div>
        </div>
    </li>
    
    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#cpuCollapse" aria-expanded="true" aria-controls="cpuCollapse">
          <i class="fas fa-table"></i>
          <span>Cpu Types</span>
        </a>
        <div id="cpuCollapse" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Cpu Type Options:</h6>
            <a class="collapse-item" href="<?php echo e(route('cpu-type.index')); ?>">Cpu Types</a>
            <a class="collapse-item" href="<?php echo e(route('cpu-type.create')); ?>">Add Cpu Type</a>
          </div>
        </div>
    </li>
    
    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#graphicsCorCollapse" aria-expanded="true" aria-controls="graphicsCorCollapse">
          <i class="fas fa-table"></i>
          <span>Graphics Coprocessor</span>
        </a>
        <div id="graphicsCorCollapse" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Graphics Coprocessor Options:</h6>
            <a class="collapse-item" href="<?php echo e(route('graphics-coprocessor.index')); ?>">Graphics Coprocessors</a>
            <a class="collapse-item" href="<?php echo e(route('graphics-coprocessor.create')); ?>">Add Graphics Coprocessor</a>
          </div>
        </div>
    </li>
    
    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#installedRamCollapse" aria-expanded="true" aria-controls="installedRamCollapse">
          <i class="fas fa-table"></i>
          <span>Installed Rams</span>
        </a>
        <div id="installedRamCollapse" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Installed Ram Options:</h6>
            <a class="collapse-item" href="<?php echo e(route('installed-ram.index')); ?>">Installed Rams</a>
            <a class="collapse-item" href="<?php echo e(route('installed-ram.create')); ?>">Add Installed Ram </a>
          </div>
        </div>
    </li>
    
    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#hardTypeCollapse" aria-expanded="true" aria-controls="hardTypeCollapse">
          <i class="fas fa-table"></i>
          <span>Hard Types</span>
        </a>
        <div id="hardTypeCollapse" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Hard Types Options:</h6>
            <a class="collapse-item" href="<?php echo e(route('hard-type.index')); ?>">Hard Types</a>
            <a class="collapse-item" href="<?php echo e(route('hard-type.create')); ?>">Add Hard Type </a>
          </div>
        </div>
    </li>
    
    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#dgmCollapse" aria-expanded="true" aria-controls="dgmCollapse">
          <i class="fas fa-table"></i>
          <span>Dedicated Graphics Memory</span>
        </a>
        <div id="dgmCollapse" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Dedicated Graphics Memory Options:</h6>
            <a class="collapse-item" href="<?php echo e(route('dgm.index')); ?>">Dedicated Graphics Memories</a>
            <a class="collapse-item" href="<?php echo e(route('dgm.create')); ?>">Add Dedicated Graphics Memory </a>
          </div>
        </div>
    </li>
    
    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#hcCollapse" aria-expanded="true" aria-controls="hcCollapse">
          <i class="fas fa-table"></i>
          <span>Hard Capacity</span>
        </a>
        <div id="hcCollapse" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Hard Capacity Options:</h6>
            <a class="collapse-item" href="<?php echo e(route('hard-capacity.index')); ?>">Hard Capacities</a>
            <a class="collapse-item" href="<?php echo e(route('hard-capacity.create')); ?>">Add Hard Capacity </a>
          </div>
        </div>
    </li>
    
    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#dtCollapse" aria-expanded="true" aria-controls="dtCollapse">
          <i class="fas fa-table"></i>
          <span>Display Type</span>
        </a>
        <div id="dtCollapse" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Display Type Options:</h6>
            <a class="collapse-item" href="<?php echo e(route('display-type.index')); ?>">Display Types</a>
            <a class="collapse-item" href="<?php echo e(route('display-type.create')); ?>">Add Display Type </a>
          </div>
        </div>
    </li>
    
    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#ctCollapse" aria-expanded="true" aria-controls="ctCollapse">
          <i class="fas fa-table"></i>
          <span>Connectivity Technologies</span>
        </a>
        <div id="ctCollapse" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Connectivity Technology Options:</h6>
            <a class="collapse-item" href="<?php echo e(route('conn-tech.index')); ?>">Connectivity Technologies</a> 
            <a class="collapse-item" href="<?php echo e(route('conn-tech.create')); ?>">Add Connectivity Technology </a>
          </div>
        </div>
    </li>
    
    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#drCollapse" aria-expanded="true" aria-controls="drCollapse">
          <i class="fas fa-table"></i>
          <span>Display Resolutions</span>
        </a>
        <div id="drCollapse" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Display Resolution Options:</h6>
            <a class="collapse-item" href="<?php echo e(route('display-res.index')); ?>">Display Resolutions</a> 
            <a class="collapse-item" href="<?php echo e(route('display-res.create')); ?>">Add Display Resolution </a>
          </div>
        </div>
    </li>
    
    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#nrCollapse" aria-expanded="true" aria-controls="nrCollapse">
          <i class="fas fa-table"></i>
          <span>Native Resolutions</span>
        </a>
        <div id="nrCollapse" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Native Resolution Options:</h6>
            <a class="collapse-item" href="<?php echo e(route('natv-res.index')); ?>">Native Resolutions</a> 
            <a class="collapse-item" href="<?php echo e(route('natv-res.create')); ?>">Add Native Resolution </a>
          </div>
        </div>
    </li>
    
    <!--<li class="nav-item">-->
    <!--    <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#icCollapse" aria-expanded="true" aria-controls="icCollapse">-->
    <!--      <i class="fas fa-table"></i>-->
    <!--      <span>Include Components</span>-->
    <!--    </a>-->
    <!--    <div id="icCollapse" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">-->
    <!--      <div class="bg-white py-2 collapse-inner rounded">-->
    <!--        <h6 class="collapse-header">Include Components Options:</h6>-->
    <!--        <a class="collapse-item" href="<?php echo e(route('inc-comp.index')); ?>">Include Components</a> -->
    <!--        <a class="collapse-item" href="<?php echo e(route('inc-comp.create')); ?>">Add Include Component </a>-->
    <!--      </div>-->
    <!--    </div>-->
    <!--</li>-->
    
    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#scsCollapse" aria-expanded="true" aria-controls="scsCollapse">
          <i class="fas fa-table"></i>
          <span>Screen Sizes</span>
        </a>
        <div id="scsCollapse" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Screen Sizes Options:</h6>
            <a class="collapse-item" href="<?php echo e(route('screen-size.index')); ?>">Screen Sizes</a> 
            <a class="collapse-item" href="<?php echo e(route('screen-size.create')); ?>">Add Screen Size</a>
          </div>
        </div>
    </li>
    
    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#mfCollapse" aria-expanded="true" aria-controls="mfCollapse">
          <i class="fas fa-table"></i>
          <span>Monitor Features</span>
        </a>
        <div id="mfCollapse" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Monitor Features Options:</h6>
            <a class="collapse-item" href="<?php echo e(route('monitor-feature.index')); ?>">Monitor Features</a> 
            <a class="collapse-item" href="<?php echo e(route('monitor-feature.create')); ?>">Add Monitor Feature</a>
          </div>
        </div>
    </li>
     
    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#plCollapse" aria-expanded="true" aria-controls="plCollapse">
          <i class="fas fa-table"></i>
          <span>Product Length</span>
        </a>
        <div id="plCollapse" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Product Length Options:</h6>
            <a class="collapse-item" href="<?php echo e(route('product-length.index')); ?>">Product Lengths</a> 
            <a class="collapse-item" href="<?php echo e(route('product-length.create')); ?>">Add Product Length</a>
          </div>
        </div>
    </li>
    
    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#cuCollapse" aria-expanded="true" aria-controls="cuCollapse">
          <i class="fas fa-table"></i>
          <span>Camera Usage</span>
        </a>
        <div id="cuCollapse" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Camera Usage Options:</h6>
            <a class="collapse-item" href="<?php echo e(route('camera-usage.index')); ?>">Camera Usages</a> 
            <a class="collapse-item" href="<?php echo e(route('camera-usage.create')); ?>">Add Camera Usage</a>
          </div>
        </div>
    </li>
    
    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#nvrCollapse" aria-expanded="true" aria-controls="nvrCollapse">
          <i class="fas fa-table"></i>
          <span>Night Vision Range</span>
        </a>
        <div id="nvrCollapse" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Night Vision Range Options:</h6>
            <a class="collapse-item" href="<?php echo e(route('night-vision-range.index')); ?>">Night Vision Ranges</a> 
            <a class="collapse-item" href="<?php echo e(route('night-vision-range.create')); ?>">Add Night Vision Range</a>
          </div>
        </div>
    </li>
    
    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#shippingCollapse" aria-expanded="true" aria-controls="shippingCollapse">
          <i class="fas fa-truck"></i>
          <span>Shipping</span>
        </a>
        <div id="shippingCollapse" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Shipping Options:</h6>
            <a class="collapse-item" href="<?php echo e(route('shipping.index')); ?>">Shipping</a>
            <a class="collapse-item" href="<?php echo e(route('shipping.create')); ?>">Add Shipping</a>
          </div>
        </div>
    </li>

    <!--Orders -->
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('order.index')); ?>">
            <i class="fas fa-hammer fa-chart-area"></i>
            <span>Orders</span>
        </a>
    </li>

    <!-- Reviews -->
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('review.index')); ?>">
            <i class="fas fa-comments"></i>
            <span>Reviews</span></a>
    </li>
    

    <!-- Divider -->
    <hr class="sidebar-divider">

    <!-- Heading -->
    <!-- <div class="sidebar-heading">
      Posts
    </div> -->

    <!-- Posts -->
    <!-- <li class="nav-item">
      <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#postCollapse" aria-expanded="true" aria-controls="postCollapse">
        <i class="fas fa-fw fa-folder"></i>
        <span>Posts</span>
      </a>
      <div id="postCollapse" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
        <div class="bg-white py-2 collapse-inner rounded">
          <h6 class="collapse-header">Post Options:</h6>
          <a class="collapse-item" href="<?php echo e(route('post.index')); ?>">Posts</a>
          <a class="collapse-item" href="<?php echo e(route('post.create')); ?>">Add Post</a>
        </div>
      </div>
    </li> -->

     <!-- Category -->
     <!-- <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#postCategoryCollapse" aria-expanded="true" aria-controls="postCategoryCollapse">
          <i class="fas fa-sitemap fa-folder"></i>
          <span>Category</span>
        </a>
        <div id="postCategoryCollapse" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Category Options:</h6>
            <a class="collapse-item" href="<?php echo e(route('post-category.index')); ?>">Category</a>
            <a class="collapse-item" href="<?php echo e(route('post-category.create')); ?>">Add Category</a>
          </div>
        </div>
      </li> -->

      <!-- Tags -->
    <!-- <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#tagCollapse" aria-expanded="true" aria-controls="tagCollapse">
            <i class="fas fa-tags fa-folder"></i>
            <span>Tags</span>
        </a>
        <div id="tagCollapse" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Tag Options:</h6>
            <a class="collapse-item" href="<?php echo e(route('post-tag.index')); ?>">Tag</a>
            <a class="collapse-item" href="<?php echo e(route('post-tag.create')); ?>">Add Tag</a>
            </div>
        </div>
    </li> -->

      <!-- Comments -->
      <!-- <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('comment.index')); ?>">
            <i class="fas fa-comments fa-chart-area"></i>
            <span>Comments</span>
        </a>
      </li> -->


    <!-- Divider -->
    <hr class="sidebar-divider d-none d-md-block">
     <!-- Heading -->
    <div class="sidebar-heading">
        General Settings
    </div>
    <li class="nav-item">
      <a class="nav-link" href="<?php echo e(route('coupon.index')); ?>">
          <i class="fas fa-table"></i>
          <span>Coupon</span></a>
    </li>
     <!-- Users -->
     <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('users.index')); ?>">
            <i class="fas fa-users"></i>
            <span>Users</span></a>
    </li>
     <!-- General settings -->
     <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('settings')); ?>">
            <i class="fas fa-cog"></i>
            <span>Settings</span></a>
    </li>

    <!-- Sidebar Toggler (Sidebar) -->
    <div class="text-center d-none d-md-inline">
      <button class="rounded-circle border-0" id="sidebarToggle"></button>
    </div>

</ul><?php /**PATH /home/alsaifcoksa/public_html/onlinestore.alsaifco-ksa.com/resources/views/backend/layouts/sidebar.blade.php ENDPATH**/ ?>