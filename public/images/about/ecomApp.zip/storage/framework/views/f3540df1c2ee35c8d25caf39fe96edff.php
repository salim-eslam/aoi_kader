

<?php $__env->startSection('title','Alsaif || Home'); ?>

<?php $__env->startSection('main-content'); ?>
<div class="section CategoryPage__inner ">
     <!-- container -->
     <div class="container-fluid">    
                <!-- row -->
  <div class="row">
  <!-- <b id="min_value">Rs. 0</b> <input id="ex2" type="text" class="span2" value="" data-slider-min="0" data-slider-max="5000" data-slider-step="5" data-slider-value="[0,5000]"/> <b id="max_value">Rs. 5000 </b> -->
  <?php if(app()->getLocale() == 'ar'): ?>
  <div id="store" class="col-md-9">
  <div id="ajax_result">

						<!-- store top filter -->
						<div class="store-filter clearfix">
                        <div  class="slides-3 swiper-container swiper-container-initialized swiper-container-horizontal swiper-container-pointer-events"><div class="swiper-wrapper" style="transition-duration: 0ms; transform: translate3d(0px, 0px, 0px);">
                                             
                                        
                        <?php $brands = \App\Models\Brand::all(); ?>
                        <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="swiper-slide" style="margin-right: 20px;"><button type="button"  class="text-primary-700 px-4 flex items-center justify-center text-center has-active-state SubCategory__item brand_btn" value="<?php echo e($brand->slug); ?>" onclick="getProducts(this.value)" style="width:100%;"><span  class="text-sm font-bold m swiper-text">
                        <?php if(app()->getLocale() == 'ar'): ?>
                        <?php echo e($brand->title_ar); ?>

                        <?php else: ?>
                        <?php echo e($brand->title); ?>

                        <?php endif; ?>
                        </span></button></div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div> <div class="flex mt-5"><button aria-label="next slide" class="swiper-button-next hologram-link text-white hover: mr-8"><img src="/front/images/next.png" alt=""/></button> <button data-v-3f2087ee="" aria-label="previous slide" class="swiper-button-prev hologram-link text-white mr-7"><img src="/front/images/prev.png" al=""/></button></div></div>
							<div id="btnContainer" style="float:left;">
  <button class="btn" onclick="listView()"><i class="fa fa-bars"></i></button> 
  <button class="btn active" onclick="gridView()"><i class="fa fa-th-large"></i></button>
</div>
						</div>
						<!-- /store top filter -->

						<!-- store products -->
						<div class="row">                        
                        <!-- product -->
    <?php if(count($products)>0): ?>
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <?php
                                         $category = \App\Models\Category::where('id',$product->cat_id)->first();
                                      ?>
							<div class="col-sm-3 col-xs-6 column">					
                               
                                <div class="product">
                                    <div class="product-img">
                                         <div class="product-btns">
                                            <button class="add-to-wishlist"><i class="fa fa-heart-o"></i><span
                                                    class="tooltipp">add to wishlist</span></button> 
                                                    </div>
                                        <img  src="/<?php echo e($product->photo); ?>" alt="">
                                        <div class="product-label">
                                            <span class="new"><?php echo e(trans('home/body.new')); ?></span>
                                        </div>
                                    </div>
                                    <div class="product-body">
                                         <p class="product-category"><?php echo e($category->title_ar); ?></p>
                                        <h3 class="product-name"><a href="#"><?php echo e($product->title_ar); ?></a></h3>
                                        <?php
                                                    $after_discount=($product->price-($product->price*$product->discount)/100);
                                                ?>
                                        <h4 class="product-price"> <?php echo e(number_format($after_discount,2)); ?>

                                            ريال سعودي
                                        <?php if($product->discount == 0): ?>
                                        <?php else: ?>
                                        <del class="product-old-price"><?php echo e($product->price); ?></del>
                                        <?php endif; ?>
                                                </h4>
            <!--                            <div class="product-rating">-->
												<!--</div>-->
                                         <div class="product-btns">
                                            <!--<button class="add-to-wishlist"><i class="fa fa-heart-o"></i><span-->
                                            <!--        class="tooltipp">add to wishlist</span></button>-->
                                            <button class="add-to-compare"><i class="fa fa-exchange"></i><span
                                                    class="tooltipp">add to compare</span></button> 
                                            <button type="button"
                                                style="background-color: #642221; width:auto;  text-transform: uppercase; font-weight: 700;border-radius: 40px;text-transform: uppercase;font-size:13px;padding:0px 25px 5px 25px;"
                                                class="btn btn-danger"> <?php echo e(trans('home/body.addtocart')); ?></button>

                                            <a data-toggle="modal" data-target="#<?php echo e($product->id); ?>" title="Quick View" href="#" class="quick-view"><i class="fa fa-eye"></i><span
                                                    class="tooltipp">quick view</span></a>                                                    
                                        </div>
                                    </div>
                                    <!--<div class="add-to-cart">-->
                                    <!--    <button class="add-to-cart-btn"><i class="fa fa-shopping-cart"></i> add to-->
                                    <!--        cart</button>-->
                                    <!--</div>-->
                                </div>                              
							</div>
							<!-- /product -->
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>		
                            <?php else: ?>
                            <h4 class="text-warning" style="margin:100px auto;">There are no products.</h4>
                            <?php endif; ?>				
						</div>
						<!-- /store products -->
                        <!-- store bottom filter -->

		
</div>
<div class="store-filter clearfix">
							<!-- <span class="store-qty">Showing 20-100 products</span> -->
							<ul class="store-pagination">
                            <?php echo e($products->appends($_GET)->links()); ?>							
							</ul>
						</div>
						<!-- /store bottom filter -->
					</div>
					<!-- /STORE -->
<div id="store" class="col-md-3">
              
                    <div class="CategoryPage__filters sidebar" id="sidebar">
                    <h2 class="text-primary-700 text-3xl font-display font-bold antialiased mb-5 relative" style="margin-right: 21%;">
                    <?php if(app()->getLocale() == 'ar'): ?>
                    تسوق حسب
                    <?php else: ?>
                        Filter by
                    <?php endif; ?>
                    </h2>
                     <div class="accordion">
  <div class="accordion-item">
    <div class="accordion-item-header">
      السعر
     </div> 
    <!-- /.accordion-item-header -->
 <div class="accordion-item-body">
      <div class="accordion-item-body-content">
     <!-- <span id="slider_value2" style="color:red;font-weight:bold;"></span><br>
      Rs. 0 <input type="range" min="0" max="5000" step="1" name="sld6" value="" onchange="show_value2(this.value)" tooltip="this.value"> Rs. 5000 -->
      <!-- <span class="current-value">0</span> -->
         <div class="d-flex">
    <div class="wrapper">
        <div class="slider">
        <div class="progress"></div>
      </div>
      <div class="range-input">
        <input type="range" class="range-min" min="0" max="5000" value="0" step="100">
        <input type="range" class="range-max" min="0" max="5000" value="5000" step="100">
      </div>
      <div class="price-input">
        <div class="field">
          <span>من</span>
          <input type="number" id="from" class="input-min" value="0">
           <span>ريال</span>
        </div>
        <div class="separator"></div>
        <div class="field" style="text-align:right;">
          <span>الي</span>
          <input type="number" class="input-max" value="5000">
          <span>ريال</span>
        </div>
      </div>
      
    </div>

    
  </div>
       </div> 
     </div> 
    <!-- /.accordion-item-body -->
   </div> 
  <!-- /.accordion-item -->
 </div> 
<?php                     $os_ids = \App\Models\Product::whereNotNull('os_id')
                        ->where('child_cat_id',$cat_id)->get();
                        $os_ids_count = $os_ids->count();
                         ?>
<?php if($os_ids_count > 0): ?>                        
<div class="accordion"> 
  <div class="accordion-item">
    <div class="accordion-item-header">
    <?php if(app()->getLocale() == 'ar'): ?>
    نظام التشغيل
    <?php else: ?>
      Operating System
     <?php endif; ?> 
    </div><!-- /.accordion-item-header -->
    <div class="accordion-item-body">
      <div class="accordion-item-body-content">                              
              <?php $osList = \App\Models\OperatingSystems::all(); ?>
              <?php $__currentLoopData = $osList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $os): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
              <?php if(app()->getLocale() == 'ar'): ?>
              <div class="form-group"> <input class="os_check" type="checkbox" value="<?php echo e($os->slug); ?>" id="<?php echo e($os->slug); ?>"> <label for="25"><?php echo e($os->title_ar); ?></label> </div>      
              <?php else: ?>     
             <div class="form-group"> <input class="os_check" type="checkbox" value="<?php echo e($os->slug); ?>" id="<?php echo e($os->slug); ?>"> <label for="25"><?php echo e($os->title); ?></label> </div>          
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div><!-- /.accordion-item-body -->
  </div><!-- /.accordion-item -->
</div>
<?php endif; ?>
<?php                     $hard_type_ids = \App\Models\Product::whereNotNull('hard_type_id')->where('child_cat_id',$cat_id)->get();
                         $hard_types_count = $hard_type_ids->count();
                         ?>
<?php if($hard_types_count > 0): ?>                         
<div class="accordion"> 
  <div class="accordion-item">
    <div class="accordion-item-header">
    <?php if(app()->getLocale() == 'ar'): ?>
    مواصفات القرص الصلب 
    <?php else: ?>
     Hard Drive Type
     <?php endif; ?>
    </div><!-- /.accordion-item-header -->
    <div class="accordion-item-body">
      <div class="accordion-item-body-content">       
           <?php $hardTypes = \App\Models\HardType::all(); ?>
           <?php $__currentLoopData = $hardTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hardType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>     
           <?php if(app()->getLocale() == 'ar'): ?>
           <div class="form-group"> <input class="hard_type_check" type="checkbox" value="<?php echo e($hardType->slug); ?>" id="<?php echo e($hardType->slug); ?>"> <label for="25"><?php echo e($hardType->title_ar); ?></label> </div>
           <?php else: ?>                  
            <div class="form-group"> <input class="hard_type_check" type="checkbox" value="<?php echo e($hardType->slug); ?>" id="<?php echo e($hardType->slug); ?>"> <label for="25"><?php echo e($hardType->title); ?></label> </div>
            <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div><!-- /.accordion-item-body -->
  </div><!-- /.accordion-item -->
</div>
<?php endif; ?>
<?php  
                           $hard_capacity_ids = \App\Models\Product::whereNotNull('hard_capacity_id')->where('child_cat_id',$cat_id)->get();
                         ?>
<?php if($hard_capacity_ids->count() > 0): ?>                       
<div class="accordion"> 
  <div class="accordion-item">
    <div class="accordion-item-header">
    <?php if(app()->getLocale() == 'ar'): ?>
    سعة التخزين
    <?php endif; ?>
    </div><!-- /.accordion-item-header -->
    <div class="accordion-item-body">
      <div class="accordion-item-body-content">                               
            <?php $hardCapcities = \App\Models\HardCapacity::all(); ?>
            <?php $__currentLoopData = $hardCapcities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hardCapcity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <?php if(app()->getLocale() == 'ar'): ?>
            <div class="form-group"> <input class="hard_capcity_check" type="checkbox" value="<?php echo e($hardCapcity->slug); ?>" id="<?php echo e($hardCapcity->slug); ?>"> <label for="25"><?php echo e($hardCapcity->title_ar); ?></label> </div>          
            <?php else: ?>
            <div class="form-group"> <input class="hard_capcity_check" type="checkbox" value="<?php echo e($hardCapcity->slug); ?>" id="<?php echo e($hardCapcity->slug); ?>"> <label for="25"><?php echo e($hardCapcity->title); ?></label> </div>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div><!-- /.accordion-item-body -->
  </div><!-- /.accordion-item -->
</div>
<?php endif; ?>    
<?php  
                           $installed_ram_ids = \App\Models\Product::whereNotNull('installed_ram_id')->where('child_cat_id',$cat_id)->get();
                         ?>
<?php if($installed_ram_ids->count() > 0): ?>                       
<div class="accordion"> 
  <div class="accordion-item">
    <div class="accordion-item-header">
    <?php if(app()->getLocale() == 'ar'): ?>
   سعة التخزين
    <?php else: ?>  
    RAM Capcity
    <?php endif; ?>
    </div><!-- /.accordion-item-header -->
    <div class="accordion-item-body">
      <div class="accordion-item-body-content">                               
            <?php $ramCapcities = \App\Models\InstalledRAM::all(); ?>
            <?php $__currentLoopData = $ramCapcities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ramCapcity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <?php if(app()->getLocale() == 'ar'): ?>
            <div class="form-group"> <input class="ram_capcity_check" type="checkbox" value="<?php echo e($ramCapcity->slug); ?>" id="<?php echo e($ramCapcity->slug); ?>"> <label for="25"><?php echo e($ramCapcity->title_ar); ?></label> </div>          
            <?php else: ?>
            <div class="form-group"> <input class="ram_capcity_check" type="checkbox" value="<?php echo e($ramCapcity->slug); ?>" id="<?php echo e($ramCapcity->slug); ?>"> <label for="25"><?php echo e($ramCapcity->title); ?></label> </div>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div><!-- /.accordion-item-body -->
  </div><!-- /.accordion-item -->
</div>
<?php endif; ?>    
<?php                     $cpu_type_ids = \App\Models\Product::whereNotNull('cpu_type_id')
                              ->where('child_cat_id',$cat_id)->get();
                         ?>
<?php if($cpu_type_ids->count() > 0): ?>                        
<div class="accordion"> 
  <div class="accordion-item">
    <div class="accordion-item-header">
    <?php if(app()->getLocale() == 'ar'): ?>
    فئة المعالج
    <?php else: ?>
    Processor Core
    <?php endif; ?>
    </div><!-- /.accordion-item-header -->
    <div class="accordion-item-body">
      <div class="accordion-item-body-content">             
            <?php $cpuTypes = \App\Models\CpuType::all(); ?>
            <?php $__currentLoopData = $cpuTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cpuType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(app()->getLocale() == 'ar'): ?>
            <div class="form-group"> <input class="cpu_type_check" type="checkbox" value="<?php echo e($cpuType->slug); ?>" id="<?php echo e($cpuType->slug); ?>"> <label for="25"><?php echo e($cpuType->title_ar); ?></label> </div>
            <?php else: ?>
            <div class="form-group"> <input class="cpu_type_check" type="checkbox" value="<?php echo e($cpuType->slug); ?>" id="<?php echo e($cpuType->slug); ?>"> <label for="25"><?php echo e($cpuType->title); ?></label> </div>            
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div><!-- /.accordion-item-body -->
  </div><!-- /.accordion-item -->
</div>
<?php endif; ?>                   
<?php                     $graphics_corprocessor_ids = \App\Models\Product::where(function($q){
                         return $q->whereNotNull('graphics_corprocessor_id')
                               ->orWhereNotNull('cat_id');
                        })->where('cat_id',$cat_id)->get();
                         ?>
<?php if($graphics_corprocessor_ids->count() > 0): ?>                         
<div class="accordion"> 
  <div class="accordion-item">
    <div class="accordion-item-header">
    <?php if(app()->getLocale() == 'ar'): ?>
    معالج الرسومات 
    <?php else: ?>
    Graphics Coprocessor
    <?php endif; ?>
    </div><!-- /.accordion-item-header -->
    <div class="accordion-item-body">
      <div class="accordion-item-body-content">                         
            <?php $graphicCoprocessors = \App\Models\GraphicsCoprocessor::all(); ?>
            <?php $__currentLoopData = $graphicCoprocessors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $graphicCoprocessor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(app()->getLocale() == 'ar'): ?>
            <div class="form-group"> <input class="graphic_coprocessor_check" type="checkbox" value="<?php echo e($graphicCoprocessor->slug); ?>" id="<?php echo e($graphicCoprocessor->slug); ?>"> <label for="25"><?php echo e($graphicCoprocessor->title_ar); ?></label> </div>
            <?php else: ?>
            <div class="form-group"> <input class="graphic_coprocessor_check" type="checkbox" value="<?php echo e($graphicCoprocessor->slug); ?>" id="<?php echo e($graphicCoprocessor->slug); ?>"> <label for="25"><?php echo e($graphicCoprocessor->title); ?></label> </div>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div><!-- /.accordion-item-body -->
  </div><!-- /.accordion-item -->
</div>
<?php endif; ?>      
<?php                     $display_types_ids = \App\Models\Product::whereNotNull('display_type_id')
                        ->where('child_cat_id',$cat_id)->get();
                         ?>
<?php if($display_types_ids->count() > 0): ?>                        
<div class="accordion"> 
  <div class="accordion-item">
    <div class="accordion-item-header">
    <?php if(app()->getLocale() == 'ar'): ?>
    نوع العرض
    <?php else: ?>
     Display Type
     <?php endif; ?>
    </div><!-- /.accordion-item-header -->
    <div class="accordion-item-body">
      <div class="accordion-item-body-content">       
            <?php $displayTypes = \App\Models\DisplayType::all(); ?>
            <?php $__currentLoopData = $displayTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $displayType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(app()->getLocale() == 'ar'): ?>
            <div class="form-group"> <input class="display_type_check" type="checkbox" value="<?php echo e($displayType->slug); ?>" id="<?php echo e($displayType->slug); ?>"> <label for="25"><?php echo e($displayType->title_ar); ?></label> </div>
            <?php else: ?>
            <div class="form-group"> <input class="display_type_check" type="checkbox" value="<?php echo e($displayType->slug); ?>" id="<?php echo e($displayType->slug); ?>"> <label for="25"><?php echo e($displayType->title); ?></label> </div>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div><!-- /.accordion-item-body -->
  </div><!-- /.accordion-item -->
</div>
<?php endif; ?>   
<?php                     $conn_tech_ids = \App\Models\Product::whereNotNull('conn_tech_id')
                        ->where('child_cat_id',$cat_id)->get();
                         ?>
<?php if($conn_tech_ids->count() > 0 ): ?>                    
<div class="accordion"> 
  <div class="accordion-item">
    <div class="accordion-item-header">
    <?php if(app()->getLocale() == 'ar'): ?>
    تقنية الاتصال
    <?php else: ?>
    Connectivity Technology
    <?php endif; ?>
    </div><!-- /.accordion-item-header -->
    <div class="accordion-item-body">
      <div class="accordion-item-body-content">       
            <?php $connTechs= \App\Models\ConnectivityTechnology::all(); ?>
            <?php $__currentLoopData = $connTechs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $connTech): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(app()->getLocale() == 'ar'): ?>
            <div class="form-group"> <input class="conn_tech_check" type="checkbox" value="<?php echo e($connTech->slug); ?>" id="<?php echo e($connTech->slug); ?>"> <label for="25"><?php echo e($connTech->title_ar); ?></label> </div>
            <?php else: ?>
            <div class="form-group"> <input class="conn_tech_check" type="checkbox" value="<?php echo e($connTech->slug); ?>" id="<?php echo e($connTech->slug); ?>"> <label for="25"><?php echo e($connTech->title); ?></label> </div>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div><!-- /.accordion-item-body -->
  </div><!-- /.accordion-item -->
</div>
<?php endif; ?>     
<?php                     $natv_res_ids = \App\Models\Product::whereNotNull('native_resolution_id')
                               ->where('cat_id',$cat_id)->get();
                         ?>
<?php if($natv_res_ids->count() > 0): ?>                      
<div class="accordion"> 
  <div class="accordion-item">
    <div class="accordion-item-header">
    <?php if(app()->getLocale() == 'ar'): ?>
    الدقة الأصلية
    <?php else: ?>
    Native Resolution
    <?php endif; ?>
    </div><!-- /.accordion-item-header -->
    <div class="accordion-item-body">
      <div class="accordion-item-body-content">       
            <?php $natvResloutions= \App\Models\NativeResolution::all(); ?>
            <?php $__currentLoopData = $natvResloutions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $natvRes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(app()->getLocale() == 'ar'): ?>
            <div class="form-group"> <input class="natv_res_check" type="checkbox" value="<?php echo e($natvRes->slug); ?>" id="<?php echo e($natvRes->slug); ?>"> <label for="25"><?php echo e($natvRes->title_ar); ?></label> </div>
            <?php else: ?>
            <div class="form-group"> <input class="natv_res_check" type="checkbox" value="<?php echo e($natvRes->slug); ?>" id="<?php echo e($natvRes->slug); ?>"> <label for="25"><?php echo e($natvRes->title); ?></label> </div>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div><!-- /.accordion-item-body -->
  </div><!-- /.accordion-item -->
</div>
<?php endif; ?>     
<?php                     $inc_comp_ids = \App\Models\Product::whereNotNull('inc_comp_id')
                       ->where('child_cat_id',$cat_id)->get();
                         ?>
<?php if($inc_comp_ids->count() > 0): ?>                          
<div class="accordion"> 
  <div class="accordion-item">
    <div class="accordion-item-header">
    <?php if(app()->getLocale() == 'ar'): ?>
    المكونات الاضافية
    <?php else: ?>  
    Include Components
    <?php endif; ?>
    </div><!-- /.accordion-item-header -->
    <div class="accordion-item-body">
      <div class="accordion-item-body-content">       
            <?php $incCompnents= \App\Models\IncludeComponents::all(); ?>
            <?php $__currentLoopData = $incCompnents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $incComp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(app()->getLocale() == 'ar'): ?>
            <div class="form-group"> <input class="inc_comp_check" type="checkbox" value="<?php echo e($incComp->slug); ?>" id="<?php echo e($incComp->slug); ?>"> <label for="25"><?php echo e($incComp->title_ar); ?></label> </div>
            <?php else: ?>
            <div class="form-group"> <input class="inc_comp_check" type="checkbox" value="<?php echo e($incComp->slug); ?>" id="<?php echo e($incComp->slug); ?>"> <label for="25"><?php echo e($incComp->title); ?></label> </div>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div><!-- /.accordion-item-body -->
  </div><!-- /.accordion-item -->
</div>
<?php endif; ?>  
<?php                     $display_res_ids = \App\Models\Product::whereNotNull('display_res_id')
                              ->where('cat_id',$cat_id)->get();
                         ?>
<?php if($display_res_ids->count() > 0): ?>                          
<div class="accordion"> 
  <div class="accordion-item">
    <div class="accordion-item-header">
    <?php if(app()->getLocale() == 'ar'): ?>
    دقة الشاشة
    <?php else: ?>
    Monitor Display Resolution
    <?php endif; ?>
    </div><!-- /.accordion-item-header -->
    <div class="accordion-item-body">
      <div class="accordion-item-body-content">       
            <?php $displayResolutions= \App\Models\DisplayResolution::all(); ?>
            <?php $__currentLoopData = $displayResolutions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $displayResolution): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(app()->getLocale() == 'ar'): ?>
            <div class="form-group"> <input class="display_res_check" type="checkbox" value="<?php echo e($displayResolution->slug); ?>" id="<?php echo e($displayResolution->slug); ?>"> <label for="25"><?php echo e($displayResolution->title_ar); ?></label> </div>
            <?php else: ?>
            <div class="form-group"> <input class="display_res_check" type="checkbox" value="<?php echo e($displayResolution->slug); ?>" id="<?php echo e($displayResolution->slug); ?>"> <label for="25"><?php echo e($displayResolution->title); ?></label> </div>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div><!-- /.accordion-item-body -->
  </div><!-- /.accordion-item -->
</div>
<?php endif; ?>    
<?php                     $screen_size_ids = \App\Models\Product::where(function($q){
                         return $q->whereNotNull('screen_size_id')
                               ->orWhereNotNull('cat_id');
                        })->where('cat_id',$cat_id)->get();
                         ?>
<?php if($screen_size_ids->count() > 0): ?>                          
<div class="accordion"> 
  <div class="accordion-item">
    <div class="accordion-item-header">
    <?php if(app()->getLocale() == 'ar'): ?>
    حجم الشاشة
    <?php else: ?>
    Screen Size
    <?php endif; ?>
    </div><!-- /.accordion-item-header -->
    <div class="accordion-item-body">
      <div class="accordion-item-body-content">       
            <?php $screenSizes= \App\Models\ScreenSize::all(); ?>
            <?php $__currentLoopData = $screenSizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $screenSize): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(app()->getLocale() == 'ar'): ?>
            <div class="form-group"> <input class="screen_size_check" type="checkbox" value="<?php echo e($screenSize->slug); ?>" id="<?php echo e($screenSize->slug); ?>"> <label for="25"><?php echo e($screenSize->title_ar); ?></label> </div>
            <?php else: ?>
            <div class="form-group"> <input class="screen_size_check" type="checkbox" value="<?php echo e($screenSize->slug); ?>" id="<?php echo e($screenSize->slug); ?>"> <label for="25"><?php echo e($screenSize->title); ?></label> </div>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div><!-- /.accordion-item-body -->
  </div><!-- /.accordion-item -->
</div>
<?php endif; ?>
<?php                     $monitor_feature_ids = \App\Models\Product::where(function($q){
                         return $q->whereNotNull('monitor_feature_id')
                               ->orWhereNotNull('cat_id');
                        })->where('cat_id',$cat_id)->get();
                         ?>
<?php if($monitor_feature_ids->count() > 0): ?>                          
<div class="accordion"> 
  <div class="accordion-item">
    <div class="accordion-item-header">
    <?php if(app()->getLocale() == 'ar'): ?>
    خصائص الشاشة
    <?php else: ?> 
    Monitors Features
    <?php endif; ?>
    </div><!-- /.accordion-item-header -->
    <div class="accordion-item-body">
      <div class="accordion-item-body-content">       
            <?php $monitorFeatures= \App\Models\MonitorFeatures::all(); ?>
            <?php $__currentLoopData = $monitorFeatures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $monitorFeature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(app()->getLocale() == 'ar'): ?>
            <div class="form-group"> <input class="screen_size_check" type="checkbox" value="<?php echo e($monitorFeature->slug); ?>" id="<?php echo e($monitorFeature->slug); ?>"> <label for="25"><?php echo e($monitorFeature->title_ar); ?></label> </div>
            <?php else: ?>
            <div class="form-group"> <input class="screen_size_check" type="checkbox" value="<?php echo e($monitorFeature->slug); ?>" id="<?php echo e($monitorFeature->slug); ?>"> <label for="25"><?php echo e($monitorFeature->title); ?></label> </div>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div><!-- /.accordion-item-body -->
  </div><!-- /.accordion-item -->
</div>
<?php endif; ?>  
<?php                     $product_length_ids = \App\Models\Product::whereNotNull('product_length_id')->where('cat_id',$cat_id)->WhereNotNull('cat_id')->orwhere('child_cat_id',$cat_id)->whereNotNull('child_cat_id')->get();
                         ?>
<?php if($product_length_ids->count() > 0): ?>                          
<div class="accordion"> 
  <div class="accordion-item">
    <div class="accordion-item-header">
    طول المنتج
    </div><!-- /.accordion-item-header -->
    <div class="accordion-item-body">
      <div class="accordion-item-body-content">       
            <?php $productLengths= \App\Models\ProductLength::all(); ?>
            <?php $__currentLoopData = $productLengths; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productLength): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(app()->getLocale() == 'ar'): ?>
            <div class="form-group"> <input class="product_length_check" type="checkbox" value="<?php echo e($productLength->slug); ?>" id="<?php echo e($productLength->slug); ?>"> <label for="25"><?php echo e($productLength->title_ar); ?></label> </div>
            <?php else: ?>
            <div class="form-group"> <input class="product_length_check" type="checkbox" value="<?php echo e($productLength->slug); ?>" id="<?php echo e($productLength->slug); ?>"> <label for="25"><?php echo e($productLength->title); ?></label> </div>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div><!-- /.accordion-item-body -->
  </div><!-- /.accordion-item -->
</div>
<?php endif; ?>         
<?php                     $brands_ids = \App\Models\Product::whereNotNull('brand_id')->where('cat_id',$cat_id)->WhereNotNull('cat_id')->orwhere('child_cat_id',$cat_id)->whereNotNull('child_cat_id')->get();
                         ?>
<?php if($brands_ids->count() > 0): ?>                                                                                               
<div class="accordion">
  <div class="accordion-item">
    <div class="accordion-item-header">
    <?php if(app()->getLocale() == 'ar'): ?>
    البراند
    <?php else: ?>
      Brand
    <?php endif; ?>
    </div><!-- /.accordion-item-header -->
    <div class="accordion-item-body">
      <div class="accordion-item-body-content">        
            <?php $brands = \App\Models\Brand::all(); ?>
            <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(app()->getLocale() == 'ar'): ?>
            <div class="form-group"> <input class="brand_check" type="checkbox" value="<?php echo e($brand->slug); ?>" id="<?php echo e($brand->slug); ?>"> <label for="25"><?php echo e($brand->title_ar); ?></label> </div>
            <?php else: ?>
            <div class="form-group"> <input class="brand_check" type="checkbox" value="<?php echo e($brand->slug); ?>" id="<?php echo e($brand->slug); ?>"> <label for="25"><?php echo e($brand->title); ?></label> </div>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div><!-- /.accordion-item-body -->
  </div><!-- /.accordion-item -->
</div>
<?php endif; ?>
<div class="accordion">
  <div class="accordion-item">
    <div class="accordion-item-header text-primary-700">
    <?php if(app()->getLocale() == 'ar'): ?>
    الفئة
    <?php else: ?>
      Category
    <?php endif; ?>
    </div><!-- /.accordion-item-header -->
    <div class="accordion-item-body">
      <div class="accordion-item-body-content">
      <?php
                        $category = \App\Models\Category::where('id',$cat_id)->first();
                        ?>
                        <?php if(app()->getLocale() == 'ar'): ?>
                        <div class="form-group"> <input class="category_check" type="checkbox" value="<?php echo e($category->id); ?>" id="<?php echo e($category->id); ?>"> <label for="25"><?php echo e($category->title_ar); ?></label> </div>
                        <?php else: ?>    
                        <div class="form-group"> <input class="category_check" type="checkbox" value="<?php echo e($category->id); ?>" id="<?php echo e($category->id); ?>"> <label for="25"><?php echo e($category->title); ?></label> </div>
                        <?php endif; ?>               
      </div>
    </div><!-- /.accordion-item-body -->
  </div><!-- /.accordion-item -->
</div>                
                   
                
                    </div>
                 </div>
  <?php else: ?>
  
                 <div id="store" class="col-md-3">
              
                    <div class="CategoryPage__filters sidebar" id="sidebar">
                    <h2 class="text-primary-700 text-3xl font-display font-bold antialiased mb-5 relative" style="margin-left: 16%;">
                    <?php if(app()->getLocale() == 'ar'): ?>
                    تسوق حسب
                    <?php else: ?>
                        Filter by
                    <?php endif; ?>
                    </h2>
                     <div class="accordion">
  <div class="accordion-item">
    <div class="accordion-item-header">
      Price
     </div> 
    <!-- /.accordion-item-header -->
  <div class="accordion-item-body">
      <div class="accordion-item-body-content">
      <!--<span id="slider_value2" style="color:red;font-weight:bold;"></span><br>-->
      <!--Rs. 0 <input type="range" min="0" max="5000" step="1" name="sld6" value="" onchange="show_value2(this.value)" tooltip="this.value"> Rs. 5000 -->
     <div class="d-flex">
    <div class="wrapper">
        <div class="slider">
        <div class="progress"></div>
      </div>
      <div class="range-input">
        <input type="range" class="range-min" min="0" max="5000" value="0" step="100">
        <input type="range" class="range-max" min="0" max="5000" value="5000" step="100">
      </div>
      <div class="price-input">
        <div class="field">
          <span>From</span>
          <input type="number" id="from" class="input-min" value="0" onchange="productPrice(this.value)">
           <span>Rs</span>
        </div>
        <div class="separator"></div>
        <div class="field" style="text-align:right;">
          <span>To</span>
          <input type="number" class="input-max" value="5000">
          <span>Rs</span>
        </div>
      </div>
      
    </div>

    
  </div>
      <!-- <span class="current-value">0</span> -->
       </div> 
     </div> 
    <!-- /.accordion-item-body -->
   </div> 
  <!-- /.accordion-item -->
 </div> 
<?php                     $os_ids = \App\Models\Product::whereNotNull('os_id')
                             ->where('child_cat_id',$cat_id)->get();
                         $os_ids_count = $os_ids->count();               
                         ?>
<?php if($os_ids_count > 0): ?>                        
<div class="accordion"> 
  <div class="accordion-item">
    <div class="accordion-item-header">
    <?php if(app()->getLocale() == 'ar'): ?>
    نظام التشغيل
    <?php else: ?>
      Operating System
     <?php endif; ?> 
    </div><!-- /.accordion-item-header -->
    <div class="accordion-item-body">
      <div class="accordion-item-body-content">                              
              <?php $osList = \App\Models\OperatingSystems::all(); ?>
              <?php $__currentLoopData = $osList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $os): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
              <?php if(app()->getLocale() == 'ar'): ?>
              <div class="form-group"> <input class="os_check" type="checkbox" value="<?php echo e($os->slug); ?>" id="<?php echo e($os->slug); ?>"> <label for="25"><?php echo e($os->title_ar); ?></label> </div>      
              <?php else: ?>     
             <div class="form-group"> <input class="os_check" type="checkbox" value="<?php echo e($os->slug); ?>" id="<?php echo e($os->slug); ?>"> <label for="25"><?php echo e($os->title); ?></label> </div>          
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div><!-- /.accordion-item-body -->
  </div><!-- /.accordion-item -->
</div>
<?php endif; ?>
<?php
               $hard_type_ids = \App\Models\Product::whereNotNull('hard_type_id')
                              ->where('child_cat_id',$cat_id)->get();
                         $hard_types_count = $hard_type_ids->count();
                         ?>
<?php if($hard_types_count > 0): ?>                         
<div class="accordion"> 
  <div class="accordion-item">
    <div class="accordion-item-header">
    <?php if(app()->getLocale() == 'ar'): ?>
    مواصفات القرص الصلب 
    <?php else: ?>
     Hard Drive Type
     <?php endif; ?>
    </div><!-- /.accordion-item-header -->
    <div class="accordion-item-body">
      <div class="accordion-item-body-content">       
           <?php $hardTypes = \App\Models\HardType::all(); ?>
           <?php $__currentLoopData = $hardTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hardType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>     
           <?php if(app()->getLocale() == 'ar'): ?>
           <div class="form-group"> <input class="hard_type_check" type="checkbox" value="<?php echo e($hardType->slug); ?>" id="<?php echo e($hardType->slug); ?>"> <label for="25"><?php echo e($hardType->title_ar); ?></label> </div>
           <?php else: ?>                  
            <div class="form-group"> <input class="hard_type_check" type="checkbox" value="<?php echo e($hardType->slug); ?>" id="<?php echo e($hardType->slug); ?>"> <label for="25"><?php echo e($hardType->title); ?></label> </div>
            <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div><!-- /.accordion-item-body -->
  </div><!-- /.accordion-item -->
</div>
<?php endif; ?>
<?php                     $installed_ram_ids = \App\Models\Product::whereNotNull('installed_ram_id')
                             ->where('child_cat_id',$cat_id)->get();
                         ?>
<?php if($installed_ram_ids->count() > 0): ?>                       
<div class="accordion"> 
  <div class="accordion-item">
    <div class="accordion-item-header">
    <?php if(app()->getLocale() == 'ar'): ?>
    سعة الرام
    <?php else: ?>  
    RAM Capcity
    <?php endif; ?>
    </div><!-- /.accordion-item-header -->
    <div class="accordion-item-body">
      <div class="accordion-item-body-content">                               
            <?php $ramCapcities = \App\Models\InstalledRAM::all(); ?>
            <?php $__currentLoopData = $ramCapcities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ramCapcity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <?php if(app()->getLocale() == 'ar'): ?>
            <div class="form-group"> <input class="ram_capcity_check" type="checkbox" value="<?php echo e($ramCapcity->slug); ?>" id="<?php echo e($ramCapcity->slug); ?>"> <label for="25"><?php echo e($ramCapcity->title_ar); ?></label> </div>          
            <?php else: ?>
            <div class="form-group"> <input class="ram_capcity_check" type="checkbox" value="<?php echo e($ramCapcity->slug); ?>" id="<?php echo e($ramCapcity->slug); ?>"> <label for="25"><?php echo e($ramCapcity->title); ?></label> </div>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div><!-- /.accordion-item-body -->
  </div><!-- /.accordion-item -->
</div>
<?php endif; ?>     
<?php  
                           $hard_capacity_ids = \App\Models\Product::where('hard_capacity_id','!=',0)->orWhereNotNull('hard_capacity_id')->where('child_cat_id',$cat_id)->get();
                         ?>
<?php if($hard_capacity_ids->count() > 0): ?>                       
<div class="accordion"> 
  <div class="accordion-item">
    <div class="accordion-item-header">
    Hard Disk Capcity
    </div><!-- /.accordion-item-header -->
    <div class="accordion-item-body">
      <div class="accordion-item-body-content">                               
            <?php $hardCapcities = \App\Models\HardCapacity::all(); ?>
            <?php $__currentLoopData = $hardCapcities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hardCapcity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <?php if(app()->getLocale() == 'ar'): ?>
            <div class="form-group"> <input class="hard_capcity_check" type="checkbox" value="<?php echo e($hardCapcity->slug); ?>" id="<?php echo e($hardCapcity->slug); ?>"> <label for="25"><?php echo e($hardCapcity->title_ar); ?></label> </div>          
            <?php else: ?>
            <div class="form-group"> <input class="hard_capcity_check" type="checkbox" value="<?php echo e($hardCapcity->slug); ?>" id="<?php echo e($hardCapcity->slug); ?>"> <label for="25"><?php echo e($hardCapcity->title); ?></label> </div>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div><!-- /.accordion-item-body -->
  </div><!-- /.accordion-item -->
</div>
<?php endif; ?>    
<?php                     $cpu_type_ids = \App\Models\Product::whereNotNull('cpu_type_id')
                               ->where('child_cat_id',$cat_id)->get();
                         ?>
<?php if($cpu_type_ids->count() > 0): ?>                        
<div class="accordion"> 
  <div class="accordion-item">
    <div class="accordion-item-header">
    <?php if(app()->getLocale() == 'ar'): ?>
    فئة المعالج
    <?php else: ?>
    Processor Core
    <?php endif; ?>
    </div><!-- /.accordion-item-header -->
    <div class="accordion-item-body">
      <div class="accordion-item-body-content">             
            <?php $cpuTypes = \App\Models\CpuType::all(); ?>
            <?php $__currentLoopData = $cpuTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cpuType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(app()->getLocale() == 'ar'): ?>
            <div class="form-group"> <input class="cpu_type_check" type="checkbox" value="<?php echo e($cpuType->slug); ?>" id="<?php echo e($cpuType->slug); ?>"> <label for="25"><?php echo e($cpuType->title_ar); ?></label> </div>
            <?php else: ?>
            <div class="form-group"> <input class="cpu_type_check" type="checkbox" value="<?php echo e($cpuType->slug); ?>" id="<?php echo e($cpuType->slug); ?>"> <label for="25"><?php echo e($cpuType->title); ?></label> </div>            
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div><!-- /.accordion-item-body -->
  </div><!-- /.accordion-item -->
</div>
<?php endif; ?>                   
<?php  $graphics_corprocessor_ids = \App\Models\Product::whereNotNull('graphics_corprocessor_id')
                         ->where('cat_id',$cat_id)
                         ->get(); 
                         ?>
<?php if($graphics_corprocessor_ids->count() > 0): ?>                         
<div class="accordion"> 
  <div class="accordion-item">
    <div class="accordion-item-header">
    <?php if(app()->getLocale() == 'ar'): ?>
    معالج الرسومات 
    <?php else: ?>
    Graphics Coprocessor
    <?php endif; ?>
    </div><!-- /.accordion-item-header -->
    <div class="accordion-item-body">
      <div class="accordion-item-body-content">                         
            <?php $graphicCoprocessors = \App\Models\GraphicsCoprocessor::all(); ?>
            <?php $__currentLoopData = $graphicCoprocessors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $graphicCoprocessor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(app()->getLocale() == 'ar'): ?>
            <div class="form-group"> <input class="graphic_coprocessor_check" type="checkbox" value="<?php echo e($graphicCoprocessor->slug); ?>" id="<?php echo e($graphicCoprocessor->slug); ?>"> <label for="25"><?php echo e($graphicCoprocessor->title_ar); ?></label> </div>
            <?php else: ?>
            <div class="form-group"> <input class="graphic_coprocessor_check" type="checkbox" value="<?php echo e($graphicCoprocessor->slug); ?>" id="<?php echo e($graphicCoprocessor->slug); ?>"> <label for="25"><?php echo e($graphicCoprocessor->title); ?></label> </div>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div><!-- /.accordion-item-body -->
  </div><!-- /.accordion-item -->
</div>
<?php endif; ?>      
<?php  $display_types_ids = \App\Models\Product::whereNotNull('display_type_id')
                         ->where('child_cat_id',$cat_id)
                         ->get(); 
                         ?>
<?php if($display_types_ids->count() > 0): ?>                        
<div class="accordion"> 
  <div class="accordion-item">
    <div class="accordion-item-header">
    <?php if(app()->getLocale() == 'ar'): ?>
    نوع العرض
    <?php else: ?>
     Display Type
     <?php endif; ?>
    </div><!-- /.accordion-item-header -->
    <div class="accordion-item-body">
      <div class="accordion-item-body-content">       
            <?php $displayTypes = \App\Models\DisplayType::all(); ?>
            <?php $__currentLoopData = $displayTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $displayType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(app()->getLocale() == 'ar'): ?>
            <div class="form-group"> <input class="display_type_check" type="checkbox" value="<?php echo e($displayType->slug); ?>" id="<?php echo e($displayType->slug); ?>"> <label for="25"><?php echo e($displayType->title_ar); ?></label> </div>
            <?php else: ?>
            <div class="form-group"> <input class="display_type_check" type="checkbox" value="<?php echo e($displayType->slug); ?>" id="<?php echo e($displayType->slug); ?>"> <label for="25"><?php echo e($displayType->title); ?></label> </div>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div><!-- /.accordion-item-body -->
  </div><!-- /.accordion-item -->
</div>
<?php endif; ?>   
<?php  $conn_tech_ids = \App\Models\Product::whereNotNull('conn_tech_id')
                         ->where('child_cat_id',$cat_id)
                         ->get();                          
                         ?>
<?php if($conn_tech_ids->count() > 0 ): ?>                    
<div class="accordion"> 
  <div class="accordion-item">
    <div class="accordion-item-header">
    <?php if(app()->getLocale() == 'ar'): ?>
    تقنية الاتصال
    <?php else: ?>
    Connectivity Technology
    <?php endif; ?>
    </div><!-- /.accordion-item-header -->
    <div class="accordion-item-body">
      <div class="accordion-item-body-content">       
            <?php $connTechs= \App\Models\ConnectivityTechnology::all(); ?>
            <?php $__currentLoopData = $connTechs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $connTech): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(app()->getLocale() == 'ar'): ?>
            <div class="form-group"> <input class="conn_tech_check" type="checkbox" value="<?php echo e($connTech->slug); ?>" id="<?php echo e($connTech->slug); ?>"> <label for="25"><?php echo e($connTech->title_ar); ?></label> </div>
            <?php else: ?>
            <div class="form-group"> <input class="conn_tech_check" type="checkbox" value="<?php echo e($connTech->slug); ?>" id="<?php echo e($connTech->slug); ?>"> <label for="25"><?php echo e($connTech->title); ?></label> </div>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div><!-- /.accordion-item-body -->
  </div><!-- /.accordion-item -->
</div>
<?php endif; ?>     
<?php  $natv_res_ids = \App\Models\Product::whereNotNull('native_resolution_id')
                        ->where('cat_id',$cat_id)
                        ->get(); 
                         ?>
<?php if($natv_res_ids->count() > 0): ?>                      
<div class="accordion"> 
  <div class="accordion-item">
    <div class="accordion-item-header">
    <?php if(app()->getLocale() == 'ar'): ?>
    الدقة الأصلية
    <?php else: ?>
    Native Resolution
    <?php endif; ?>
    </div><!-- /.accordion-item-header -->
    <div class="accordion-item-body">
      <div class="accordion-item-body-content">       
            <?php $natvResloutions= \App\Models\NativeResolution::all(); ?>
            <?php $__currentLoopData = $natvResloutions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $natvRes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(app()->getLocale() == 'ar'): ?>
            <div class="form-group"> <input class="natv_res_check" type="checkbox" value="<?php echo e($natvRes->slug); ?>" id="<?php echo e($natvRes->slug); ?>"> <label for="25"><?php echo e($natvRes->title_ar); ?></label> </div>
            <?php else: ?>
            <div class="form-group"> <input class="natv_res_check" type="checkbox" value="<?php echo e($natvRes->slug); ?>" id="<?php echo e($natvRes->slug); ?>"> <label for="25"><?php echo e($natvRes->title); ?></label> </div>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div><!-- /.accordion-item-body -->
  </div><!-- /.accordion-item -->
</div>
<?php endif; ?>     
<?php  $inc_comp_ids = \App\Models\Product::whereNotNull('inc_comp_id')
                         ->where('child_cat_id',$cat_id)
                         ->get(); 
                         ?>
<?php if($inc_comp_ids->count() > 0): ?>                          
<div class="accordion"> 
  <div class="accordion-item">
    <div class="accordion-item-header">
    <?php if(app()->getLocale() == 'ar'): ?>
    المكونات الاضافية
    <?php else: ?>  
    Include Components
    <?php endif; ?>
    </div><!-- /.accordion-item-header -->
    <div class="accordion-item-body">
      <div class="accordion-item-body-content">       
            <?php $incCompnents= \App\Models\IncludeComponents::all(); ?>
            <?php $__currentLoopData = $incCompnents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $incComp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(app()->getLocale() == 'ar'): ?>
            <div class="form-group"> <input class="inc_comp_check" type="checkbox" value="<?php echo e($incComp->slug); ?>" id="<?php echo e($incComp->slug); ?>"> <label for="25"><?php echo e($incComp->title_ar); ?></label> </div>
            <?php else: ?>
            <div class="form-group"> <input class="inc_comp_check" type="checkbox" value="<?php echo e($incComp->slug); ?>" id="<?php echo e($incComp->slug); ?>"> <label for="25"><?php echo e($incComp->title); ?></label> </div>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div><!-- /.accordion-item-body -->
  </div><!-- /.accordion-item -->
</div>
<?php endif; ?>  
<?php  $display_res_ids = \App\Models\Product::whereNotNull('display_res_id')
                         ->where('cat_id',$cat_id)
                         ->get(); 
                         ?>
<?php if($display_res_ids->count() > 0): ?>                          
<div class="accordion"> 
  <div class="accordion-item">
    <div class="accordion-item-header">
    <?php if(app()->getLocale() == 'ar'): ?>
    دقة الشاشة
    <?php else: ?>
    Monitor Display Resolution
    <?php endif; ?>
    </div><!-- /.accordion-item-header -->
    <div class="accordion-item-body">
      <div class="accordion-item-body-content">       
            <?php $displayResolutions= \App\Models\DisplayResolution::all(); ?>
            <?php $__currentLoopData = $displayResolutions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $displayResolution): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(app()->getLocale() == 'ar'): ?>
            <div class="form-group"> <input class="display_res_check" type="checkbox" value="<?php echo e($displayResolution->slug); ?>" id="<?php echo e($displayResolution->slug); ?>"> <label for="25"><?php echo e($displayResolution->title_ar); ?></label> </div>
            <?php else: ?>
            <div class="form-group"> <input class="display_res_check" type="checkbox" value="<?php echo e($displayResolution->slug); ?>" id="<?php echo e($displayResolution->slug); ?>"> <label for="25"><?php echo e($displayResolution->title); ?></label> </div>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div><!-- /.accordion-item-body -->
  </div><!-- /.accordion-item -->
</div>
<?php endif; ?>    
<?php  $screen_size_ids = \App\Models\Product::whereNotNull('screen_size_id')
                         ->where('cat_id',$cat_id)
                         ->get(); 
                         ?>
<?php if($screen_size_ids->count() > 0): ?>                          
<div class="accordion"> 
  <div class="accordion-item">
    <div class="accordion-item-header">
    <?php if(app()->getLocale() == 'ar'): ?>
    حجم الشاشة
    <?php else: ?>
    Screen Size
    <?php endif; ?>
    </div><!-- /.accordion-item-header -->
    <div class="accordion-item-body">
      <div class="accordion-item-body-content">       
            <?php $screenSizes= \App\Models\ScreenSize::all(); ?>
            <?php $__currentLoopData = $screenSizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $screenSize): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(app()->getLocale() == 'ar'): ?>
            <div class="form-group"> <input class="screen_size_check" type="checkbox" value="<?php echo e($screenSize->slug); ?>" id="<?php echo e($screenSize->slug); ?>"> <label for="25"><?php echo e($screenSize->title_ar); ?></label> </div>
            <?php else: ?>
            <div class="form-group"> <input class="screen_size_check" type="checkbox" value="<?php echo e($screenSize->slug); ?>" id="<?php echo e($screenSize->slug); ?>"> <label for="25"><?php echo e($screenSize->title); ?></label> </div>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div><!-- /.accordion-item-body -->
  </div><!-- /.accordion-item -->
</div>
<?php endif; ?>
<?php  $monitor_feature_ids = \App\Models\Product::whereNotNull('monitor_feature_id')
                         ->where('cat_id',$cat_id)
                         ->get(); 
                         ?>
<?php if($monitor_feature_ids->count() > 0): ?>                          
<div class="accordion"> 
  <div class="accordion-item">
    <div class="accordion-item-header">
    <?php if(app()->getLocale() == 'ar'): ?>
    خصائص الشاشة
    <?php else: ?> 
    Monitors Features
    <?php endif; ?>
    </div><!-- /.accordion-item-header -->
    <div class="accordion-item-body">
      <div class="accordion-item-body-content">       
            <?php $monitorFeatures= \App\Models\MonitorFeatures::all(); ?>
            <?php $__currentLoopData = $monitorFeatures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $monitorFeature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(app()->getLocale() == 'ar'): ?>
            <div class="form-group"> <input class="monitor_feature_check" type="checkbox" value="<?php echo e($monitorFeature->slug); ?>" id="<?php echo e($monitorFeature->slug); ?>"> <label for="25"><?php echo e($monitorFeature->title_ar); ?></label> </div>
            <?php else: ?>
            <div class="form-group"> <input class="monitor_feature_check" type="checkbox" value="<?php echo e($monitorFeature->slug); ?>" id="<?php echo e($monitorFeature->slug); ?>"> <label for="25"><?php echo e($monitorFeature->title); ?></label> </div>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div><!-- /.accordion-item-body -->
  </div><!-- /.accordion-item -->
</div>
<?php endif; ?>     
<?php  $product_length_ids = \App\Models\Product::whereNotNull('product_length_id')
                         ->where('cat_id',$cat_id)
                         ->get(); 
                         ?>
<?php if($product_length_ids->count() > 0): ?>                          
<div class="accordion"> 
  <div class="accordion-item">
    <div class="accordion-item-header">
    <?php if(app()->getLocale() == 'ar'): ?>
    طول المنتج
    <?php else: ?>
    Product Length
    <?php endif; ?>
    </div><!-- /.accordion-item-header -->
    <div class="accordion-item-body">
      <div class="accordion-item-body-content">       
            <?php $productLengths= \App\Models\ProductLength::all(); ?>
            <?php $__currentLoopData = $productLengths; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productLength): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(app()->getLocale() == 'ar'): ?>
            <div class="form-group"> <input class="product_length_check" type="checkbox" value="<?php echo e($productLength->slug); ?>" id="<?php echo e($productLength->slug); ?>"> <label for="25"><?php echo e($productLength->title_ar); ?></label> </div>
            <?php else: ?>
            <div class="form-group"> <input class="product_length_check" type="checkbox" value="<?php echo e($productLength->slug); ?>" id="<?php echo e($productLength->slug); ?>"> <label for="25"><?php echo e($productLength->title); ?></label> </div>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div><!-- /.accordion-item-body -->
  </div><!-- /.accordion-item -->
</div>
<?php endif; ?>         
<?php                     $brands_ids = \App\Models\Product::where(function($q){
                         return $q->whereNotNull('brand_id')
                               ->orWhereNotNull('cat_id')
                               ->orWhereNotNull('child_cat_id')
                               ->orWhereNotNull('child_child_cat_id');
                        })->distinct()->where('cat_id',$cat_id)->orWhere('child_cat_id',$cat_id)->orWhere('child_child_cat_id',$cat_id)->get();
                         ?>
<?php if($brands_ids->count() > 0): ?>                                                                                               
<div class="accordion">
  <div class="accordion-item">
    <div class="accordion-item-header">
    <?php if(app()->getLocale() == 'ar'): ?>
    البراند
    <?php else: ?>
      Brand
    <?php endif; ?>
    </div><!-- /.accordion-item-header -->
    <div class="accordion-item-body">
      <div class="accordion-item-body-content">        
            <?php $brands = \App\Models\Brand::all(); ?>
            <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(app()->getLocale() == 'ar'): ?>
            <div class="form-group"> <input class="brand_check" type="checkbox" value="<?php echo e($brand->slug); ?>" id="<?php echo e($brand->slug); ?>"> <label for="25"><?php echo e($brand->title_ar); ?></label> </div>
            <?php else: ?>
            <div class="form-group"> <input class="brand_check" type="checkbox" value="<?php echo e($brand->slug); ?>" id="<?php echo e($brand->slug); ?>"> <label for="25"><?php echo e($brand->title); ?></label> </div>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div><!-- /.accordion-item-body -->
  </div><!-- /.accordion-item -->
</div>
<?php endif; ?>
<div class="accordion">
  <div class="accordion-item">
    <div class="accordion-item-header">
    <?php if(app()->getLocale() == 'ar'): ?>
    الفئة
    <?php else: ?>
      Category
    <?php endif; ?>
    </div><!-- /.accordion-item-header -->
    <div class="accordion-item-body">
      <div class="accordion-item-body-content">
      <?php
                        $category = \App\Models\Category::where('id',$cat_id)->first();
                        ?>
                        <?php if(app()->getLocale() == 'ar'): ?>
                        <div class="form-group"> <input class="category_check" type="checkbox" value="<?php echo e($category->id); ?>" id="<?php echo e($category->id); ?>"> <label for="25"><?php echo e($category->title_ar); ?></label> </div>
                        <?php else: ?>    
                        <div class="form-group"> <input class="category_check" type="checkbox" value="<?php echo e($category->id); ?>" id="<?php echo e($category->id); ?>"> <label for="25"><?php echo e($category->title); ?></label> </div>
                        <?php endif; ?>       
                        
      </div>
    </div><!-- /.accordion-item-body -->
  </div><!-- /.accordion-item -->
</div>         
                 <button type="button" class="apply-filter" onclick="hideCategoryFilters()" style="background-color: #642221;
    color: #fff;
    width: 100%;
    font-weight: 700;
    border-radius: 10px;
    font-size: 16px;
    padding: 30px 25px 30px 25px;">Apply Filters</button>
                
                    </div>
                 </div>
					<!-- STORE -->
					<div id="store" class="col-md-9">
<div id="ajax_result">

						<!-- store top filter -->
						<div class="store-filter clearfix">
                        <div  class="slides-3 swiper-container swiper-container-initialized swiper-container-horizontal swiper-container-pointer-events"><div class="swiper-wrapper" style="transition-duration: 0ms; transform: translate3d(0px, 0px, 0px);">
                                             
                        <?php $brands_ids = collect($brands_ids); ?>                       
                        <?php $brands = \App\Models\Brand::all(); ?>
                        <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="swiper-slide" style="margin-right: 20px;"><button type="button"  class="text-primary-700 px-4 flex items-center justify-center text-center has-active-state SubCategory__item brand_btn" value="<?php echo e($brand->slug); ?>" onclick="getProducts(this.value)" style="width:100%;"><span  class="text-sm font-bold m swiper-text">
                        <?php if(app()->getLocale() == 'ar'): ?>
                        <?php echo e($brand->title_ar); ?>

                        <?php else: ?>
                        <?php echo e($brand->title); ?>

                        <?php endif; ?>
                        </span></button></div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div> <div class="flex mt-5"><button aria-label="next slide" class="swiper-button-next hologram-link text-white hover: mr-8"><img src="/front/images/prev.png" al=""/></button> <button data-v-3f2087ee="" aria-label="previous slide" class="swiper-button-prev hologram-link text-white mr-7"><img src="/front/images/next.png" alt=""/></button></div></div>
                        <div id="btnContainer" style="float:right;">
                          <button class="btn" onclick="listView()"><i class="fa fa-bars"></i></button> 
                          <button class="btn active" onclick="gridView()"><i class="fa fa-th-large"></i></button>
                        </div>
						</div>
						<!-- /store top filter -->

						<!-- store products -->
						<div class="row">                        
                        <!-- product -->
    <?php if(count($products)>0): ?>
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <?php
                                         $category = \App\Models\Category::where('id',$product->cat_id)->first();
                                      ?>
							<div class="col-sm-3 col-xs-6 column">					
                               
                                <div class="product">
                                    <div class="product-img">
                                         <div class="product-btns">
                                            <button class="add-to-wishlist"><i class="fa fa-heart-o"></i><span
                                                    class="tooltipp">add to wishlist</span></button> 
                                                    </div>
                                        <img  src="/<?php echo e($product->photo); ?>" alt="">
                                        <div class="product-label">
                                            <span class="new"><?php echo e(trans('home/body.new')); ?></span>
                                        </div>
                                    </div>
                                    <div class="product-body">
                                         <?php if(app()->getLocale() == 'ar'): ?>
                                         <p class="product-category"><?php echo e($category->title_ar); ?></p>
                                        <h3 class="product-name"><a href="#"><?php echo e($product->title_ar); ?></a></h3>
                                         <?php else: ?>
                                        <p class="product-category"><?php echo e($category->title); ?></p>
                                        <h3 class="product-name"><a href="#"><?php echo e($product->title); ?></a></h3>
                                        <?php endif; ?>
                                        <?php
                                                    $after_discount=($product->price-($product->price*$product->discount)/100);
                                                ?>
                                        <h4 class="product-price"><?php echo e(number_format($after_discount,2)); ?> Rs
                                        <?php if($product->discount == 0): ?>
                                        <?php else: ?>
                                        <del class="product-old-price"><?php echo e($product->price); ?></del>
                                        <?php endif; ?>
                                        </h4>
            <!--                            <div class="product-rating">-->
												<!--</div>-->
                                         <div class="product-btns">
                                            <!--<button class="add-to-wishlist"><i class="fa fa-heart-o"></i><span-->
                                            <!--        class="tooltipp">add to wishlist</span></button>-->
                                            <button class="add-to-compare" id="compare"><i class="fa fa-exchange"></i><span
                                                    class="tooltipp">add to compare</span></button> 
                                            <button type="button"
                                                style="background-color: #642221; width:auto;  text-transform: uppercase; font-weight: 700;border-radius: 40px;text-transform: uppercase;font-size:13px;padding:0px 25px 5px 25px;"
                                                class="btn btn-danger" id="add"> <?php echo e(trans('home/body.addtocart')); ?></button>

                                            <a data-toggle="modal" data-target="#<?php echo e($product->id); ?>" title="Quick View" href="#" class="quick-view"><i class="fa fa-eye"></i><span
                                                    class="tooltipp">quick view</span></a>                                                    
                                        </div>
                                    </div>
                                    <!--<div class="add-to-cart">-->
                                    <!--    <button class="add-to-cart-btn"><i class="fa fa-shopping-cart"></i> add to-->
                                    <!--        cart</button>-->
                                    <!--</div>-->
                                </div>                              
							</div>
							<!-- /product -->
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>		
                            <?php else: ?>
                            <h4 class="text-warning" style="margin:100px auto;">There are no products.</h4>
                            <?php endif; ?>				
						</div>
						<!-- /store products -->
                        
		
</div>
<!-- store bottom filter -->
<div class="store-filter clearfix">
							<!-- <span class="store-qty">Showing 20-100 products</span> -->
							<ul class="store-pagination">
                            <?php echo e($products->appends($_GET)->links()); ?>							
							</ul>
						</div>
						<!-- /store bottom filter -->
					</div>
					<!-- /STORE -->
<?php endif; ?>
</div>
				<!-- /row -->
			</div>
			<!-- /container -->
		</div>

          <!-- Modal -->
          <?php if($products): ?>
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="modal fade" id="<?php echo e($product->id); ?>" tabindex="-1" role="dialog">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span class="ti-close" aria-hidden="true"></span></button>
                            </div>
                            <div class="modal-body">
                                <div class="row no-gutters">
                                    <div class="col-lg-6 col-md-12 col-sm-12 col-xs-12">
                                        <!-- Product Slider -->
                                            <div class="product-gallery">
                                                <div class="quickview-slider-active">
                                                    <?php if(str_contains($product->photo, ',')): ?>
                                                    <?php
                                                        $photo=explode(',',$product->photo);
                                                    // dd($photo);
                                                    ?>
                                                    <?php $__currentLoopData = $photo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <div class="single-slider">
                                                            <img src="<?php echo e($data); ?>" alt="<?php echo e($data); ?>">
                                                        </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php else: ?>
                                                    <div class="single-slider">
                                                            <img src="/<?php echo e($product->photo); ?>" alt="<?php echo e($product->photo); ?>" style="width:100%;">
                                                        </div>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        <!-- End Product slider -->
                                    </div>
                                    <div class="col-lg-6 col-md-12 col-sm-12 col-xs-12">
                                        <div class="quickview-content">
                                            <h2><?php echo e($product->title); ?></h2>
                                            <div class="quickview-ratting-review">
                                                <div class="quickview-ratting-wrap">
                                                    <div class="quickview-ratting">
                                                        
                                                        <?php
                                                            $rate=DB::table('product_reviews')->where('product_id',$product->id)->avg('rate');
                                                            $rate_count=DB::table('product_reviews')->where('product_id',$product->id)->count();
                                                        ?>
                                                        <?php for($i=1; $i<=5; $i++): ?>
                                                            <?php if($rate>=$i): ?>
                                                                <i class="yellow fa fa-star"></i>
                                                            <?php else: ?>
                                                            <i class="fa fa-star"></i>
                                                            <?php endif; ?>
                                                        <?php endfor; ?>
                                                    </div>
                                                    <a href="#"> (<?php echo e($rate_count); ?> customer review)</a>
                                                </div>
                                                <div class="quickview-stock">
                                                    <?php if($product->stock >0): ?>
                                                    <span><i class="fa fa-check-circle-o"></i> <?php echo e($product->stock); ?> in stock</span>
                                                    <?php else: ?>
                                                    <span><i class="fa fa-times-circle-o text-danger"></i> <?php echo e($product->stock); ?> out stock</span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <?php
                                                $after_discount=($product->price-($product->price*$product->discount)/100);
                                            ?>
                                            <h3><small><del class="text-muted">$<?php echo e(number_format($product->price,2)); ?></del></small>    $<?php echo e(number_format($after_discount,2)); ?>  </h3>
                                            <div class="quickview-peragraph">
                                                <p style="text-align:left;"><?php echo html_entity_decode($product->summary); ?></p>
                                            </div>
                                            <?php if($product->size): ?>
                                                <div class="size">
                                                    <h4>Size</h4>
                                                    <ul>
                                                        <?php
                                                            $sizes=explode(',',$product->size);
                                                            // dd($sizes);
                                                        ?>
                                                        <?php $__currentLoopData = $sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <li><a href="#" class="one"><?php echo e($size); ?></a></li>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </ul>
                                                </div>
                                            <?php endif; ?>
                                            <div class="size">
                                                <div class="row">
                                                    <div class="col-lg-6 col-12">
                                                        <h5 class="title">Size</h5>
                                                        <select>
                                                            <?php
                                                            $sizes=explode(',',$product->size);
                                                            // dd($sizes);
                                                            ?>
                                                            <?php $__currentLoopData = $sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option><?php echo e($size); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </div>
                                                    
                                                </div>
                                            </div>
                                            <form action="<?php echo e(route('single-add-to-cart')); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <div class="quantity">
                                                    <!-- Input Order -->
                                                    <div class="input-group">
                                                        <div class="button minus">
                                                            <button type="button" class="btn btn-primary btn-number" disabled="disabled" data-type="minus" data-field="quant[1]">
                                                                <i class="ti-minus"></i>
                                                            </button>
                                                        </div>
                                                        <input type="hidden" name="slug" value="<?php echo e($product->slug); ?>">
                                                        <input type="text" name="quant[1]" class="input-number"  data-min="1" data-max="1000" value="1">
                                                        <div class="button plus">
                                                            <button type="button" class="btn btn-primary btn-number" data-type="plus" data-field="quant[1]">
                                                                <i class="ti-plus"></i>
                                                            </button>
                                                        </div>
                                                    </div>
                                                    <!--/ End Input Order -->
                                                </div>
                                                <div class="add-to-cart">
                                                    <button type="submit" class="btn" style="background-color: #642221; width:auto;  text-transform: uppercase; font-weight: 700;border-radius: 40px;text-transform: uppercase;font-size:13px;padding:0px 25px 5px 25px;color:#fff;">Add to cart</button>
                                                    <a href="<?php echo e(route('add-to-wishlist',$product->slug)); ?>" class="btn min"><i class="ti-heart"></i></a>
                                                </div>
                                            </form>
                                            <div class="default-social">
                                            <!-- ShareThis BEGIN --><div class="sharethis-inline-share-buttons"></div><!-- ShareThis END -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    <!-- Modal end -->

    
<?php $__env->stopSection(); ?>
<?php $__env->startPush('styles'); ?>
<style>
    .pagination{
        display:inline-flex;
    }
    .filter_button{
        /* height:20px; */
        text-align: center;
        background:#F7941D;
        padding:8px 16px;
        margin-top:10px;
        color: white;
    }
</style>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('scripts'); ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>
    
    <script>
        $(document).ready(function(){            
        /*----------------------------------------------------*/
        /*  Jquery Ui slider js
        /*----------------------------------------------------*/
        if ($("#slider-range").length > 0) {
            const max_value = parseInt( $("#slider-range").data('max') ) || 500;
            const min_value = parseInt($("#slider-range").data('min')) || 0;
            const currency = $("#slider-range").data('currency') || '';
            let price_range = min_value+'-'+max_value;
            if($("#price_range").length > 0 && $("#price_range").val()){
                price_range = $("#price_range").val().trim();
            }

            let price = price_range.split('-');
            $("#slider-range").slider({
                range: true,
                min: min_value,
                max: max_value,
                values: price,
                slide: function (event, ui) {
                    $("#amount").val(currency + ui.values[0] + " -  "+currency+ ui.values[1]);
                    $("#price_range").val(ui.values[0] + "-" + ui.values[1]);
                }
            });
            }
        if ($("#amount").length > 0) {
            const m_currency = $("#slider-range").data('currency') || '';
            $("#amount").val(m_currency + $("#slider-range").slider("values", 0) +
                "  -  "+m_currency + $("#slider-range").slider("values", 1));
            }
        })
       
    </script>
    
    <script>
      const os_Ids = [];
      const brands_Ids = [];
      const hard_type_Ids = [];
      const installed_ram_Ids = [];
      const cpu_types_Ids = [];
      const graphic_coprocessor_Ids = [];
      const display_types_Ids = [];  
      const conn_tech_Ids = []; 
      const natv_res_Ids = []; 
      const inc_comp_Ids = []; 
      const display_res_Ids = [];
      const monitor_feature_Ids = [];
      const price = [];
      const product_length_Ids = [];
      const hard_capacity_Ids = [];
      $('.os_check').click(function() {
        var prodId = window.location.href.split('/').reverse()[0];        
        os_Ids.push($(this).attr('id'));
        var dataString = 'id=' + prodId +  '&os=' + os_Ids + '&brands=' + brands_Ids + '&hard_types=' + hard_type_Ids + '&ram_capcity=' + installed_ram_Ids + '&cpu_type=' + cpu_types_Ids +
                         '&graphic_coprocessor=' + graphic_coprocessor_Ids + '&display_type=' + display_types_Ids + '&conn_tech=' + conn_tech_Ids + '&natv_res=' + natv_res_Ids + 
                         '&inc_comp=' + inc_comp_Ids + '&display_res=' + display_res_Ids + '&monitor_feature=' + monitor_feature_Ids + '&price=' + price + '&product_length=' + product_length_Ids + '&hard_capacity_Ids=' +hard_capacity_Ids;  
       if(this.checked){
            $.ajax({
                type: "get",
                url: "<?php echo e(url('get-products-ajax')); ?>",
                data: dataString, //--> send id of checked checkbox on other page
                success: function(data) {                                    
                    $('#ajax_result').html(data);                    
                },
                 error: function() {
                    console.log('it broke');
                },
                complete: function() {
                  console.log('it completed');
                }
            });

            }
      });
      </script>
      <script>      
      $('.hard_type_check').click(function() {
        var prodId = window.location.href.split('/').reverse()[0];        
        hard_type_Ids.push($(this).attr('id'));
        var dataString = 'id=' + prodId +  '&os=' + os_Ids + '&brands=' + brands_Ids + '&hard_types=' + hard_type_Ids + '&ram_capcity=' + installed_ram_Ids + '&cpu_type=' + cpu_types_Ids +
                         '&graphic_coprocessor=' + graphic_coprocessor_Ids + '&display_type=' + display_types_Ids + '&conn_tech=' + conn_tech_Ids + '&natv_res=' + natv_res_Ids + 
                         '&inc_comp=' + inc_comp_Ids + '&display_res=' + display_res_Ids + '&monitor_feature=' + monitor_feature_Ids + '&price=' + price + '&product_length=' + product_length_Ids + '&hard_capacity_Ids=' +hard_capacity_Ids;   
       if(this.checked){
            $.ajax({
                type: "get",
                url: "<?php echo e(url('get-products-ajax')); ?>",
                data: dataString, //--> send id of checked checkbox on other page
                success: function(data) {                                       
                    $('#ajax_result').html(data);                    
                },
                 error: function() {
                    console.log('it broke');
                },
                complete: function() {
                  console.log('it completed');
                }
            });

            }
      });
      </script>
      <script>       
      $('.ram_capcity_check').click(function() {
        var prodId = window.location.href.split('/').reverse()[0];        
        installed_ram_Ids.push($(this).attr('id'));
        var dataString = 'id=' + prodId +  '&os=' + os_Ids + '&brands=' + brands_Ids + '&hard_types=' + hard_type_Ids + '&ram_capcity=' + installed_ram_Ids + '&cpu_type=' + cpu_types_Ids +
                         '&graphic_coprocessor=' + graphic_coprocessor_Ids + '&display_type=' + display_types_Ids + '&conn_tech=' + conn_tech_Ids + '&natv_res=' + natv_res_Ids + 
                         '&inc_comp=' + inc_comp_Ids + '&display_res=' + display_res_Ids + '&monitor_feature=' + monitor_feature_Ids + '&price=' + price + '&product_length=' + product_length_Ids + '&hard_capacity_Ids=' +hard_capacity_Ids;    
       if(this.checked){
            $.ajax({
                type: "get",
                url: "<?php echo e(url('get-products-ajax')); ?>",
                data: dataString, //--> send id of checked checkbox on other page
                success: function(data) {                                      
                    $('#ajax_result').html(data);                    
                },
                 error: function() {
                    console.log('it broke');
                },
                complete: function() {
                  console.log('it completed');
                }
            });

            }
      });
      </script>  
       <script>       
      $('.hard_capcity_check').click(function() {
        var prodId = window.location.href.split('/').reverse()[0];        
        hard_capacity_Ids.push($(this).attr('id'));
        var dataString = 'id=' + prodId +  '&os=' + os_Ids + '&brands=' + brands_Ids + '&hard_types=' + hard_type_Ids + '&ram_capcity=' + installed_ram_Ids + '&cpu_type=' + cpu_types_Ids +
                         '&graphic_coprocessor=' + graphic_coprocessor_Ids + '&display_type=' + display_types_Ids + '&conn_tech=' + conn_tech_Ids + '&natv_res=' + natv_res_Ids + 
                         '&inc_comp=' + inc_comp_Ids + '&display_res=' + display_res_Ids + '&monitor_feature=' + monitor_feature_Ids + '&price=' + price + '&product_length=' + product_length_Ids + '&hard_capacity_Ids=' +hard_capacity_Ids;    
       if(this.checked){
            $.ajax({
                type: "get",
                url: "<?php echo e(url('get-products-ajax')); ?>",
                data: dataString, //--> send id of checked checkbox on other page
                success: function(data) {                                      
                    $('#ajax_result').html(data);                    
                },
                 error: function() {
                    console.log('it broke');
                },
                complete: function() {
                  console.log('it completed');
                }
            });

            }
      });
      </script>
       <script>         
      $('.cpu_type_check').click(function() {
        var prodId = window.location.href.split('/').reverse()[0];        
        cpu_types_Ids.push($(this).attr('id'));
        var dataString = 'id=' + prodId +  '&os=' + os_Ids + '&brands=' + brands_Ids + '&hard_types=' + hard_type_Ids + '&ram_capcity=' + installed_ram_Ids + '&cpu_type=' + cpu_types_Ids +
                         '&graphic_coprocessor=' + graphic_coprocessor_Ids + '&display_type=' + display_types_Ids + '&conn_tech=' + conn_tech_Ids + '&natv_res=' + natv_res_Ids + 
                         '&inc_comp=' + inc_comp_Ids + '&display_res=' + display_res_Ids + '&monitor_feature=' + monitor_feature_Ids + '&price=' + price + '&product_length=' + product_length_Ids + '&hard_capacity_Ids=' +hard_capacity_Ids;     
       if(this.checked){
            $.ajax({
                type: "get",
                url: "<?php echo e(url('get-products-ajax')); ?>",
                data: dataString, //--> send id of checked checkbox on other page
                success: function(data) {                                    
                    $('#ajax_result').html(data);                    
                },
                 error: function() {
                    console.log('it broke');
                },
                complete: function() {
                  console.log('it completed');
                }
            });

            }
      });
      </script>
        <script>       
      $('.graphic_coprocessor_check').click(function() {
        var prodId = window.location.href.split('/').reverse()[0];        
        graphic_coprocessor_Ids.push($(this).attr('id'));
        var dataString = 'id=' + prodId +  '&os=' + os_Ids + '&brands=' + brands_Ids + '&hard_types=' + hard_type_Ids + '&ram_capcity=' + installed_ram_Ids + '&cpu_type=' + cpu_types_Ids +
                         '&graphic_coprocessor=' + graphic_coprocessor_Ids + '&display_type=' + display_types_Ids + '&conn_tech=' + conn_tech_Ids + '&natv_res=' + natv_res_Ids + 
                         '&inc_comp=' + inc_comp_Ids + '&display_res=' + display_res_Ids + '&monitor_feature=' + monitor_feature_Ids + '&price=' + price + '&product_length=' + product_length_Ids + '&hard_capacity_Ids=' +hard_capacity_Ids;   
       if(this.checked){
            $.ajax({
                type: "get",
                url: "<?php echo e(url('get-products-ajax')); ?>",
                data: dataString, //--> send id of checked checkbox on other page
                success: function(data) {                                      
                    $('#ajax_result').html(data);                    
                },
                 error: function() {
                    console.log('it broke');
                },
                complete: function() {
                  console.log('it completed');
                }
            });

            }
      });
      </script>
      <script>       
      $('.display_type_check').click(function() {
        var prodId = window.location.href.split('/').reverse()[0];        
        display_types_Ids.push($(this).attr('id'));
        var dataString = 'id=' + prodId +  '&os=' + os_Ids + '&brands=' + brands_Ids + '&hard_types=' + hard_type_Ids + '&ram_capcity=' + installed_ram_Ids + '&cpu_type=' + cpu_types_Ids +
                         '&graphic_coprocessor=' + graphic_coprocessor_Ids + '&display_type=' + display_types_Ids + '&conn_tech=' + conn_tech_Ids + '&natv_res=' + natv_res_Ids + 
                         '&inc_comp=' + inc_comp_Ids + '&display_res=' + display_res_Ids + '&monitor_feature=' + monitor_feature_Ids + '&price=' + price + '&product_length=' + product_length_Ids + '&hard_capacity_Ids=' +hard_capacity_Ids;     
       if(this.checked){
            $.ajax({
                type: "get",
                url: "<?php echo e(url('get-products-ajax')); ?>",
                data: dataString, //--> send id of checked checkbox on other page
                success: function(data) {                                      
                    $('#ajax_result').html(data);                    
                },
                 error: function() {
                    console.log('it broke');
                },
                complete: function() {
                  console.log('it completed');
                }
            });

            }
      });
      </script>
       <script>      
      $('.conn_tech_check').click(function() {
        var prodId = window.location.href.split('/').reverse()[0];        
        conn_tech_Ids.push($(this).attr('id'));
        var dataString = 'id=' + prodId +  '&os=' + os_Ids + '&brands=' + brands_Ids + '&hard_types=' + hard_type_Ids + '&ram_capcity=' + installed_ram_Ids + '&cpu_type=' + cpu_types_Ids +
                         '&graphic_coprocessor=' + graphic_coprocessor_Ids + '&display_type=' + display_types_Ids + '&conn_tech=' + conn_tech_Ids + '&natv_res=' + natv_res_Ids + 
                         '&inc_comp=' + inc_comp_Ids + '&display_res=' + display_res_Ids + '&monitor_feature=' + monitor_feature_Ids + '&price=' + price + '&product_length=' + product_length_Ids + '&hard_capacity_Ids=' +hard_capacity_Ids;    
       if(this.checked){
            $.ajax({
                type: "get",
                url: "<?php echo e(url('get-products-ajax')); ?>",
                data: dataString, //--> send id of checked checkbox on other page
                success: function(data) {                                      
                    $('#ajax_result').html(data);                    
                },
                 error: function() {
                    console.log('it broke');
                },
                complete: function() {
                  console.log('it completed');
                }
            });

            }
      });
      </script>
       <script>       
      $('.natv_res_check').click(function() {
        var prodId = window.location.href.split('/').reverse()[0];        
        natv_res_Ids.push($(this).attr('id'));
        var dataString = 'id=' + prodId +  '&os=' + os_Ids + '&brands=' + brands_Ids + '&hard_types=' + hard_type_Ids + '&ram_capcity=' + installed_ram_Ids + '&cpu_type=' + cpu_types_Ids +
                         '&graphic_coprocessor=' + graphic_coprocessor_Ids + '&display_type=' + display_types_Ids + '&conn_tech=' + conn_tech_Ids + '&natv_res=' + natv_res_Ids + 
                         '&inc_comp=' + inc_comp_Ids + '&display_res=' + display_res_Ids + '&monitor_feature=' + monitor_feature_Ids + '&price=' + price + '&product_length=' + product_length_Ids + '&hard_capacity_Ids=' +hard_capacity_Ids;     
       if(this.checked){
            $.ajax({
                type: "get",
                url: "<?php echo e(url('get-products-ajax')); ?>",
                data: dataString, //--> send id of checked checkbox on other page
                success: function(data) {                                      
                    $('#ajax_result').html(data);                    
                },
                 error: function() {
                    console.log('it broke');
                },
                complete: function() {
                  console.log('it completed');
                }
            });

            }
      });
      </script>
        <script>       
      $('.inc_comp_check').click(function() {
        var prodId = window.location.href.split('/').reverse()[0];        
        inc_comp_Ids.push($(this).attr('id'));
        var dataString = 'id=' + prodId +  '&os=' + os_Ids + '&brands=' + brands_Ids + '&hard_types=' + hard_type_Ids + '&ram_capcity=' + installed_ram_Ids + '&cpu_type=' + cpu_types_Ids +
                         '&graphic_coprocessor=' + graphic_coprocessor_Ids + '&display_type=' + display_types_Ids + '&conn_tech=' + conn_tech_Ids + '&natv_res=' + natv_res_Ids + 
                         '&inc_comp=' + inc_comp_Ids + '&display_res=' + display_res_Ids + '&monitor_feature=' + monitor_feature_Ids + '&price=' + price + '&product_length=' + product_length_Ids + '&hard_capacity_Ids=' +hard_capacity_Ids;     
       if(this.checked){
            $.ajax({
                type: "get",
                url: "<?php echo e(url('get-products-ajax')); ?>",
                data: dataString, //--> send id of checked checkbox on other page
                success: function(data) {                                      
                    $('#ajax_result').html(data);                    
                },
                 error: function() {
                    console.log('it broke');
                },
                complete: function() {
                  console.log('it completed');
                }
            });

            }
      });
      </script> 
        <script>       
      $('.display_res_check').click(function() {
        var prodId = window.location.href.split('/').reverse()[0];        
        display_res_Ids.push($(this).attr('id'));
        var dataString = 'id=' + prodId +  '&os=' + os_Ids + '&brands=' + brands_Ids + '&hard_types=' + hard_type_Ids + '&ram_capcity=' + installed_ram_Ids + '&cpu_type=' + cpu_types_Ids +
                         '&graphic_coprocessor=' + graphic_coprocessor_Ids + '&display_type=' + display_types_Ids + '&conn_tech=' + conn_tech_Ids + '&natv_res=' + natv_res_Ids + 
                         '&inc_comp=' + inc_comp_Ids + '&display_res=' + display_res_Ids + '&monitor_feature=' + monitor_feature_Ids + '&price=' + price + '&product_length=' + product_length_Ids + '&hard_capacity_Ids=' +hard_capacity_Ids;     
       if(this.checked){
            $.ajax({
                type: "get",
                url: "<?php echo e(url('get-products-ajax')); ?>",
                data: dataString, //--> send id of checked checkbox on other page
                success: function(data) {                                      
                    $('#ajax_result').html(data);                    
                },
                 error: function() {
                    console.log('it broke');
                },
                complete: function() {
                  console.log('it completed');
                }
            });

            }
      });
      </script> 
       <script>       
      $('.monitor_feature_check').click(function() {
        var prodId = window.location.href.split('/').reverse()[0];        
        monitor_feature_Ids.push($(this).attr('id'));
        var dataString = 'id=' + prodId +  '&os=' + os_Ids + '&brands=' + brands_Ids + '&hard_types=' + hard_type_Ids + '&ram_capcity=' + installed_ram_Ids + '&cpu_type=' + cpu_types_Ids +
                         '&graphic_coprocessor=' + graphic_coprocessor_Ids + '&display_type=' + display_types_Ids + '&conn_tech=' + conn_tech_Ids + '&natv_res=' + natv_res_Ids + 
                         '&inc_comp=' + inc_comp_Ids + '&display_res=' + display_res_Ids + '&monitor_feature=' + monitor_feature_Ids + '&price=' + price + '&product_length=' + product_length_Ids + '&hard_capacity_Ids=' +hard_capacity_Ids;     
       if(this.checked){
            $.ajax({
                type: "get",
                url: "<?php echo e(url('get-products-ajax')); ?>",
                data: dataString, //--> send id of checked checkbox on other page
                success: function(data) {                                      
                    $('#ajax_result').html(data);                    
                },
                 error: function() {
                    console.log('it broke');
                },
                complete: function() {
                  console.log('it completed');
                }
            });

            }
      });
      </script> 
       <script>       
      $('.product_length_check').click(function() {
        var prodId = window.location.href.split('/').reverse()[0];        
        product_length_Ids.push($(this).attr('id'));
        var dataString = 'id=' + prodId +  '&os=' + os_Ids + '&brands=' + brands_Ids + '&hard_types=' + hard_type_Ids + '&ram_capcity=' + installed_ram_Ids + '&cpu_type=' + cpu_types_Ids +
                         '&graphic_coprocessor=' + graphic_coprocessor_Ids + '&display_type=' + display_types_Ids + '&conn_tech=' + conn_tech_Ids + '&natv_res=' + natv_res_Ids + 
                         '&inc_comp=' + inc_comp_Ids + '&display_res=' + display_res_Ids + '&monitor_feature=' + monitor_feature_Ids + '&price=' + price + '&product_length=' + product_length_Ids + '&hard_capacity_Ids=' +hard_capacity_Ids;     
       if(this.checked){
            $.ajax({
                type: "get",
                url: "<?php echo e(url('get-products-ajax')); ?>",
                data: dataString, //--> send id of checked checkbox on other page
                success: function(data) {                                      
                    $('#ajax_result').html(data);                    
                },
                 error: function() {
                    console.log('it broke');
                },
                complete: function() {
                  console.log('it completed');
                }
            });

            }
      });
      </script> 
      <script>
     //   var minValue = 0;
        // jQuery(function($) {
        //   $('#from').on('input', function() {
        //       var fromValue = $('#from').val();
        //       price[0] = minValue;
        //       price[1] = fromValue;
        //     var dataString = 'id=' + prodId +  '&os=' + os_Ids + '&brands=' + brands_Ids + '&hard_types=' + hard_type_Ids + '&ram_capcity=' + installed_ram_Ids + '&cpu_type=' + cpu_types_Ids +
        //                  '&graphic_coprocessor=' + graphic_coprocessor_Ids + '&display_type=' + display_types_Ids + '&conn_tech=' + conn_tech_Ids + '&natv_res=' + natv_res_Ids + 
        //                  '&inc_comp=' + inc_comp_Ids + '&display_res=' + display_res_Ids + '&monitor_feature=' + monitor_feature_Ids + '&price=' + price;     
      
        //     $.ajax({
        //         type: "get",
        //         url: "<?php echo e(url('get-products-ajax')); ?>",
        //         data: dataString, //--> send id of checked checkbox on other page
        //         success: function(data) {                                      
        //             $('#ajax_result').html(data);                    
        //         },
        //          error: function() {
        //             console.log('it broke');
        //         },
        //         complete: function() {
        //           console.log('it completed');
        //         }
        //     });
        // });
        // });
      </script>
      <script>
        const rangeInput = document.querySelectorAll(".range-input input"),
  priceInput = document.querySelectorAll(".price-input input"),
  range = document.querySelector(".slider .progress");
let priceGap = 0;

priceInput.forEach((input) => {
  input.addEventListener("input", (e) => {
    let minPrice = parseInt(priceInput[0].value),
      maxPrice = parseInt(priceInput[1].value);

    if (maxPrice - minPrice >= priceGap && maxPrice <= rangeInput[1].max) {
      if (e.target.className === "input-min") {
        rangeInput[0].value = minPrice;
        range.style.left = (minPrice / rangeInput[0].max) * 100 + "%";
      } else {
        rangeInput[1].value = maxPrice;
        range.style.right = 100 - (maxPrice / rangeInput[1].max) * 100 + "%";
      }
    }
  });
});

rangeInput.forEach((input) => {
  input.addEventListener("input", (e) => {
    let minVal = parseInt(rangeInput[0].value),
      maxVal = parseInt(rangeInput[1].value);
      var prodId = window.location.href.split('/').reverse()[0];  
      price[0] = 0;
              price[1] = minVal;
              $('.range-input input').css('background','#642221');
              $('.range-input input').css('height','5px');
            var dataString = 'id=' + prodId +  '&os=' + os_Ids + '&brands=' + brands_Ids + '&hard_types=' + hard_type_Ids + '&ram_capcity=' + installed_ram_Ids + '&cpu_type=' + cpu_types_Ids +
                         '&graphic_coprocessor=' + graphic_coprocessor_Ids + '&display_type=' + display_types_Ids + '&conn_tech=' + conn_tech_Ids + '&natv_res=' + natv_res_Ids + 
                         '&inc_comp=' + inc_comp_Ids + '&display_res=' + display_res_Ids + '&monitor_feature=' + monitor_feature_Ids + '&price=' + price + '&product_length=' + product_length_Ids + '&hard_capacity_Ids=' +hard_capacity_Ids;     
      
    if (maxVal - minVal < priceGap) {
      if (e.target.className === "range-min") {
        rangeInput[0].value = maxVal - priceGap;
      } else {
        rangeInput[1].value = minVal + priceGap;
      }
    } else {
      priceInput[0].value = minVal;
      priceInput[1].value = maxVal;
      range.style.left = (minVal / rangeInput[0].max) * 100 + "%";
      range.style.right = 100 - (maxVal / rangeInput[1].max) * 100 + "%";
    }
    
            $.ajax({
                type: "get",
                url: "<?php echo e(url('get-products-ajax')); ?>",
                data: dataString, //--> send id of checked checkbox on other page
                success: function(data) {                                      
                    $('#ajax_result').html(data);                    
                },
                 error: function() {
                    console.log('it broke');
                },
                complete: function() {
                  console.log('it completed');
                }
            });
  });
});

    </script>
    <script>      
      $('.brand_check').click(function() {
        var prodId = window.location.href.split('/').reverse()[0];        
        brands_Ids.push($(this).attr('id'));
        var dataString = 'id=' + prodId +  '&os=' + os_Ids + '&brands=' + brands_Ids + '&hard_types=' + hard_type_Ids + '&ram_capcity=' + installed_ram_Ids + '&cpu_type=' + cpu_types_Ids +
                         '&graphic_coprocessor=' + graphic_coprocessor_Ids + '&display_type=' + display_types_Ids + '&conn_tech=' + conn_tech_Ids + '&natv_res=' + natv_res_Ids + 
                         '&inc_comp=' + inc_comp_Ids + '&display_res=' + display_res_Ids + '&monitor_feature=' + monitor_feature_Ids + '&price=' + price + '&product_length=' + product_length_Ids + '&hard_capacity_Ids=' +hard_capacity_Ids;  
   // alert($(this).attr('id'));  //-->this will alert id of checked checkbox.
   console.log(dataString);
       if(this.checked){
            $.ajax({
                type: "get",
                url: "<?php echo e(url('get-products-ajax')); ?>",
                data: dataString, //--> send id of checked checkbox on other page
                success: function(data) {
                    // alert('it worked');
                    // alert(data);
                    
                    $('#ajax_result').html(data);
                    var arrayLength = brands_Ids.length;
                    for (var i = 0; i < arrayLength; i++) {
                       // console.log(myStringArray[i]);
                     //   document.getElementById("+brands_Ids[i]+").checked = true;
                        //Do something
                    }
                },
                 error: function() {
                    console.log('it broke');
                },
                complete: function() {
                  console.log('it completed');
                }
            });

            }
      });
      </script>
      <script>
              $('.category_check').click(function() {
       // var prodId = window.location.href.split('/').reverse()[0];        
        //brands_Ids.push($(this).attr('id'));
            var dataString = 'id=' + $(this).attr('id');
    //alert($(this).attr('id'));  //-->this will alert id of checked checkbox.
   console.log(dataString);
       if(this.checked){
            $.ajax({
                type: "get",
                url: "<?php echo e(url('get-products-ajax')); ?>",
                data: dataString, //--> send id of checked checkbox on other page
                success: function(data) {
                    // alert('it worked');
                    console.log(data);
                    
                    $('#ajax_result').html(data);                   
                },
                 error: function() {
                    console.log('it broke');
                },
                complete: function() {
                  console.log('it completed');
                }
            });

            }
      });
      </script>
      <script>
        function getProducts(val)
        {
            var prodId = window.location.href.split('/').reverse()[0];  
          var dataString = 'id=' + prodId + '&brands=' + val;
          console.log(dataString);
          $.ajax({
                type: "get",
                url: "<?php echo e(url('get-products-ajax')); ?>",
                data: dataString, //--> send id of checked checkbox on other page
                success: function(data) {
                    // alert('it worked');
                    // alert(data);
                    
                    $('#ajax_result').html(data);                   
                },
                 error: function() {
                    console.log('it broke');
                },
                complete: function() {
                  console.log('it completed');
                }
            }); 

        }
        
      </script>
     
<?php $__env->stopPush(); ?>


<?php echo $__env->make('front.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alsaifcoksa/public_html/onlinestore.alsaifco-ksa.com/resources/views/front/pages/product-grids.blade.php ENDPATH**/ ?>