<?php
    return[
        'new'=>'new',
        'addtocart'=>'Add To Cart',
        'RECOMMENDEDCOLLECTIONS'=>'Recommended for you',
        'Latestoffers'=>'Latest offers',
        'PopularCategories'=>'Popular Categories',
        'Router'=>'Router',
        'monitors'=>'Monitors',
        'LapTopBags'=>'Lap Top Bags',
        'labtopandnotebook'=>'Laptop & notebook',
        'PowerExtension'=>'Power Extension',
        'computeraccessories'=>'Computer Accessories',
         'projector'=>'Projector',
         'printer'=>'Printer',
         'labtop'=>'Labtop',
         'surveillancecameras'=>'Surveillance Cameras',
    ];
?>