<?php
    return[
        'aboutus'=>'About Us',
     'LetUsHelpYou'=>'Let Us Help You',
       'AboutUS'=>'About US',
       'ContactUs'=>'Contact Us',
       'ReturnPolicy'=>'Return Policy',
       'PrivacyPolicy'=>'Privacy Policy',
       'termsandconditions'=>'Terms & Conditions',
       'ShopWithUs'=>'Shop With Us',
        'myaccount'=>'My account ',
        'yourcart'=>'Your Cart',
        'wishlist'=>'Wishlist',
        'trackorder'=>'Track Order',
        'help'=>'Help',
        'aboutusdesc'=>'AL-Saif Arabia for Projects Group is a dedicated business in the creation of information technology and smart solutions. Since our companys inception in 2006 in addition to agreements with the most well-known technological brands. 
', 
       'address'=>'Saudi Arabia Kingdom - madina - Qurban El Talaa',
    ];
?>