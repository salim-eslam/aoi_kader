<?php
    return[
        'new'=>'جديد',
        'addtocart'=>'اضافة الى العربة',
        'RECOMMENDEDCOLLECTIONS'=>'اختياراتنا المتميزة ',
        'Latestoffers'=>'عروضنا الجديدة',
        'PopularCategories'=>'الفئات الأكثر طلبا',
        'LapTopBags'=>'حقائب لاب توب',
        'PowerExtension'=>'توصيلة كهربائية ',
        'labtopandnotebook'=>'لاب توب و نوت بوك',
         'Router'=>'روتر',
         'monitors'=>'شاشات',
         'computeraccessories'=>'اكسسورات كمبيوتر',
         'projector'=>'بروجيكتور',
         'printer'=>'طابعة',
         'labtop'=>'لاب توب',
         'surveillancecameras'=>'كاميرا مراقبة',
    ];
?>