<head>
    <meta charset="utf-8">
    <title>Computer Shop</title>
    <base href="/">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#ec1c24">
    <meta name="twitter:image" content="assets/images/others/icon_empty.png">
    <meta name="og:image" content="assets/images/others/icon_empty.png">
    <link rel="icon" type="image/x-icon" href="assets/images/others/logo-mini.png">
    <link rel="stylesheet" href="styles.ed1c0c2499f68ff67632.css">
    <script type="text/javascript" async="" src="https://www.google-analytics.com/analytics.js"></script>
    <script type="text/javascript" async=""
        src="https://www.googletagmanager.com/gtag/js?id=G-5B45M6RFRR&amp;l=dataLayer&amp;cx=c"></script>
    <script charset="utf-8" src="2.293a3e40e8690525571f.js"></script>
    <script charset="utf-8" src="common.a9de57ecc6e87ffb2750.js"></script>
    <script charset="utf-8" src="6.edf895a616d3cad55828.js"></script>
    <script type="text/javascript" async=""
        src="https://googleads.g.doubleclick.net/pagead/viewthroughconversion/577479233/?random=1701612751686&amp;cv=11&amp;fst=1701612751686&amp;bg=ffffff&amp;guid=ON&amp;async=1&amp;gtm=45be3bt0&amp;gcd=11l1l1l1l1&amp;dma=0&amp;u_w=1920&amp;u_h=1200&amp;url=https%3A%2F%2Fcomputershop.com.eg%2F&amp;ref=https%3A%2F%2Fwww.google.com%2F&amp;hn=www.googleadservices.com&amp;frm=0&amp;tiba=Computer%20Shop&amp;auid=85733136.1701612752&amp;fledge=1&amp;uaa=x86&amp;uab=64&amp;uafvl=Google%2520Chrome%3B117.0.5938.92%7CNot%253BA%253DBrand%3B8.0.0.0%7CChromium%3B117.0.5938.92&amp;uamb=0&amp;uap=Linux&amp;uapv=6.2.0&amp;uaw=0&amp;data=event%3Dgtag.config&amp;rfmt=3&amp;fmt=4">
    </script>
    <script type="text/javascript" async=""
        src="https://googleads.g.doubleclick.net/pagead/viewthroughconversion/577485643/?random=1701612751721&amp;cv=11&amp;fst=1701612751721&amp;bg=ffffff&amp;guid=ON&amp;async=1&amp;gtm=45be3bt0&amp;gcd=11l1l1l1l1&amp;dma=0&amp;u_w=1920&amp;u_h=1200&amp;url=https%3A%2F%2Fcomputershop.com.eg%2F&amp;ref=https%3A%2F%2Fwww.google.com%2F&amp;hn=www.googleadservices.com&amp;frm=0&amp;tiba=Computer%20Shop&amp;auid=85733136.1701612752&amp;fledge=1&amp;uaa=x86&amp;uab=64&amp;uafvl=Google%2520Chrome%3B117.0.5938.92%7CNot%253BA%253DBrand%3B8.0.0.0%7CChromium%3B117.0.5938.92&amp;uamb=0&amp;uap=Linux&amp;uapv=6.2.0&amp;uaw=0&amp;data=event%3Dgtag.config&amp;rfmt=3&amp;fmt=4">
    </script>
    <style></style>
    <meta name="og:image" content="./../../../../../src/assets/images/others/icon_empty.png">
    <style>
        .main[_ngcontent-serverApp-c2] {
            min-height: 400px;
            min-height: calc(100vh - 288px);
            padding: 16px
        }

        .sidenav[_ngcontent-serverApp-c2] {
            width: 250px;
            padding: 8px 16px;
            position: fixed
        }

        .sidenav[_ngcontent-serverApp-c2] .close[_ngcontent-serverApp-c2] {
            margin-left: 178px
        }

        .sidenav[_ngcontent-serverApp-c2] .divider[_ngcontent-serverApp-c2] {
            margin: 8px 0
        }

        @media (max-width:370px) {
            .logo[_ngcontent-serverApp-c2] {
                width: 120px !important
            }
        }

        .cart-items-count[_ngcontent-serverApp-c2] {
            position: absolute;
            top: -3px;
            left: 26px;
            background: #f44336;
            height: 18px;
            width: 18px;
            line-height: 18px;
            border-radius: 50%;
            font-size: 11px
        }

        .arrow-category[_ngcontent-serverApp-c2] {
            position: absolute;
            top: 7px;
            right: 13px
        }

        .menu[_ngcontent-serverApp-c2] {
            width: 760px;
            max-width: 760px
        }

        .shopping_cart_remove[_ngcontent-serverApp-c2] {
            -webkit-transform: scaleX(-1) !important;
            transform: scaleX(-1) !important
        }

        .cart-dropdown.mat-menu-panel[_ngcontent-serverApp-c2] {
            padding: 0 !important
        }

        @media (max-width:700px) {
            .sidenav[_ngcontent-serverApp-c2] {
                padding-right: 0;
                padding-top: 0;
                padding-bottom: 0
            }

            .logo-mobile[_ngcontent-serverApp-c2] img[_ngcontent-serverApp-c2] {
                height: 69px !important;
                width: auto !important
            }

            .searchMobileArebic.search-dropdown.mat-menu-panel[_ngcontent-serverApp-c2] {
                direction: rtl !important;
                -webkit-transform-origin: right top !important;
                transform-origin: right top !important
            }

            .searchMobileArebic[_ngcontent-serverApp-c2] .search-form[_ngcontent-serverApp-c2] input[type=text][_ngcontent-serverApp-c2] {
                padding: 0 12px 0 25px;
                border-right: 1px solid #ccc
            }

            .searchMobileArebic[_ngcontent-serverApp-c2] .search-form[_ngcontent-serverApp-c2] .search-btn[_ngcontent-serverApp-c2] {
                margin-left: 0 !important;
                margin-right: -19px !important
            }

            .sidenav[_ngcontent-serverApp-c2] .close.closeInArabic[_ngcontent-serverApp-c2] {
                margin-right: 178px;
                margin-left: 0 !important
            }
        }

        .searchMobileArabic[_ngcontent-serverApp-c2] {
            direction: rtl
        }

        .search-form.searchMobileArabic[_ngcontent-serverApp-c2] input[type=text][_ngcontent-serverApp-c2] {
            padding: 0 12px 0 27px !important
        }

        .search-form.searchMobileArabic[_ngcontent-serverApp-c2] .search-btn[_ngcontent-serverApp-c2] {
            margin-left: 0 !important;
            margin-right: -20px !important
        }

        .discount_price-line-through[_ngcontent-serverApp-c2] {
            text-decoration: line-through
        }

        .discount_price-color[_ngcontent-serverApp-c2] {
            color: #ff3d00
        }

        .cart-relative[_ngcontent-serverApp-c2] {
            position: relative
        }

        .cart-relative[_ngcontent-serverApp-c2] .loading[_ngcontent-serverApp-c2] {
            position: absolute;
            top: 0;
            left: 0;
            height: 100%;
            width: 100%;
            background: rgba(255, 255, 255, .43);
            z-index: 99
        }

        .cart-relative[_ngcontent-serverApp-c2] .loading[_ngcontent-serverApp-c2] img[_ngcontent-serverApp-c2] {
            display: block;
            -webkit-transform: translate(60%, 50%);
            transform: translate(60%, 50%);
            position: absolute;
            top: calc(50% - 125px)
        }

        .top-header-beta[_ngcontent-serverApp-c2] {
            background: #e30b13;
            height: 30px
        }

        .top-header-beta[_ngcontent-serverApp-c2] h6[_ngcontent-serverApp-c2] {
            text-align: center;
            font-size: 17px;
            text-transform: uppercase;
            color: #fff;
            height: 100%;
            line-height: 30px
        }
    </style>
    <style>
        .mat-drawer-container {
            position: relative;
            z-index: 1;
            box-sizing: border-box;
            -webkit-overflow-scrolling: touch;
            display: block;
            overflow: hidden
        }

        .mat-drawer-container[fullscreen] {
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            position: absolute
        }

        .mat-drawer-container[fullscreen].mat-drawer-opened {
            overflow: hidden
        }

        .mat-drawer-container.mat-drawer-container-explicit-backdrop .mat-drawer-side {
            z-index: 3
        }

        .mat-drawer-container.ng-animate-disabled .mat-drawer-backdrop,
        .mat-drawer-container.ng-animate-disabled .mat-drawer-content,
        .ng-animate-disabled .mat-drawer-container .mat-drawer-backdrop,
        .ng-animate-disabled .mat-drawer-container .mat-drawer-content {
            transition: none
        }

        .mat-drawer-backdrop {
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            position: absolute;
            display: block;
            z-index: 3;
            visibility: hidden
        }

        .mat-drawer-backdrop.mat-drawer-shown {
            visibility: visible
        }

        .mat-drawer-transition .mat-drawer-backdrop {
            transition-duration: .4s;
            transition-timing-function: cubic-bezier(.25, .8, .25, 1);
            transition-property: background-color, visibility
        }

        @media (-ms-high-contrast:active) {
            .mat-drawer-backdrop {
                opacity: .5
            }
        }

        .mat-drawer-content {
            position: relative;
            z-index: 1;
            display: block;
            height: 100%;
            overflow: auto
        }

        .mat-drawer-transition .mat-drawer-content {
            transition-duration: .4s;
            transition-timing-function: cubic-bezier(.25, .8, .25, 1);
            transition-property: transform, margin-left, margin-right
        }

        .mat-drawer {
            position: relative;
            z-index: 4;
            display: block;
            position: absolute;
            top: 0;
            bottom: 0;
            z-index: 3;
            outline: 0;
            box-sizing: border-box;
            overflow-y: auto;
            transform: translate3d(-100%, 0, 0)
        }

        @media (-ms-high-contrast:active) {

            .mat-drawer,
            [dir=rtl] .mat-drawer.mat-drawer-end {
                border-right: solid 1px currentColor
            }
        }

        @media (-ms-high-contrast:active) {

            .mat-drawer.mat-drawer-end,
            [dir=rtl] .mat-drawer {
                border-left: solid 1px currentColor;
                border-right: none
            }
        }

        .mat-drawer.mat-drawer-side {
            z-index: 2
        }

        .mat-drawer.mat-drawer-end {
            right: 0;
            transform: translate3d(100%, 0, 0)
        }

        [dir=rtl] .mat-drawer {
            transform: translate3d(100%, 0, 0)
        }

        [dir=rtl] .mat-drawer.mat-drawer-end {
            left: 0;
            right: auto;
            transform: translate3d(-100%, 0, 0)
        }

        .mat-drawer-inner-container {
            width: 100%;
            height: 100%;
            overflow: auto;
            -webkit-overflow-scrolling: touch
        }

        .mat-sidenav-fixed {
            position: fixed
        }
    </style>
    <style>
        @media (-ms-high-contrast:active) {
            .mat-toolbar {
                outline: solid 1px
            }
        }

        .mat-toolbar-row,
        .mat-toolbar-single-row {
            display: flex;
            box-sizing: border-box;
            padding: 0 16px;
            width: 100%;
            flex-direction: row;
            align-items: center;
            white-space: nowrap
        }

        .mat-toolbar-multiple-rows {
            display: flex;
            box-sizing: border-box;
            flex-direction: column;
            width: 100%
        }

        .mat-toolbar-multiple-rows {
            min-height: 64px
        }

        .mat-toolbar-row,
        .mat-toolbar-single-row {
            height: 64px
        }

        @media (max-width:599px) {
            .mat-toolbar-multiple-rows {
                min-height: 56px
            }

            .mat-toolbar-row,
            .mat-toolbar-single-row {
                height: 56px
            }
        }
    </style>
    <style type="text/css">
        /*
  @angular/flex-layout - workaround for possible browser quirk with mediaQuery listeners
  see http://bit.ly/2sd4HMP
*/
        @media (min-width: 600px),
        (max-width: 599px),
        (min-width: 960px),
        (max-width: 959px),
        (min-width: 1280px),
        (max-width: 1279px),
        (min-width: 1920px),
        (max-width: 1919px),
        (min-width: 0px) and (max-width: 599px),
        (min-width: 600px) and (max-width: 959px),
        (min-width: 960px) and (max-width: 1279px),
        (min-width: 1280px) and (max-width: 1919px),
        (min-width: 1920px) and (max-width: 5000px) {
            .fx-query-test {}
        }
    </style>
    <style>
