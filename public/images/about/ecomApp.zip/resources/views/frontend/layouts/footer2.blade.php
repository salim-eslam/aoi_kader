<footer id="footer">

    <div class="footer-top">
        <div class="container">
            <div class="row">

                <div class="col-lg-3 col-md-3 footer-links reveal2">
                    <h4>{{trans('header.USEFUL')}}</h4>
                    <ul>
                        <li><i class="bx bx-chevron-right"></i> <a href="{{route('home')}}">{{trans('header.Home')}}</a></li>
                        <li><i class="bx bx-chevron-right"></i> <a href="https://alsaifco-ksa.com/en/about">{{trans('header.About')}}</a></li>
                        <li><i class="bx bx-chevron-right"></i> <a href="https://alsaifco-ksa.com/en/clients">{{trans('mainpage.clients')}}</a></li>
                        <li><i class="bx bx-chevron-right"></i> <a href="#services">{{trans('header.Services')}}</a></li>
                    </ul>
                </div>

                <div class="col-lg-3 col-md-3 footer-links reveal2">
                    <h4>{{trans('header.VARIOUS')}}</h4>
                    <ul>
                        @if(session()->get('locale')=='ar')
                        <li><i class="bx bx-chevron-right"></i><a target="_blank" href="{{asset('assets/Front/assets/files/Sifar.pdf')}}">{{trans('header.Download Profile')}}</a></li>
                        @else
                        <li><i class="bx bx-chevron-right"></i><a target="_blank" href="{{asset('assets/Front/assets/files/Sifen.pdf')}}">{{trans('header.Download Profile')}}</a></li>
                        @endif
                        <li><i class="bx bx-chevron-right"></i> <a href="https://alsaifco-ksa.com/en/Privacy">{{trans('header.Privacy')}}</a></li>
                        <li><i class="bx bx-chevron-right"></i> <a href="https://alsaifco-ksa.com/en/Blog">{{trans('header.Blog')}}</a></li>
                    </ul>
                </div>

                <div class="col-lg-3 col-md-3 footer-contact reveal">
                    <h4>{{trans('header.CONTACT')}}</h4>
                    <p>
                        <strong>{{trans('header.Phone')}}:</strong>&nbsp;8004422221<br>
                        <strong>{{trans('header.Email')}}:</strong>&nbsp;info@alsaifco-ksa.com<br>
                    </p>
                </div>
                <div class="col-lg-3 reveal">
                    <a href="https://zatca.gov.sa/ar/Pages/default.aspx" target="_blank"><img style="width: 135px; margin-top: -10px;" src="{{asset('assets/Front/assets/img/logo/zaka.png')}}" alt=""></a>
                    <a href="https://zatca.gov.sa/ar/PortalServices/Search/Pages/default.aspx#k=%d9%85%d9%86%d8%b5%d8%a9%20%d9%81%d8%a7%d8%aa%d9%88%d8%b1%d8%a9" target="_blank"><img style="width: 115px; margin-top: -10px;" src="{{asset('assets/Front/assets/img/logo/fatora.png')}}" alt=""></a>
                    <p> {{trans('header.zaka')}} </p>
                </div>
            </div>
        </div>
    </div>

    <div class="footer-newsletter">
        <div class="container">
            <div class="row ">
                <div class="col-lg-3  reveal2">
                    <h4>{{trans('header.AlSaif For Projects')}}</h4>
                    <p style="font-size: 16px;">{{trans('header.We have previously pioneered digital transformation in accordance with the vision of the Kingdom of Saudi Arabia 2030')}} </p>
                </div>
                <div class="col-lg-3 col-md-6 footer-info reveal2">
                    <h3 class="reveal">{{trans('header.About')}}</h3>
                    <p class="reveal">{{trans('mainpage.aboutP')}}</p>
                </div>
                <div class="col-lg-3  reveal">
                    <a href="https://alsaifco-ksa.com/en/quotation"><i class="bi bi-geo-alt"></i> <strong> {{trans('mainpage.locations')}}</strong></a>
                    <p>{{trans('header.madina')}}</p>
                    <p>{{trans('header.dmam')}}</p>
                    <p>{{trans('header.cairo')}}</p>
                </div>

                <div class="col-lg-3 reveal">
                    <a href="https://alsaifco-ksa.com/en/Technical_Support"><i class="bi bi-headset"></i> <strong>{{trans('header.Technical Support')}} </strong></a>
                    <div class="social-links mt-3">
                        <a href="https://twitter.com/alsaifco2" target="_blank" class="twitter"><i class="bi bi-twitter"></i></a>
                        <a href="https://www.facebook.com/alsaifcoksa/" target="_blank" class="facebook"><i class="bi bi-facebook"></i></a>
                        <a href="https://www.instagram.com/alsaifco.sa/" target="_blank" class="instagram"><i class="bi bi-instagram"></i></a>
                        <a href="https://www.linkedin.com/in/%D8%A7%D9%84%D8%B3%D9%8A%D9%81-%D8%A7%D9%84%D8%B9%D8%B1%D8%A8%D9%8A%D8%A9-%D9%84%D9%84%D9%85%D8%B4%D8%A7%D8%B1%D9%8A%D8%B9-967472251/" target="_blank" class="linkedin"><i class="bi bi-linkedin"></i></i></a>
                    </div>
                    <a style="background-color: #e6c47a57;color: white; margin-top: 10px; margin-bottom: 10px;" href="https://alsaifco-ksa.com/en/quotation" class="btn btn-light" role="button" aria-pressed="true">{{trans('header.quotation')}}</a>
                </div>
                <div class="col-lg-2  reveal2">
                    <a href="https://www.sitksa-eg.com/" target="_blank"><img style="width: 100px;" src="{{asset('assets/Front/assets/img/logo/masder.png')}}" alt=""></a>
                </div>
                <div class="col-lg-2  reveal2">
                    <a href="https://safedcare.com/ar" target="_blank"><img style="width: 110px;" src="{{asset('assets/Front/assets/img/logo/sdc.png')}}" alt=""></a>
                </div>
            </div>
        </div>
    </div>

    <div class="container">
        <div class="copyright">
            &copy; {{trans('header.All Rights Reserved')}}
        </div>
    </div>
</footer><!-- End Footer -->