<section id="topbar" class="d-flex align-items-center">
    <div class="container d-flex justify-content-center justify-content-md-between">

        <div class="social-links d-none d-md-flex align-items-center">
            <a href="https://twitter.com/alsaifco2" target="_blank" class="twitter"><i class="bi bi-twitter"></i></a>
            <a href="https://www.facebook.com/alsaifcoksa/" target="_blank" class="facebook"><i class="bi bi-facebook"></i></a>
            <a href="https://www.instagram.com/alsaifco.sa/" target="_blank" class="instagram"><i class="bi bi-instagram"></i></a>
            <a href="https://www.linkedin.com/in/%D8%A7%D9%84%D8%B3%D9%8A%D9%81-%D8%A7%D9%84%D8%B9%D8%B1%D8%A8%D9%8A%D8%A9-%D9%84%D9%84%D9%85%D8%B4%D8%A7%D8%B1%D9%8A%D8%B9-967472251/" target="_blank" class="linkedin"><i class="bi bi-linkedin"></i></i></a>
        </div>
        <div class="contact-info d-flex align-items-center">
            <div class="topbar-col">
                <div style="max-width: 200px;">
                    <a style="margin: 5px;" href="">E &nbsp; <img style=" max-width: 20%;" src="{{asset('assets/Front/assets/img/usa.png')}}" class="img-fluid" alt=""></a>
                    <a href=""><img style=" max-width: 20%;" src="{{asset('assets/Front/assets/img/ksa.png')}}" class="img-fluid" alt=""> &nbsp; ع</a>
                </div>
            </div>
            <i class="bi bi-envelope  d-none d-md-flex align-items-center"><a href="mailto:contact@example.com">&nbsp;info@alsaifco-ksa.com</a></i>
            <i class="bi bi-phone d-flex align-items-center ms-4"><span>&nbsp;8004422221</span></i>
        </div>
    </div>

</section>

<!-- ======= Header ======= -->
<header id="header" class="d-flex align-items-center">
    <div style="max-width: 1323px;" class="container d-flex justify-content-between align-items-center">
        <div class="logo">
            <a href="{{route('home')}}"><img src=" {{asset('assets/Front/assets/img/logo.png')}}" alt=""></a>
        </div>
        <nav id="navbar" class="navbar">
            <ul id="myMenu">
                <li><a class="active" href="{{route('home')}}">{{trans('header.Home')}}</a></li>
                <li class="dropdown"><a href="#about"><span>{{trans('header.About')}}</span> <i class="bi bi-chevron-down"></i></a>
                    <ul>
                        <li><a target="_blank" href="">{{trans('header.About Alsaif for projects')}}</a></li>
                        <li><a href="">{{trans('header.Exhibitions and conferences')}}</a></li>
                        @if(session()->get('locale')=='ar')
                        <li><a target="_blank" href="{{asset('assets/Front/assets/files/Sifar.pdf')}}">{{trans('header.Download Profile')}}</a></li>
                        @else
                        <li><a target="_blank" href="{{asset('assets/Front/assets/files/Sifen.pdf')}}">{{trans('header.Download Profile')}}</a></li>
                        @endif
                    </ul>
                </li>
                <li class="dropdown"><a href="#services"><span>{{trans('header.Technological solutions')}}</span> <i class="bi bi-chevron-down"></i></a>
                    <ul>
                        <li><a href="">{{trans('header.Technological infrastructure')}}</a></li>
                        <li><a href="">{{trans('header.Data center processing')}}</a></li>
                        <li><a href="">{{trans('header.Optical Fiber')}}</a></li>
                        <li><a href="">{{trans('header.Wireless networks')}}</a></li>
                        <li><a href="">{{trans('header.Technical Support')}}</a></li>
                        <li><a href="">{{trans('header.Cyber security')}}</a></li>
                    </ul>
                </li>

                <li class="dropdown"><a href="#features"><span>{{trans('header.Electronic products')}}</span> <i class="bi bi-chevron-down"></i></a>
                    <ul>
                        <li><a href="">{{trans('header.Supplying computers and laptops')}}</a></li>
                        <li><a href="">{{trans('header.Surveillance systems and security devices')}}</a></li>
                        <li><a href="">{{trans('header.VoIP devices')}}</a></li>
                        <li><a href="">{{trans('header.Attendance systems')}}</a></li>
                        <li><a href="">{{trans('header.Equipping the conference room')}}</a></li>
                    </ul>
                </li>
                <li class="dropdown"><a href=""><span>{{trans('header.Blog and news')}}</span> <i class="bi bi-chevron-down"></i></a>
                    <ul>
                        <li><a target="_blank" href="">{{trans('header.News and events')}}</a></li>
                        <li><a target="_blank" href="">{{trans('header.Blog')}}</a></li>
                    </ul>
                </li>
                <li class="dropdown"><a href=""><span>{{trans('header.E-Invoicing')}}</span> <i class="bi bi-chevron-down"></i></a>
                    <ul>
                        <li><a target="_blank" href="https://zatca.gov.sa/ar/E-Invoicing/Introduction/Pages/What-is-e-invoicing.aspx">{{trans('e-invoicing.invoice1')}}</a></li>
                        <li><a target="_blank" href="https://zatca.gov.sa/ar/E-Invoicing/SolutionProviders/Pages/default.aspx">{{trans('e-invoicing.invoice2')}}</a></li>
                        <li><a target="_blank" href="https://zatca.gov.sa/ar/RulesRegulations/Pages/default.aspx">{{trans('e-invoicing.invoice3')}}</a></li>
                    </ul>
                </li>
                <li><a href=" ">{{trans('mainpage.clients')}}</a></li>


                <li><a href="">{{trans('header.CONTACT')}}</a></li>
                <!-- <li><a href="">{{trans('header.Store')}}</a></li> -->
                <li class="top-level-link">
                    <a href="" class="btn btn-outline-white ms-2" id="dm" style="filter: blur(0px); padding: 10px;">{{trans('header.Store')}}</a>
                </li>
                <div style="margin-left: 20px; width: 200px;">
                    <div class="basic-search">
                        <div class="input-field">
                            <input id="search" type="text" placeholder="{{trans('header.Search')}}" />
                            <div class="icon-wrap">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
                                    <path d="M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"></path>
                                </svg>
                            </div>
                        </div>
                    </div>
                </div>
            </ul>
            <i class="bi bi-list mobile-nav-toggle"></i>
        </nav>
    </div>
</header>