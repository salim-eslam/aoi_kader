@extends('backend.layouts.master')

@section('main-content')

<div class="card">
    <h5 class="card-header">Add Product</h5>
    <div class="card-body">
      <form method="post" action="{{route('product.store')}}" enctype="multipart/form-data" >
        {{csrf_field()}}
        <div class="form-group">
          <label for="inputTitle" class="col-form-label">Title <span class="text-danger">*</span></label>
          <input id="inputTitle" type="text" name="title" placeholder="Enter title"  value="{{old('title')}}" class="form-control">
          @error('title')
          <span class="text-danger">{{$message}}</span>
          @enderror
        </div>
        <div class="form-group">
          <label for="inputTitle" class="col-form-label">Arabic Title <span class="text-danger">*</span></label>
          <input id="inputTitle" type="text" name="title_ar" placeholder="Enter title"  value="{{old('title_ar')}}" class="form-control">
          @error('title_ar')
          <span class="text-danger">{{$message}}</span>
          @enderror
        </div>

        <div class="form-group">
          <label for="summary" class="col-form-label">Summary <span class="text-danger">*</span></label>
          <textarea class="form-control" id="summary" name="summary">{{old('summary')}}</textarea>
          @error('summary')
          <span class="text-danger">{{$message}}</span>
          @enderror
        </div>
        <div class="form-group">
          <label for="summary" class="col-form-label">Arabic Summary <span class="text-danger">*</span></label>
          <textarea class="form-control" id="summary_ar" name="summary_ar">{{old('summary_ar')}}</textarea>
          @error('summary_ar')
          <span class="text-danger">{{$message}}</span>
          @enderror
        </div>
        <div class="form-group">
          <label for="brand_id">Product Brand</label>
          <select name="brand_id" id="brand_id" class="form-control">
              <option value="">--Select brand --</option>
              @foreach($brands as $brand)
                  <option value='{{$brand->id}}'>{{$brand->title}}</option>
              @endforeach 
          </select>
        </div>

      
              {{-- {{$categories}} --}}

        <div class="form-group">
          <label for="cat_id">Category <span class="text-danger">*</span></label>
          <select name="cat_id" id="cat_id" class="form-control">
              <option value="">--Select any category--</option>
              @foreach($categories as $key=>$cat_data)
              @php $hasChildren = \App\Models\Category::getAllParentWithChild(); @endphp
              @if($cat_data->parent_id == null)
                  <option value='{{$cat_data->id}}'>{{$cat_data->title}}</option>
              @endif      
              @endforeach
          </select>
        </div>

        <div class="form-group d-none" id="child_cat_div">
          <label for="child_cat_id">Sub Category</label>
          <select name="child_cat_id" id="child_cat_id" class="form-control">
              <option value="">--Select any category--</option>
              {{-- @foreach($parent_cats as $key=>$parent_cat)
                  <option value='{{$parent_cat->id}}'>{{$parent_cat->title}}</option>
              @endforeach --}}
          </select>
        </div>
          <div class="form-group d-none" id="child_child_cat_div">
          <label for="child_child_cat_id">Sub Sub Category</label>
          <select name="child_child_cat_id" id="child_child_cat_id" class="form-control">
              <option value="">--Select Sub Sub category--</option>
              
          </select>
        </div>
         <div class="form-group d-none" id="display_types_div">
          <label for="display_type_id">Display Types</label>
          <select name="display_type_id" id="display_type_id" class="form-control">
              <option value="">--Select any type--</option>
              @foreach($displayTypes as $displayType)
                  <option value='{{$displayType->id}}'>{{$displayType->title}}</option>
              @endforeach
          </select>
        </div>
        <div class="form-group d-none" id="conn_tech_div">
          <label for="conn_tech_id">Connectivity Technologies</label>
          <select name="conn_tech_id" id="conn_tech_id" class="form-control">
              <option value="">--Select any technology--</option>
              @foreach($connectivityTechnologies as $connectivityTechnology)
                  <option value='{{$connectivityTechnology->id}}'>{{$connectivityTechnology->title}}</option>
              @endforeach 
          </select>
        </div>
        <div class="form-group d-none" id="native_resolution_div">
          <label for="native_resolution_id">Native Resolutions</label>
          <select name="native_resolution_id" id="native_resolution_id" class="form-control">
              <option value="">--Select any --</option>
               @foreach($nativeResolutions as $nativeResolution)
                  <option value='{{$nativeResolution->id}}'>{{$nativeResolution->title}}</option>
              @endforeach 
          </select>
        </div>
        <div class="form-group d-none" id="inc_comp_div">
          <label for="inc_comp_id">Include Components</label>
          <select name="inc_comp_id" id="inc_comp_id" class="form-control">
              <option value="">--Select any --</option>
               @foreach($includeComponents as $includeComponent)
                  <option value='{{$includeComponent->id}}'>{{$includeComponent->title}}</option>
              @endforeach 
          </select>
        </div>
        <div class="form-group d-none" id="display_res_div">
          <label for="display_res_id ">Display Resolutions</label>
          <select name="display_res_id " id="display_res_id " class="form-control">
              <option value="">--Select any --</option>
               @foreach($displayResolutions as $displayResolution)
                  <option value='{{$displayResolution->id}}'>{{$displayResolution->title}}</option>
              @endforeach 
          </select>
        </div>
        <div class="form-group d-none" id="screen_size_div">
          <label for="screen_size_id">Screen Sizes</label>
          <select name="screen_size_id" id="screen_size_id" class="form-control">
              <option value="">--Select any --</option>
               @foreach($screenSizes as $screenSize)
                  <option value='{{$screenSize->id}}'>{{$screenSize->title}}</option>
              @endforeach 
          </select>
        </div>
        <div class="form-group d-none" id="monitor_feature_div">
          <label for="monitor_feature_id">Monitor Features</label>
          <select name="monitor_feature_id" id="monitor_feature_id" class="form-control">
              <option value="">--Select any --</option>
               @foreach($monitorFeatures as $monitorFeature)
                  <option value='{{$monitorFeature->id}}'>{{$monitorFeature->title}}</option>
              @endforeach 
          </select>
        </div>

        
        <div class="form-group d-none" id="product_length_div">
          <label for="product_length_id">Product Length</label>
          <select name="product_length_id" id="product_length_id" class="form-control">
              <option value="">--Select any --</option>
               @foreach($productLengths as $productLength)
                  <option value='{{$productLength->id}}'>{{$productLength->title}}</option>
              @endforeach 
          </select>
        </div>
        <div class="form-group d-none" id="os_div">
          <label for="os_id">Operating System</label>
          <select name="os_id" id="os_id" class="form-control">
              <option value="">--Select any --</option>
               @foreach($operatingSystems as $operatingSystem)
                  <option value='{{$operatingSystem->id}}'>{{$operatingSystem->title}}</option>
              @endforeach 
          </select>
        </div>
        <div class="form-group d-none" id="cpu_type_div">
          <label for="cpu_type_id">CPU Type</label>
          <select name="cpu_type_id" id="cpu_type_id" class="form-control">
              <option value="">--Select any --</option>
               @foreach($cpuTypes as $cpuType)
                  <option value='{{$cpuType->id}}'>{{$cpuType->title}}</option>
              @endforeach 
          </select>
        </div>
        <div class="form-group d-none" id="hard_type_div">
          <label for="hard_type_id">Hard Drive Type</label>
          <select name="hard_type_id" id="hard_type_id" class="form-control">
              <option value="">--Select any --</option>
               @foreach($hardTypes as $hardType)
                  <option value='{{$hardType->id}}'>{{$hardType->title}}</option>
              @endforeach 
          </select>
        </div>
        <div class="form-group d-none" id="graphics_corprocessor_div">
          <label for="graphics_corprocessor_id">Graphics Coprocessor</label>
          <select name="graphics_corprocessor_id" id="graphics_corprocessor_id" class="form-control">
              <option value="">--Select any --</option>
               @foreach($graphicsCoprocessors as $graphicsCoprocessor)
                  <option value='{{$graphicsCoprocessor->id}}'>{{$graphicsCoprocessor->title}}</option>
              @endforeach 
          </select>
        </div>

       
        <div class="form-group d-none" id="installed_ram_div">
          <label for="installed_ram_id">Installed RAM</label>
          <select name="installed_ram_id" id="installed_ram_id" class="form-control">
              <option value="">--Select any --</option>
               @foreach($installedRAMs as $installedRAM)
                  <option value='{{$installedRAM->id}}'>{{$installedRAM->title}}</option>
              @endforeach 
          </select>
        </div>
        <div class="form-group d-none" id="hard_capacity_div">
          <label for="hard_capacity_id">Hard Drive Capacity</label>
          <select name="hard_capacity_id" id="hard_capacity_id" class="form-control">
              <option value="">--Select any --</option>
               @foreach($hardCapacities as $hardCapacity)
                  <option value='{{$hardCapacity->id}}'>{{$hardCapacity->title}}</option>
              @endforeach 
          </select>
        </div>
          <div class="form-group d-none" id="dedicated_graphics_memory_div">
          <label for="dedicated_graphics_memory_id">Dedicated Graphics Memory</label>
          <select name="dedicated_graphics_memory_id" id="dedicated_graphics_memory_id" class="form-control">
              <option value="">--Select any --</option>
               @foreach($dedicatedGraphicsMemories as $dedicatedGraphicsMemory)
                  <option value='{{$dedicatedGraphicsMemory->id}}'>{{$dedicatedGraphicsMemory->title}}</option>
              @endforeach 
          </select>
        </div>
          <div class="form-group d-none" id="lab_screen_size_div">
          <label for="lab_screen_size_id">Labtop Screen Size</label>
          <select name="lab_screen_size_id" id="lab_screen_size_id" class="form-control">
              <option value="">--Select any --</option>
               @foreach($laptopScreenSizes as $laptopScreenSize)
                  <option value='{{$laptopScreenSize->id}}'>{{$laptopScreenSize->title}}</option>
              @endforeach 
          </select>
        </div>
          <div class="form-group d-none" id="wa_res_level_div">
          <label for="wa_res_level_id">Water Resistance Level</label>
          <select name="wa_res_level_id" id="wa_res_level_id" class="form-control">
              <option value="">--Select any --</option>
               @foreach($waterResistanceLevels as $waterResistanceLevel)
                  <option value='{{$waterResistanceLevel->id}}'>{{$waterResistanceLevel->title}}</option>
              @endforeach 
          </select>
        </div>
        <div class="form-group d-none" id="night_vision_range_div">
          <label for="night_vision_range_id">Night Vision Ranges</label>
          <select name="night_vision_range_id" id="night_vision_range_id" class="form-control">
              <option value="">--Select any --</option>
               @foreach($nightVisionRanges as $nightVisionRange)
                  <option value='{{$nightVisionRange->id}}'>{{$nightVisionRange->title}}</option>
              @endforeach 
          </select>
        </div>
         <div class="form-group d-none" id="usage_div">
          <label for="usage_id">Camera Usage</label>
          <select name=usage_id" id="usage_id" class="form-control">
              <option value="">--Select any --</option>
               @foreach($usages as $usage)
                  <option value='{{$usage->id}}'>{{$usage->title}}</option>
              @endforeach 
          </select>
        </div>



        <div class="form-group">
          <label for="price" class="col-form-label">Price(NRS) <span class="text-danger">*</span></label>
          <input id="price" type="number" name="price" placeholder="Enter price"  value="{{old('price')}}" class="form-control">
          @error('price')
          <span class="text-danger">{{$message}}</span>
          @enderror
        </div>

        <div class="form-group">
          <label for="discount" class="col-form-label">Discount(%)</label>
          <input id="discount" type="number" name="discount" min="0" max="100" placeholder="Enter discount"  value="{{old('discount')}}" class="form-control">
          @error('discount')
          <span class="text-danger">{{$message}}</span>
          @enderror
        </div>
    
        <div class="form-group">
          <label for="condition">Condition</label>
          <select name="condition" class="form-control">
              <option value="">--Select Condition--</option>
              <option value="default">Default</option>
              <option value="new">New</option>
              <option value="hot">Special</option>
          </select>
        </div>

        <div class="form-group">
          <label for="stock">Quantity <span class="text-danger">*</span></label>
          <input id="quantity" type="number" name="stock" min="0" placeholder="Enter quantity"  value="{{old('stock')}}" class="form-control">
          @error('stock')
          <span class="text-danger">{{$message}}</span>
          @enderror
        </div>
        <div class="form-group">
          <label for="inputPhoto" class="col-form-label">Photo <span class="text-danger">*</span></label>
          <div class="input-group">
              <!-- <span class="input-group-btn">
                  <a id="lfm" data-input="thumbnail" data-preview="holder" class="btn btn-primary">
                  <i class="fa fa-picture-o"></i> Choose
                  </a>
              </span> -->
          <input id="thumbnail" class="form-control" type="file" name="photo" value="{{old('photo')}}">
        </div>
        <div id="holder" style="margin-top:15px;max-height:100px;"></div>
          @error('photo')
          <span class="text-danger">{{$message}}</span>
          @enderror
        </div>
        
        <div class="form-group">
          <label for="status" class="col-form-label">Status <span class="text-danger">*</span></label>
          <select name="status" class="form-control">
              <option value="active">Active</option>
              <option value="inactive">Inactive</option>
          </select>
          @error('status')
          <span class="text-danger">{{$message}}</span>
          @enderror
        </div>
        <div class="form-group mb-3">
          <button type="reset" class="btn btn-warning">Reset</button>
           <button class="btn btn-success" type="submit">Submit</button>
        </div>
      </form>
    </div>
</div>

@endsection

@push('styles')
<link rel="stylesheet" href="{{asset('backend/summernote/summernote.min.css')}}">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.1/css/bootstrap-select.css" />
@endpush
@push('scripts')
<script src="/vendor/laravel-filemanager/js/stand-alone-button.js"></script>
<script src="{{asset('backend/summernote/summernote.min.js')}}"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.1/js/bootstrap-select.min.js"></script>

<script>
    $('#lfm').filemanager('image');

    $(document).ready(function() {
      $('#summary').summernote({
        placeholder: "Write short description.....",
          tabsize: 2,
          height: 100
      });
    });
$(document).ready(function() {
      $('#summary_ar').summernote({
        placeholder: "Write short description.....",
          tabsize: 2,
          height: 100
      });
    });
    $(document).ready(function() {
      $('#description').summernote({
        placeholder: "Write detail description.....",
          tabsize: 2,
          height: 150
      });
    });
    // $('select').selectpicker();

</script>

<script>
  $('#cat_id').change(function(){
    var cat_id=$(this).val();
    // alert(cat_id);
    if(cat_id !=null){
      // Ajax call
      $.ajax({
        url:"/admin/category/"+cat_id+"/child",
        data:{
          _token:"{{csrf_token()}}",
          id:cat_id
        },
        type:"POST",
        success:function(response){
          if(typeof(response) !='object'){
            response=$.parseJSON(response)
          }
          // console.log(response);
          var html_option="<option value=''>----Select sub category----</option>"
          if(response.status){
            var data=response.data;
            // alert(data);
            if(response.data){
              $('#child_cat_div').removeClass('d-none');
              $.each(data,function(id,title){
                html_option +="<option value='"+id+"'>"+title+"</option>"
              });
            }
            else{
            }
          }
          else{
            $('#child_cat_div').addClass('d-none');
          }
          $('#child_cat_id').html(html_option);
        }
      });
    }
    else{
    }
  })
</script>
<script>
  $('#child_cat_id').change(function(){
    var child_cat_id=$(this).val();
    // alert(cat_id);
    if(cat_id !=null){
      // Ajax call
      $.ajax({
        url:"/admin/get-category/",
        data:{
          _token:"{{csrf_token()}}",
          id:child_cat_id
        },
        type:"GET",
        success:function(response){
          if(typeof(response) !='object'){
            response=$.parseJSON(response)
          }  
          var title = response.data.title.toLowerCase(); 
          console.log(title);       
          if(response.status){
            if(title == "monitors")
            {
              $('#display_res_div').removeClass('d-none');
              $('#conn_tech_div').removeClass('d-none');
              $('#screen_size_div').removeClass('d-none');
              $('#monitor_feature_div').removeClass('d-none');
            }
            else
            {
              $('#display_res_div').addClass('d-none');
              // $('#conn_tech_div').addClass('d-none');
              $('#screen_size_div').addClass('d-none');
              $('#monitor_feature_div').addClass('d-none');
            }
            if(title == "projector")
            {
              $('#display_types_div').removeClass('d-none');
              $('#conn_tech_div').removeClass('d-none');
              $('#native_resolution_div').removeClass('d-none');
              $('#inc_comp_div').removeClass('d-none');
            }
            else
            {
              $('#display_types_div').addClass('d-none');
              // $('#conn_tech_div').addClass('d-none');
              $('#native_resolution_div').addClass('d-none');
              $('#inc_comp_div').addClass('d-none');
            }
            if(title == "labtop & notebook")
            {
              $('#os_div').removeClass('d-none'); 
              $('#cpu_type_div').removeClass('d-none');
              $('#hard_type_div').removeClass('d-none');
              $('#graphics_corprocessor_div').removeClass('d-none');
             // $('#dedicated_graphics_memory_div').removeClass('d-none');
              $('#installed_ram_div').removeClass('d-none');             
            }
            else
            {
             // $('#os_div').addClass('d-none'); 
              $('#cpu_type_div').addClass('d-none');
              //$('#hard_type_div').addClass('d-none');
              $('#graphics_corprocessor_div').addClass('d-none');
              $('#dedicated_graphics_memory_div').addClass('d-none');
             // $('#installed_ram_div').addClass('d-none');          
            }
            if(title == "desktop")
            {
              $('#os_div').removeClass('d-none'); 
              $('#hard_capacity_div').removeClass('d-none');
              $('#hard_type_div').removeClass('d-none');
              $('#installed_ram_div').removeClass('d-none');
            } 
            else
            {
              //$('#os_div').addClass('d-none'); 
              $('#hard_capacity_div').addClass('d-none');
             // $('#hard_type_div').addClass('d-none');
              //$('#installed_ram_div').addClass('d-none');
            } 
            if(title == "lab top bags")
            {
              $('#lab_screen_size_div').removeClass('d-none');
              $('#wa_res_level_div').removeClass('d-none');
            } 
            else
            {
              $('#lab_screen_size_div').addClass('d-none');
              $('#wa_res_level_div').addClass('d-none');
            }                   
            if(title == "power extension")
            {
              $('#product_length_div').removeClass('d-none');
            }   
            else
            {
              $('#product_length_div').addClass('d-none');
            }
            if(title == "cabels")
            {
              $('#product_length_div').removeClass('d-none');
            }   
            else
            {
              $('#product_length_div').addClass('d-none');
            } 
             if(title == "surveillance camera")
            {
              $('#night_vision_range_div').removeClass('d-none');
              $('#conn_tech_div').removeClass('d-none');
              $('#usage_div').removeClass('d-none');
            }   
            else
            {
              $('#night_vision_range_div').addClass('d-none');
              $('#usage_div').addClass('d-none');
            }   
          }
          else{
            $('#child_cat_div').addClass('d-none');
          }          
        }
      });
    }
    else{
    }
  })
</script>
<script>
    $('#child_cat_id').change(function(){
    var child_catt_id=$(this).val();
    //  alert(child_catt_id);
    if(cat_id !=null){
      // Ajax call
      $.ajax({
        url:"/admin/get-child-category/",
         data:{
          _token:"{{csrf_token()}}",
          id:child_catt_id
        },
        type:"GET",
        success:function(response){
          if(typeof(response) !='object'){
            response=$.parseJSON(response)
          }
          // console.log(response);
          var html_option="<option value=''>----Select sub sub category----</option>"
          if(response.status){
            var data=response.data;
            // alert(data);
            if(response.data){
              $('#child_child_cat_div').removeClass('d-none');
              $.each(data,function(id,title){
                html_option +="<option value='"+id+"'>"+title+"</option>"
              });
            }
            else{
            }
          }
          else{
            $('#child_child_cat_div').addClass('d-none');
          }
          $('#child_child_cat_id').html(html_option);
        }
      });
    }
    else{
    }
  })
</script>
@endpush