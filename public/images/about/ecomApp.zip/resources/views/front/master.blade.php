 <!DOCTYPE html>
@if(app()->getLocale() == 'ar')
<html dir="rtl" lang="ar">
@else
<html lang="en">
@endif

<head>
    <meta charset="utf-8">
    <meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="icon" type="image/png" href="{{ asset('front/img/alsaif.png') }}">
    <title>AlSaif - Ecommerce</title>
    <!-- Google font -->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,500,700" rel="stylesheet">

    <!-- Bootstrap -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"/>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css"/>
     @if(app()->getLocale() == 'ar')
     <link type="text/css" rel="stylesheet" href="{{ asset('front/rtlcss/bootstrap.min.css') }}" />
     @else
    <link type="text/css" rel="stylesheet" href="{{ asset('front/css/bootstrap.min.css') }}" />
    @endif
    <!-- Slick -->
    <link type="text/css" rel="stylesheet" href="{{ asset('front/css/slick.css') }}" />
    <link type="text/css" rel="stylesheet" href="{{ asset('front/css/slick-theme.css') }}" />

    <!-- nouislider -->
    <link type="text/css" rel="stylesheet" href="{{ asset('front/css/nouislider.min.css') }}" />

    <!-- Font Awesome Icon -->
    <link rel="stylesheet" href="{{ asset('front/css/font-awesome.min.css') }}">
   
    <!-- Custom stlylesheet -->
    @if(app()->getLocale() == 'ar')
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@600&display=swap" rel="stylesheet">

     <link type="text/css" rel="stylesheet" href="{{ asset('front/rtlcss/style.css') }}" />
    @else
    <link type="text/css" rel="stylesheet" href="{{ asset('front/css/style.css') }}" />
    @endif

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
    <script>
        $(document).ready(function() {
            $(".wish-icon i").click(function() {
                $(this).toggleClass("fa-heart fa-heart-o");
            });
        });
    </script>
</head>

<body>
    <!-- HEADER -->
    <header>
        <!-- TOP HEADER -->
        <div id="top-header">
            <div class="container">
                @if(app()->getLocale() == 'ar')
                <ul class="header-links pull-right">
                @else
                <ul class="header-links pull-left">
                @endif
                    <li class="top-header-li"><a href="#"><i class="fa fa-phone"></i>8004422221</a></li>
                    <li class="top-header-li"><a href="#"><i class="fa fa-envelope-o"></i> info@alsaifco-ksa.com</a></li>
                    <li>
                     <a style="margin: 5px;" href="{{ LaravelLocalization::getLocalizedURL('en', null, [], true) }}">E &nbsp; <img style="max-width: 18%;" src="{{asset('/front/images/usa.png')}}" alt=""></a>
                     <a style="margin: 10px;"  href="{{ LaravelLocalization::getLocalizedURL('ar', null, [], true) }}"><img style=" max-width: 18%;" src="{{asset('/front/images/ksa.png')}}" alt=""> &nbsp; ع</a>
                    </li>
                    <!--<li><a  rel="alternate" hreflang="ar"  href="{{ LaravelLocalization::getLocalizedURL('ar', null, [], true) }}" class="dropdown-item">{{ trans('layouts/header.ar') }}</a><img src="/front/images/flag_sa.png" style="width:2.5rem;margin-left:5px;" alt=""/></li>-->
                   
                </ul>
                 @if(app()->getLocale() == 'ar')
                 <ul class="header-links pull-left">
                 @else
                <ul class="header-links pull-right">
                @endif    
                    <li><svg style="color: white;" xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                            fill="currentColor" class="bi bi-geo-alt" viewBox="0 0 16 16">
                            <path
                                d="M12.166 8.94c-.524 1.062-1.234 2.12-1.96 3.07A31.493 31.493 0 0 1 8 14.58a31.481 31.481 0 0 1-2.206-2.57c-.726-.95-1.436-2.008-1.96-3.07C3.304 7.867 3 6.862 3 6a5 5 0 0 1 10 0c0 .862-.305 1.867-.834 2.94M8 16s6-5.686 6-10A6 6 0 0 0 2 6c0 4.314 6 10 6 10" />
                            <path d="M8 8a2 2 0 1 1 0-4 2 2 0 0 1 0 4m0 1a3 3 0 1 0 0-6 3 3 0 0 0 0 6" />
                        </svg> <a href="{{ route('order.track') }}">{{trans('layouts/header.OrderTracking')}}</a>
                    </li>
                    <li><svg style="color: white;" xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                            fill="currentColor" class="bi bi-power" viewBox="0 0 16 16">
                            <path d="M7.5 1v7h1V1z" />
                            <path
                                d="M3 8.812a4.999 4.999 0 0 1 2.578-4.375l-.485-.874A6 6 0 1 0 11 3.616l-.501.865A5 5 0 1 1 3 8.812" />
                        </svg><a href="#">{{trans('layouts/header.login')}} /</a><a href="#">{{trans('layouts/header.register')}}</a></li>

                </ul>
            </div>
        </div>
        <!-- /TOP HEADER -->

        <!-- MAIN HEADER -->
         @if(app()->getLocale() == 'ar')
         <div id="header">
            <!-- container -->
            <div class="container">
                <!-- row -->
                <div class="row">
                        <!-- ACCOUNT -->
                    <div class="col-md-3 clearfix">
                        <div class="header-ctn">
                            <!-- Wishlist -->
                            <div>
                                <a href="#">
                                    <i class="fa fa-heart-o"></i>
                                    <span>{{trans('layouts/header.wishlist')}}</span>
                                    <div class="qty">2</div>
                                </a>
                            </div>
                            <!-- /Wishlist -->

                            <!-- Cart -->
                            <div class="dropdown">
                                <a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true">
                                    <i class="fa fa-shopping-cart"></i>
                                    <span>{{trans('layouts/header.YourCart')}}</span>
                                    <div class="qty">3</div>
                                </a>
                                <div class="cart-dropdown">
                                    <div class="cart-list">
                                        <div class="product-widget">
                                            <div class="product-img">
                                                <img src="{{ asset('front//img/product01.png') }}" alt="">
                                            </div>
                                            <div class="product-body">
                                                <h3 class="product-name"><a href="#">product name goes here</a>
                                                </h3>
                                                <h4 class="product-price"><span class="qty">1x</span>$980.00</h4>
                                            </div>
                                            <button class="delete"><i class="fa fa-close"></i></button>
                                        </div>

                                        <div class="product-widget">
                                            <div class="product-img">
                                                <img src="{{ asset('front//img/product02.png') }}" alt="">
                                            </div>
                                            <div class="product-body">
                                                <h3 class="product-name"><a href="#">product name goes here</a>
                                                </h3>
                                                <h4 class="product-price"><span class="qty">3x</span>$980.00</h4>
                                            </div>
                                            <button class="delete"><i class="fa fa-close"></i></button>
                                        </div>
                                    </div>
                                    <div class="cart-summary">
                                        <small>3 Item(s) selected</small>
                                        <h5>SUBTOTAL: $2940.00</h5>
                                    </div>
                                    <div class="cart-btns">
                                        <a href="#">View Cart</a>
                                        <a href="#">Checkout <i class="fa fa-arrow-circle-right"></i></a>
                                    </div>
                                </div>
                            </div>
                            <!-- /Cart -->

                            <!-- Menu Toogle -->
                            <div class="menu-toggle">
                                <a href="#">
                                    <i class="fa fa-bars"></i>
                                    <span>{{trans('layouts/header.menu')}}</span>
                                </a>
                            </div>
                            <!-- /Menu Toogle -->
                        </div>
                    </div>
                    <!-- /ACCOUNT -->

                    <!-- SEARCH BAR -->
                    <div class="col-md-6">
                        <div class="header-search">
                            <form>
                                <select class="input-select">
                                    <option value="0">{{trans('layouts/header.allcategories')}}</option>
                                    <option value="1">Category 01</option>
                                    <option value="1">Category 02</option>
                                </select>
                                <input class="input" placeholder="{{trans('layouts/header.searchhere')}}">
                                <button class="search-btn">{{trans('layouts/header.search')}}</button>
                            </form>
                        </div>
                    </div>
                    <!-- /SEARCH BAR -->
                    <!-- LOGO -->
                    <div class="col-md-3">
                        <div class="header-logo">
                            <a href="https://alsaifco-ksa.com/en"><img
                                    src="https://alsaifco-ksa.com/Dashboard/assets/Front/assets/img/alsaif.png"
                                    alt="logo" style="padding: 0; margin: 0;height: 140px; "></a>
                        </div>
                    </div>
                    <!-- /LOGO -->
                
                </div>
                <!-- row -->
            </div>
            <!-- container -->
        </div>
         @else
        <div id="header">
            <!-- container -->
            <div class="container">
                <!-- row -->
                <div class="row">
                    <!-- LOGO -->
                    <div class="col-md-3">
                        <div class="header-logo">
                            <a href="https://alsaifco-ksa.com/en"><img
                                    src="https://alsaifco-ksa.com/Dashboard/assets/Front/assets/img/alsaif.png"
                                    alt="logo" style="padding: 0; margin: 0;height: 140px; "></a>
                        </div>
                    </div>
                    <!-- /LOGO -->

                    <!-- SEARCH BAR -->
                    <div class="col-md-6">
                        <div class="header-search">
                            <form>
                                <select class="input-select">
                                    <option value="0">{{trans('layouts/header.allcategories')}}</option>
                                    <option value="1">Category 01</option>
                                    <option value="1">Category 02</option>
                                </select>
                                <input class="input" placeholder="{{trans('layouts/header.searchhere')}}">
                                <button class="search-btn">{{trans('layouts/header.search')}}</button>
                            </form>
                        </div>
                    </div>
                    <!-- /SEARCH BAR -->

                    <!-- ACCOUNT -->
                    <div class="col-md-3 clearfix">
                        <div class="header-ctn">
                            <!-- Wishlist -->
                            <div>
                                <a href="#">
                                    <i class="fa fa-heart-o"></i>
                                    <span>{{trans('layouts/header.wishlist')}}</span>
                                    <div class="qty">2</div>
                                </a>
                            </div>
                            <!-- /Wishlist -->

                            <!-- Cart -->
                            <div class="dropdown">
                                <a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true">
                                    <i class="fa fa-shopping-cart"></i>
                                    <span>{{trans('layouts/header.YourCart')}}</span>
                                    <div class="qty">3</div>
                                </a>
                                <div class="cart-dropdown">
                                    <div class="cart-list">
                                        <div class="product-widget">
                                            <div class="product-img">
                                                <img src="{{ asset('front//img/product01.png') }}" alt="">
                                            </div>
                                            <div class="product-body">
                                                <h3 class="product-name"><a href="#">product name goes here</a>
                                                </h3>
                                                <h4 class="product-price"><span class="qty">1x</span>$980.00</h4>
                                            </div>
                                            <button class="delete"><i class="fa fa-close"></i></button>
                                        </div>

                                        <div class="product-widget">
                                            <div class="product-img">
                                                <img src="{{ asset('front//img/product02.png') }}" alt="">
                                            </div>
                                            <div class="product-body">
                                                <h3 class="product-name"><a href="#">product name goes here</a>
                                                </h3>
                                                <h4 class="product-price"><span class="qty">3x</span>$980.00</h4>
                                            </div>
                                            <button class="delete"><i class="fa fa-close"></i></button>
                                        </div>
                                    </div>
                                    <div class="cart-summary">
                                        <small>3 Item(s) selected</small>
                                        <h5>SUBTOTAL: $2940.00</h5>
                                    </div>
                                    <div class="cart-btns">
                                        <a href="#">View Cart</a>
                                        <a href="#">Checkout <i class="fa fa-arrow-circle-right"></i></a>
                                    </div>
                                </div>
                            </div>
                            <!-- /Cart -->

                            <!-- Menu Toogle -->
                            <div class="menu-toggle">
                                <a href="#">
                                    <i class="fa fa-bars"></i>
                                    <span>{{trans('layouts/header.menu')}}</span>
                                </a>
                            </div>
                            <!-- /Menu Toogle -->
                        </div>
                    </div>
                    <!-- /ACCOUNT -->
                </div>
                <!-- row -->
            </div>
            <!-- container -->
        </div>
        @endif
        <!-- /MAIN HEADER -->
    </header>
    <!-- /HEADER -->

    <!-- NAVIGATION -->
    <nav id="navigation"
        style="box-shadow: 0 3px 1px -2px rgba(0,0,0,.2), 0 2px 2px 0 rgba(0,0,0,.14), 0 1px 5px 0 rgba(0,0,0,.12);">
        <!-- container -->
        <div class="container">
            <!-- responsive-nav -->
            <div id="responsive-nav">
                <!-- NAV -->
                <ul class="main-nav nav navbar-nav">
                    {{-- <li class="active"><a href="#">Home</a></li>
                    <li><a href="#">Hot Deals</a></li> --}}
                    <li class="dropdown dd-main"><a href="#" class="dropdown-toggle" data-toggle="dropdown">{{trans('layouts/header.monitors')}}</a>
                       <ul class="dropdown-menu dropdown-menu-custom">
				<li><a href="#">{{trans('layouts/header.monitors')}}</a></li>
				<li><a href="#">{{trans('layouts/header.projector')}}</a></li>
			  </ul>
                    </li>
                    <li class="dropdown dd-main"><a href="#"  class="dropdown-toggle" data-toggle="dropdown">{{trans('layouts/header.wireless')}}</a>
                     <ul class="dropdown-menu dropdown-menu-custom">
			     	<li><a href="#">{{trans('layouts/header.Router')}}</a></li>
					<li><a href="#">{{trans('layouts/header.Adaptors')}}</a></li>
						<li><a href="#">{{trans('layouts/header.AccessPoint')}}</a></li>
					<li><a href="#">{{trans('layouts/header.Switch')}}</a></li>
			  </ul>
                    </li>
                    <li class="dropdown dd-main"><a href="#"  class="dropdown-toggle" data-toggle="dropdown">{{trans('layouts/header.accessories')}}</a>
                     <ul class="dropdown-menu dropdown-menu-custom">
				<li><a href="#">{{trans('layouts/header.LapTopBags')}}</a></li>
				<li><a href="#">{{trans('layouts/header.MobileCharger')}}</a></li>
				<li><a href="#">{{trans('layouts/header.keyboard')}}</a></li>
				<li><a href="#">{{trans('layouts/header.mouses')}}</a></li>
				<li><a href="#">{{trans('layouts/header.Headphones')}}</a></li>
				<li><a href="#">{{trans('layouts/header.Speaker')}}</a></li>
				<li><a href="#">{{trans('layouts/header.PowerExtension')}}</a></li>
				<li><a href="#">{{trans('layouts/header.Cables')}}</a></li>
			  </ul>
                    </li>
                    <li class="dropdown dd-main"><a href="#"  class="dropdown-toggle" data-toggle="dropdown">{{trans('layouts/header.Cameras')}}</a>
                     <ul class="dropdown-menu dropdown-menu-custom">
				     <li><a href="#">{{trans('layouts/header.SurveillanceCameras')}}</a></li>
			  </ul>
                    </li>
                    <li class="dropdown dd-main"><a href="#"  class="dropdown-toggle" data-toggle="dropdown">{{trans('layouts/header.StoragesDevices')}}</a>
                     <ul class="dropdown-menu dropdown-menu-custom">
				<li><a href="#">{{trans('layouts/header.harddisks')}}</a></li>
				<li><a href="#">{{trans('layouts/header.MemoryCard')}}</a></li>
				<li><a href="#">{{trans('layouts/header.Flashmemory')}}</a></li>
			  </ul>
                    </li>
                     <li class="dropdown dd-main"><a href="#"  class="dropdown-toggle" data-toggle="dropdown">{{trans('layouts/header.Electronics')}}</a>
                      <ul class="dropdown-menu dropdown-menu-custom">
				<li><a href="#">{{trans('layouts/header.labtopandnotebook')}}</a></li>
				<li><a href="#">{{trans('layouts/header.Desktops')}}</a></li>
				<li><a href="#">{{trans('layouts/header.computercomponents')}}</a></li>
				<li><a href="#">{{trans('layouts/header.FingerPrint')}}</a></li>
				<li><a href="#">{{trans('layouts/header.pos')}}</a></li>
			  </ul>
                     </li>
                      <li class="dropdown dd-main"><a href="#"  class="dropdown-toggle" data-toggle="dropdown">{{trans('layouts/header.PrintersandScanners')}}</a>
                       <ul class="dropdown-menu dropdown-menu-custom">
				<li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown">{{trans('layouts/header.printers')}}</a>
					<ul class="dropdown-menu dropdown-menu-custom-sub">
						<li><a href="#">{{trans('layouts/header.Laserjet')}}</a></li>
						<li><a href="#">{{trans('layouts/header.inkjet')}}</a></li>
							<li><a href="#">{{trans('layouts/header.all in one printers')}}</a></li>
						<li><a href="#">{{trans('layouts/header.Inks')}}</a></li>
					</ul>
				</li>
					<li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown">{{trans('layouts/header.scanner')}}</a>
					<ul class="dropdown-menu dropdown-menu-custom-sub">
						<li><a href="#">{{trans('layouts/header.Casher')}}</a></li>
					</ul>
				</li>
			
			  </ul>
                      </li>
                </ul>
                <!-- /NAV -->
            </div>
            <!-- /responsive-nav -->
        </div>
        <!-- /container -->
    </nav>
    <!-- /NAVIGATION -->

    <!-- SECTION -->

    {{-- Slider  --}}

    <div style=" padding-right: inherit;
    padding-left: inherit;" class="container-fluid">

        <div id="myCarousel" class="carousel slide" data-ride="carousel">
            <!-- Indicators -->
            <ol class="carousel-indicators">
                <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
                <li data-target="#myCarousel" data-slide-to="1"></li>
                <li data-target="#myCarousel" data-slide-to="2"></li>
            </ol>

            <!-- Wrapper for slides -->
            <div class="carousel-inner">
                <div class="item active">
                     @if(app()->getLocale() == 'ar')
                      <img src="{{ asset('front/images/Banner/1.jpg') }}" alt="Los Angeles" style="width:100%;">
                     @else
                    <img src="{{ asset('front/images/Banner/1 EN.jpg') }}" alt="Los Angeles" style="width:100%;">
                    @endif
                </div>

                <div class="item">
                     @if(app()->getLocale() == 'ar')
                      <img src="{{ asset('front/images/Banner/2.jpg') }}" alt="Los Angeles" style="width:100%;">
                     @else
                    <img src="{{ asset('front/images/Banner/2 EN.jpg') }}" alt="Chicago" style="width:100%;">
                    @endif
                </div>

                <div class="item">
                     @if(app()->getLocale() == 'ar')
                      <img src="{{ asset('front/images/Banner/3.jpg') }}" alt="Los Angeles" style="width:100%;">
                     @else
                    <img src="{{ asset('front/images/Banner/3 EN.jpg') }}" alt="New york" style="width:100%;">
                    @endif
                </div>
            </div>

            <!-- Left and right controls -->
            <a class="left carousel-control" href="#myCarousel" data-slide="prev">
                <span class="glyphicon glyphicon-chevron-left"></span>
                <span class="sr-only">Previous</span>
            </a>
            <a class="right carousel-control" href="#myCarousel" data-slide="next">
                <span class="glyphicon glyphicon-chevron-right"></span>
                <span class="sr-only">Next</span>
            </a>
        </div>
    </div>

    <!-- SECTION -->
    <div class="section">
        <!-- container -->
        <div class="container">
            <!-- row -->
            <div class="row">

                <!-- section title -->
                <div class="col-md-12">
                    <div class="section-title">
                        <h3 class="title">{{trans('home/body.RECOMMENDEDCOLLECTIONS')}}
                        </h3>
                        
                    </div>
                </div>
                <!-- /section title -->

                <!-- Products tab & slick -->
                <div class="col-md-12">
                    <div class="row">
                        <div class="products-tabs">
                            <!-- tab -->
                            <div id="tab1" class="tab-pane active">
                                 @if(app()->getLocale() == 'ar')
                                   <div class="products-slick" data-nav="#slick-nav-1" dir="rtl">
                                 @else
                                <div class="products-slick" data-nav="#slick-nav-1">
                                 @endif
                                    <!-- product -->
                                    <div class="product">
                                        <div class="product-img">
                                             <div class="product-btns">
                                          <button class="add-to-wishlist"><i class="fa fa-heart-o"></i><span
                                                        class="tooltipp">add to wishlist</span></button>
                                                        </div>
                                            <img src="{{ asset('front//img/product01.png') }}" alt="">
                                            <div class="product-label">
                                                <span class="sale">-30%</span>
                                                <span class="new">{{trans('home/body.new')}}</span>
                                            </div>
                                        </div>
                                        <div class="product-body">
                                            <p class="product-category">Category</p>
                                            <h3 class="product-name"><a href="#">product name goes here</a></h3>
                                            <h4 class="product-price">$980.00 <del
                                                    class="product-old-price">$990.00</del></h4>
                                            <div class="product-rating">
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                            </div>
                                              <div class="product-btns">
                                                <!--<button class="add-to-wishlist"><i class="fa fa-heart-o"></i><span-->
                                                <!--        class="tooltipp">add to wishlist</span></button>-->
                                                <button class="add-to-compare"><i class="fa fa-exchange"></i><span
                                                        class="tooltipp">add to compare</span></button> 
                                                <button type="button"
                                                    style="background-color: #642221; width:auto;  text-transform: uppercase; font-weight: 700;border-radius: 40px;text-transform: uppercase;font-size:13px;padding:0px 25px 5px 25px;"
                                                    class="btn btn-danger"> <span>{{trans('home/body.addtocart')}}</span></button>

                                                <button class="quick-view"><i class="fa fa-eye"></i><span
                                                        class="tooltipp">quick view</span></button>
                                            </div>
                                        </div>
                                        <!--<div class="add-to-cart">-->
                                        <!--    <button class="add-to-cart-btn"><i class="fa fa-shopping-cart"></i> add to-->
                                        <!--        cart</button>-->
                                        <!--</div>-->
                                    </div>
                                    <!-- /product -->

                                    <!-- product -->
                                    <div class="product">
                                        <div class="product-img">
                                             <div class="product-btns">
                                             <button class="add-to-wishlist"><i class="fa fa-heart-o"></i><span
                                                        class="tooltipp">add to wishlist</span></button>
                                                        </div>
                                            <img src="{{ asset('front//img/product02.png') }}" alt="">
                                            <div class="product-label">
                                                <span class="new">{{trans('home/body.new')}}</span>
                                            </div>
                                        </div>
                                        <div class="product-body">
                                            <p class="product-category">Category</p>
                                            <h3 class="product-name"><a href="#">product name goes here</a></h3>
                                            <h4 class="product-price">$980.00 <del
                                                    class="product-old-price">$990.00</del></h4>
                                            <div class="product-rating">
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star-o"></i>
                                            </div>
                                             <div class="product-btns">
                                                <!--<button class="add-to-wishlist"><i class="fa fa-heart-o"></i><span-->
                                                <!--        class="tooltipp">add to wishlist</span></button>-->
                                                <button class="add-to-compare"><i class="fa fa-exchange"></i><span
                                                        class="tooltipp">add to compare</span></button> 
                                                <button type="button"
                                                    style="background-color: #642221; width:auto;  text-transform: uppercase; font-weight: 700;border-radius: 40px;text-transform: uppercase;font-size:13px;padding: 0px 25px 5px 25px;"
                                                    class="btn btn-danger">  <span>{{trans('home/body.addtocart')}}</span></button>

                                                <button class="quick-view"><i class="fa fa-eye"></i><span
                                                        class="tooltipp">quick view</span></button>
                                            </div>
                                        </div>
                                        <!--<div class="add-to-cart">-->
                                        <!--    <button class="add-to-cart-btn"><i class="fa fa-shopping-cart"></i> add to-->
                                        <!--        cart</button>-->
                                        <!--</div>-->
                                    </div>
                                    <!-- /product -->

                                    <!-- product -->
                                    <div class="product">
                                        <div class="product-img">
                                             <div class="product-btns">
                                                <button class="add-to-wishlist"><i class="fa fa-heart-o"></i><span
                                                        class="tooltipp">add to wishlist</span></button> 
                                                        </div>
                                            <img src="{{ asset('front//img/product03.png') }}" alt="">
                                            <div class="product-label">
                                                <span class="sale">-30%</span>
                                            </div>
                                        </div>
                                        <div class="product-body">
                                            <p class="product-category">Category</p>
                                            <h3 class="product-name"><a href="#">product name goes here</a></h3>
                                            <h4 class="product-price">$980.00 <del
                                                    class="product-old-price">$990.00</del></h4>
                                            <div class="product-rating">
                                            </div>
                                           
                                              <div class="product-btns">
                                                <!--<button class="add-to-wishlist"><i class="fa fa-heart-o"></i><span-->
                                                <!--        class="tooltipp">add to wishlist</span></button>-->
                                                <button class="add-to-compare"><i class="fa fa-exchange"></i><span
                                                        class="tooltipp">add to compare</span></button> 
                                                <button type="button"
                                                    style="background-color: #642221; width:auto;  text-transform: uppercase; font-weight: 700;border-radius: 40px;text-transform: uppercase;font-size:13px;padding: 0px 25px 5px 25px;"
                                                    class="btn btn-danger">  <span>{{trans('home/body.addtocart')}}</span></button>

                                                <button class="quick-view"><i class="fa fa-eye"></i><span
                                                        class="tooltipp">quick view</span></button>
                                            </div>
                                        </div>
                                        <!--<div class="add-to-cart">-->
                                        <!--    <button class="add-to-cart-btn"><i class="fa fa-shopping-cart"></i> add to-->
                                        <!--        cart</button>-->
                                        <!--</div>-->
                                    </div>
                                    <!-- /product -->

                                    <!-- product -->
                                    <div class="product">
                                        <div class="product-img">
                                             <div class="product-btns">
                                                <button class="add-to-wishlist"><i class="fa fa-heart-o"></i><span
                                                        class="tooltipp">add to wishlist</span></button> 
                                                        </div>
                                            <img src="{{ asset('front//img/product04.png') }}" alt="">
                                        </div>
                                        <div class="product-body">
                                            <p class="product-category">Category</p>
                                            <h3 class="product-name"><a href="#">product name goes here</a></h3>
                                            <h4 class="product-price">$980.00 <del
                                                    class="product-old-price">$990.00</del></h4>
                                            <div class="product-rating">
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                            </div>
                                            <div class="product-btns">
                                                <!--<button class="add-to-wishlist"><i class="fa fa-heart-o"></i><span-->
                                                <!--        class="tooltipp">add to wishlist</span></button>-->
                                                <button class="add-to-compare"><i class="fa fa-exchange"></i><span
                                                        class="tooltipp">add to compare</span></button> 
                                                <button type="button"
                                                    style="background-color: #642221; width:auto;  text-transform: uppercase; font-weight: 700;border-radius: 40px;text-transform: uppercase;font-size:13px;padding:0px 25px 5px 25px;"
                                                    class="btn btn-danger">  <span>{{trans('home/body.addtocart')}}</span></button>

                                                <button class="quick-view"><i class="fa fa-eye"></i><span
                                                        class="tooltipp">quick view</span></button>
                                            </div>
                                        </div>
                                        <!--<div class="add-to-cart">-->
                                        <!--    <button class="add-to-cart-btn"><i class="fa fa-shopping-cart"></i> add to-->
                                        <!--        cart</button>-->
                                        <!--</div>-->
                                    </div>
                                    <!-- /product -->

                                    <!-- product -->
                                    <div class="product">
                                        <div class="product-img">
                                             <div class="product-btns">
                                                <button class="add-to-wishlist"><i class="fa fa-heart-o"></i><span
                                                        class="tooltipp">add to wishlist</span></button> 
                                                        </div>
                                            <img src="{{ asset('front//img/product05.png') }}" alt="">
                                        </div>
                                        <div class="product-body">
                                            <p class="product-category">Category</p>
                                            <h3 class="product-name"><a href="#">product name goes here</a></h3>
                                            <h4 class="product-price">$980.00 <del
                                                    class="product-old-price">$990.00</del></h4>
                                            <div class="product-rating">
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                            </div>
                                            <div class="product-btns">
                                                <!--<button class="add-to-wishlist"><i class="fa fa-heart-o"></i><span-->
                                                <!--        class="tooltipp">add to wishlist</span></button>-->
                                                <button class="add-to-compare"><i class="fa fa-exchange"></i><span
                                                        class="tooltipp">add to compare</span></button> 
                                                <button type="button"
                                                    style="background-color: #642221; width:auto;  text-transform: uppercase; font-weight: 700;border-radius: 40px;text-transform: uppercase;font-size:13px;padding: 0px 25px 5px 25px;"
                                                    class="btn btn-danger">  <span>{{trans('home/body.addtocart')}}</span></button>

                                                <button class="quick-view"><i class="fa fa-eye"></i><span
                                                        class="tooltipp">quick view</span></button>
                                            </div>
                                        </div>
                                        <!--<div class="add-to-cart">-->
                                        <!--    <button class="add-to-cart-btn"><i class="fa fa-shopping-cart"></i> add to-->
                                        <!--        cart</button>-->
                                        <!--</div>-->
                                    </div>
                                    <!-- /product -->
                                </div>
                                <div id="slick-nav-1" class="products-slick-nav"></div>
                            </div>
                            <!-- /tab -->
                        </div>
                    </div>
                </div>
                <!-- Products tab & slick -->
            </div>
            <!-- /row -->
        </div>
        <!-- /container -->
    </div>
    <!-- /SECTION -->

    <!-- HOT DEAL SECTION -->

    <!-- /HOT DEAL SECTION -->

    <!-- SECTION -->
    <div class="section">
        <!-- container -->
        <div class="container">
            <!-- row -->
            <div class="row">

                <!-- section title -->
                <div class="col-md-12">
                    <div class="section-title">
                        <h3 class="title">{{trans('home/body.Latestoffers')}}</h3>
                        <div class="section-nav">
                            {{-- <ul class="section-tab-nav tab-nav">
                                <li class="active"><a data-toggle="tab" href="#tab2">Laptops</a></li>
                                <li><a data-toggle="tab" href="#tab2">Smartphones</a></li>
                                <li><a data-toggle="tab" href="#tab2">Cameras</a></li>
                                <li><a data-toggle="tab" href="#tab2">Accessories</a></li>
                            </ul> --}}
                        </div>
                    </div>
                </div>
                <!-- /section title -->

                <!-- Products tab & slick -->
                <div class="col-md-12">
                    <div class="row">
                        <div class="products-tabs">
                            <!-- tab -->
                            <div id="tab2" class="tab-pane fade in active">
                                @if(app()->getLocale() == 'ar')
                                 <div class="products-slick" data-nav="#slick-nav-2">
                                @else
                                <div class="products-slick" data-nav="#slick-nav-2">
                                @endif    
                                    <!-- product -->
                                    <div class="product">
                                        <div class="product-img">
                                             <div class="product-btns">
                                                <button class="add-to-wishlist"><i class="fa fa-heart-o"></i><span
                                                        class="tooltipp">add to wishlist</span></button> 
                                                        </div>
                                            <img src="{{ asset('front//img/product06.png') }}" alt="">
                                            <div class="product-label">
                                                <span class="sale">-30%</span>
                                                <span class="new">{{trans('home/body.new')}}</span>
                                            </div>
                                        </div>
                                        <div class="product-body">
                                            <p class="product-category">Category</p>
                                            <h3 class="product-name"><a href="#">product name goes here</a></h3>
                                            <h4 class="product-price">$980.00 <del
                                                    class="product-old-price">$990.00</del></h4>
                                            <div class="product-rating">
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                            </div>
                                            <div class="product-btns">
                                                <!--<button class="add-to-wishlist"><i class="fa fa-heart-o"></i><span-->
                                                <!--        class="tooltipp">add to wishlist</span></button>-->
                                                <button class="add-to-compare"><i class="fa fa-exchange"></i><span
                                                        class="tooltipp">add to compare</span></button> 
                                                <button type="button"
                                                    style="background-color: #642221; width:auto;  text-transform: uppercase; font-weight: 700;border-radius: 40px;text-transform: uppercase;font-size:13px;padding:0px 25px 5px 25px;"
                                                    class="btn btn-danger"> {{trans('home/body.addtocart')}}</button>

                                                <button class="quick-view"><i class="fa fa-eye"></i><span
                                                        class="tooltipp">quick view</span></button>
                                            </div>
                                        </div>
                                        <!--<div class="add-to-cart">-->
                                        <!--    <button class="add-to-cart-btn"><i class="fa fa-shopping-cart"></i> add to-->
                                        <!--        cart</button>-->
                                        <!--</div>-->
                                    </div>
                                    <!-- /product -->

                                    <!-- product -->
                                    <div class="product">
                                        <div class="product-img">
                                             <div class="product-btns">
                                                <button class="add-to-wishlist"><i class="fa fa-heart-o"></i><span
                                                        class="tooltipp">add to wishlist</span></button> 
                                                        </div>
                                            <img src="{{ asset('front//img/product07.png') }}" alt="">
                                            <div class="product-label">
                                                <span class="new">{{trans('home/body.new')}}</span>
                                            </div>
                                        </div>
                                        <div class="product-body">
                                            <p class="product-category">Category</p>
                                            <h3 class="product-name"><a href="#">product name goes here</a></h3>
                                            <h4 class="product-price">$980.00 <del
                                                    class="product-old-price">$990.00</del></h4>
                                            <div class="product-rating">
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star-o"></i>
                                            </div>
                                             <div class="product-btns">
                                                <!--<button class="add-to-wishlist"><i class="fa fa-heart-o"></i><span-->
                                                <!--        class="tooltipp">add to wishlist</span></button>-->
                                                <button class="add-to-compare"><i class="fa fa-exchange"></i><span
                                                        class="tooltipp">add to compare</span></button> 
                                                <button type="button"
                                                    style="background-color: #642221; width:auto;  text-transform: uppercase; font-weight: 700;border-radius: 40px;text-transform: uppercase;font-size:13px;padding:0px 25px 5px 25px;"
                                                    class="btn btn-danger"> {{trans('home/body.addtocart')}}</button>

                                                <button class="quick-view"><i class="fa fa-eye"></i><span
                                                        class="tooltipp">quick view</span></button>
                                            </div>
                                        </div>
                                        <!--<div class="add-to-cart">-->
                                        <!--    <button class="add-to-cart-btn"><i class="fa fa-shopping-cart"></i> add to-->
                                        <!--        cart</button>-->
                                        <!--</div>-->
                                    </div>
                                    <!-- /product -->

                                    <!-- product -->
                                    <div class="product">
                                        <div class="product-img">
                                             <div class="product-btns">
                                                <button class="add-to-wishlist"><i class="fa fa-heart-o"></i><span
                                                        class="tooltipp">add to wishlist</span></button>
                                                        </div>
                                            <img src="{{ asset('front//img/product08.png') }}" alt="">
                                            <div class="product-label">
                                                <span class="sale">-30%</span>
                                            </div>
                                        </div>
                                        <div class="product-body">
                                            <p class="product-category">Category</p>
                                            <h3 class="product-name"><a href="#">product name goes here</a></h3>
                                            <h4 class="product-price">$980.00 <del
                                                    class="product-old-price">$990.00</del></h4>
                                            <div class="product-rating">
                                            </div>
                                           <div class="product-btns">
                                                <!--<button class="add-to-wishlist"><i class="fa fa-heart-o"></i><span-->
                                                <!--        class="tooltipp">add to wishlist</span></button>-->
                                                <button class="add-to-compare"><i class="fa fa-exchange"></i><span
                                                        class="tooltipp">add to compare</span></button> 
                                                <button type="button"
                                                    style="background-color: #642221; width:auto;  text-transform: uppercase; font-weight: 700;border-radius: 40px;text-transform: uppercase;font-size:13px;padding:0px 25px 5px 25px;"
                                                    class="btn btn-danger"> {{trans('home/body.addtocart')}}</button>

                                                <button class="quick-view"><i class="fa fa-eye"></i><span
                                                        class="tooltipp">quick view</span></button>
                                            </div>
                                        </div>
                                        <!--<div class="add-to-cart">-->
                                        <!--    <button class="add-to-cart-btn"><i class="fa fa-shopping-cart"></i> add to-->
                                        <!--        cart</button>-->
                                        <!--</div>-->
                                    </div>
                                    <!-- /product -->

                                    <!-- product -->
                                    <div class="product">
                                        <div class="product-img">
                                             <div class="product-btns">
                                                <button class="add-to-wishlist"><i class="fa fa-heart-o"></i><span
                                                        class="tooltipp">add to wishlist</span></button> 
                                                        </div>
                                            <img src="{{ asset('front//img/product09.png') }}" alt="">
                                        </div>
                                        <div class="product-body">
                                            <p class="product-category">Category</p>
                                            <h3 class="product-name"><a href="#">product name goes here</a></h3>
                                            <h4 class="product-price">$980.00 <del
                                                    class="product-old-price">$990.00</del></h4>
                                            <div class="product-rating">
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                            </div>
                                             <div class="product-btns">
                                                <!--<button class="add-to-wishlist"><i class="fa fa-heart-o"></i><span-->
                                                <!--        class="tooltipp">add to wishlist</span></button>-->
                                                <button class="add-to-compare"><i class="fa fa-exchange"></i><span
                                                        class="tooltipp">add to compare</span></button> 
                                                <button type="button"
                                                    style="background-color: #642221; width:auto;  text-transform: uppercase; font-weight: 700;border-radius: 40px;text-transform: uppercase;font-size:13px;padding:0px 25px 5px 25px;"
                                                    class="btn btn-danger"> {{trans('home/body.addtocart')}} </button>

                                                <button class="quick-view"><i class="fa fa-eye"></i><span
                                                        class="tooltipp">quick view</span></button>
                                            </div>
                                        </div>
                                        <!--<div class="add-to-cart">-->
                                        <!--    <button class="add-to-cart-btn"><i class="fa fa-shopping-cart"></i> add to-->
                                        <!--        cart</button>-->
                                        <!--</div>-->
                                    </div>
                                    <!-- /product -->

                                    <!-- product -->
                                    <div class="product">
                                        <div class="product-img">
                                             <div class="product-btns">
                                                    <button class="add-to-wishlist"><i class="fa fa-heart-o"></i><span
                                                        class="tooltipp">add to wishlist</span></button> 
                                                </div>
                                            <img src="{{ asset('front//img/product01.png') }}" alt="">
                                        </div>
                                        <div class="product-body">
                                           
                                            <p class="product-category">Category</p>
                                            <h3 class="product-name"><a href="#">product name goes here</a></h3>
                                            <h4 class="product-price">$980.00 <del
                                                    class="product-old-price">$990.00</del></h4>
                                            <div class="product-rating">
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                            </div>
                                           <div class="product-btns">
                                                <!--<button class="add-to-wishlist"><i class="fa fa-heart-o"></i><span-->
                                                <!--        class="tooltipp">add to wishlist</span></button>-->
                                                <button class="add-to-compare"><i class="fa fa-exchange"></i><span
                                                        class="tooltipp">add to compare</span></button> 
                                                <button type="button"
                                                    style="background-color: #642221; width:auto;  text-transform: uppercase; font-weight: 700;border-radius: 40px;text-transform: uppercase;font-size:13px;padding:0px 25px 5px 25px;"
                                                    class="btn btn-danger"> {{trans('home/body.addtocart')}}</button>

                                                <button class="quick-view"><i class="fa fa-eye"></i><span
                                                        class="tooltipp">quick view</span></button>
                                            </div>
                                        </div>
                                        <!--<div class="add-to-cart">-->
                                        <!--    <button class="add-to-cart-btn"><i class="fa fa-shopping-cart"></i> add to-->
                                        <!--        cart</button>-->
                                        <!--</div>-->
                                    </div>
                                    <!-- /product -->
                                </div>
                                <div id="slick-nav-2" class="products-slick-nav"></div>
                            </div>
                            <!-- /tab -->
                        </div>
                    </div>
                </div>
                <!-- /Products tab & slick -->
            </div>
            <!-- /row -->
        </div>
        <!-- /container -->
    </div>
    <!-- /SECTION -->
    {{-- <div class="beauty_section layout_padding">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-sm-12">
                    <div class="beauty_box">
                        <h1 class="bed_text">Beauty products</h1>
                        <div><img src="{{ asset('front//img/scerrn.webp') }}" class="image_3"></div>
                        <div class="seemore_bt"><a href="#">see More</a></div>
                    </div>
                </div>
                <div class="col-lg-8 col-sm-12">
                    <div class="beauty_box_1">
                        <h1 class="bed_text_1">Explore trending electronics</h1>
                        <div><img src="{{ asset('front//img/product03.png') }}" class="image_3"></div>
                        <div class="seemore_bt_1"><a href="#">see More</a></div>
                    </div>
                </div>
            </div>
        </div>
    </div> --}}

    <div class="product_section layout_padding">
        <div class="container">
            <h1 class="feature_taital">{{trans('home/body.PopularCategories')}}</h1>
            {{-- <p class="feature_text">It is a long established fact that a reader will be distracted by the readable
                content of a page when looking</p> --}}
            <div class="product_section_2">
                <div class="row">
                    <div class="col-sm-3">
                        <div class="feature_box">
                              <h1 class="readable_text">{{trans('home/body.surveillancecameras')}}</h1>
                               <div><img src="{{ asset('front//img/camera.png') }}" class="image_7"></div>
                            
                        </div>
                        <div class="feature_box_1">
                            <h1 class="readable_text">{{trans('home/body.projector')}}</h1>
                            <div><img src="{{ asset('front//img/projector.png') }}" class="image_7"></div>
                        </div>

                    </div>
                    <div class="col-sm-3">
                        <div class="feature_box">
                            <h1 class="readable_text">{{trans('home/body.printer')}}</h1>
                            <div><img src="{{ asset('front//img/printer.png') }}" class="image_7"></div>
                        </div>
                        <div class="feature_box_1">
                            <h1 class="readable_text">{{trans('home/body.labtop')}}</h1>
                            <div><img src="{{ asset('front//img/laptop.png') }}" class="image_7"></div>
                        </div>

                    </div>
                    <div class="col-sm-6">
                        <div class="feature_box_2">
                             <h1 class="readable_text">{{trans('home/body.computeraccessories')}}</h1>
                            <div><img src="{{ asset('front//img/computer-accessories.png') }}" class="image_8"></div>
                            <!--<div class="seemore_bt"><a href="#">see More</a></div>-->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!-- SECTION -->
    {{-- <div class="section">
        <!-- container -->
        <div class="container">
            <!-- row -->
            <div class="row">
                <div class="col-md-4 col-xs-6">
                    <div class="section-title">
                        <h4 class="title">Top selling</h4>
                        <div class="section-nav">
                            <div id="slick-nav-3" class="products-slick-nav"></div>
                        </div>
                    </div>

                    <div class="products-widget-slick" data-nav="#slick-nav-3">
                        <div>
                            <!-- product widget -->
                            <div class="product-widget">
                                <div class="product-img">
                                    <img src="img//product07.png" alt="">
                                </div>
                                <div class="product-body">
                                    <p class="product-category">Category</p>
                                    <h3 class="product-name"><a href="#">product name goes here</a></h3>
                                    <h4 class="product-price">$980.00 <del class="product-old-price">$990.00</del>
                                    </h4>
                                </div>
                            </div>
                            <!-- /product widget -->

                            <!-- product widget -->
                            <div class="product-widget">
                                <div class="product-img">
                                    <img src="{{ asset('front//img/product08.png') }}" alt="">
                                </div>
                                <div class="product-body">
                                    <p class="product-category">Category</p>
                                    <h3 class="product-name"><a href="#">product name goes here</a></h3>
                                    <h4 class="product-price">$980.00 <del class="product-old-price">$990.00</del>
                                    </h4>
                                </div>
                            </div>
                            <!-- /product widget -->

                            <!-- product widget -->
                            <div class="product-widget">
                                <div class="product-img">
                                    <img src="{{ asset('front//img/product09.png') }}" alt="">
                                </div>
                                <div class="product-body">
                                    <p class="product-category">Category</p>
                                    <h3 class="product-name"><a href="#">product name goes here</a></h3>
                                    <h4 class="product-price">$980.00 <del class="product-old-price">$990.00</del>
                                    </h4>
                                </div>
                            </div>
                            <!-- product widget -->
                        </div>

                        <div>
                            <!-- product widget -->
                            <div class="product-widget">
                                <div class="product-img">
                                    <img src="{{ asset('front//img/product01.png') }}" alt="">
                                </div>
                                <div class="product-body">
                                    <p class="product-category">Category</p>
                                    <h3 class="product-name"><a href="#">product name goes here</a></h3>
                                    <h4 class="product-price">$980.00 <del class="product-old-price">$990.00</del>
                                    </h4>
                                </div>
                            </div>
                            <!-- /product widget -->

                            <!-- product widget -->
                            <div class="product-widget">
                                <div class="product-img">
                                    <img src="{{ asset('front//img/product02.png') }}" alt="">
                                </div>
                                <div class="product-body">
                                    <p class="product-category">Category</p>
                                    <h3 class="product-name"><a href="#">product name goes here</a></h3>
                                    <h4 class="product-price">$980.00 <del class="product-old-price">$990.00</del>
                                    </h4>
                                </div>
                            </div>
                            <!-- /product widget -->

                            <!-- product widget -->
                            <div class="product-widget">
                                <div class="product-img">
                                    <img src="{{ asset('front//img/product03.png') }}" alt="">
                                </div>
                                <div class="product-body">
                                    <p class="product-category">Category</p>
                                    <h3 class="product-name"><a href="#">product name goes here</a></h3>
                                    <h4 class="product-price">$980.00 <del class="product-old-price">$990.00</del>
                                    </h4>
                                </div>
                            </div>
                            <!-- product widget -->
                        </div>
                    </div>
                </div>

                <div class="col-md-4 col-xs-6">
                    <div class="section-title">
                        <h4 class="title">Top selling</h4>
                        <div class="section-nav">
                            <div id="slick-nav-4" class="products-slick-nav"></div>
                        </div>
                    </div>

                    <div class="products-widget-slick" data-nav="#slick-nav-4">
                        <div>
                            <!-- product widget -->
                            <div class="product-widget">
                                <div class="product-img">
                                    <img src="{{ asset('front//img/product04.pn') }}g" alt="">
                                </div>
                                <div class="product-body">
                                    <p class="product-category">Category</p>
                                    <h3 class="product-name"><a href="#">product name goes here</a></h3>
                                    <h4 class="product-price">$980.00 <del class="product-old-price">$990.00</del>
                                    </h4>
                                </div>
                            </div>
                            <!-- /product widget -->

                            <!-- product widget -->
                            <div class="product-widget">
                                <div class="product-img">
                                    <img src="{{ asset('front//img/product05.png') }}" alt="">
                                </div>
                                <div class="product-body">
                                    <p class="product-category">Category</p>
                                    <h3 class="product-name"><a href="#">product name goes here</a></h3>
                                    <h4 class="product-price">$980.00 <del class="product-old-price">$990.00</del>
                                    </h4>
                                </div>
                            </div>
                            <!-- /product widget -->

                            <!-- product widget -->
                            <div class="product-widget">
                                <div class="product-img">
                                    <img src="{{ asset('front//img/product06.png') }}" alt="">
                                </div>
                                <div class="product-body">
                                    <p class="product-category">Category</p>
                                    <h3 class="product-name"><a href="#">product name goes here</a></h3>
                                    <h4 class="product-price">$980.00 <del class="product-old-price">$990.00</del>
                                    </h4>
                                </div>
                            </div>
                            <!-- product widget -->
                        </div>

                        <div>
                            <!-- product widget -->
                            <div class="product-widget">
                                <div class="product-img">
                                    <img src="{{ asset('front//img/product07.png') }}" alt="">
                                </div>
                                <div class="product-body">
                                    <p class="product-category">Category</p>
                                    <h3 class="product-name"><a href="#">product name goes here</a></h3>
                                    <h4 class="product-price">$980.00 <del class="product-old-price">$990.00</del>
                                    </h4>
                                </div>
                            </div>
                            <!-- /product widget -->

                            <!-- product widget -->
                            <div class="product-widget">
                                <div class="product-img">
                                    <img src="{{ asset('front//img/product08.png') }}" alt="">
                                </div>
                                <div class="product-body">
                                    <p class="product-category">Category</p>
                                    <h3 class="product-name"><a href="#">product name goes here</a></h3>
                                    <h4 class="product-price">$980.00 <del class="product-old-price">$990.00</del>
                                    </h4>
                                </div>
                            </div>
                            <!-- /product widget -->

                            <!-- product widget -->
                            <div class="product-widget">
                                <div class="product-img">
                                    <img src="{{ asset('front//img/product09.png') }}" alt="">
                                </div>
                                <div class="product-body">
                                    <p class="product-category">Category</p>
                                    <h3 class="product-name"><a href="#">product name goes here</a></h3>
                                    <h4 class="product-price">$980.00 <del class="product-old-price">$990.00</del>
                                    </h4>
                                </div>
                            </div>
                            <!-- product widget -->
                        </div>
                    </div>
                </div>

                <div class="clearfix visible-sm visible-xs"></div>

                <div class="col-md-4 col-xs-6">
                    <div class="section-title">
                        <h4 class="title">Top selling</h4>
                        <div class="section-nav">
                            <div id="slick-nav-5" class="products-slick-nav"></div>
                        </div>
                    </div>

                    <div class="products-widget-slick" data-nav="#slick-nav-5">
                        <div>
                            <!-- product widget -->
                            <div class="product-widget">
                                <div class="product-img">
                                    <img src="{{ asset('front//img/product01.png') }}" alt="">
                                </div>
                                <div class="product-body">
                                    <p class="product-category">Category</p>
                                    <h3 class="product-name"><a href="#">product name goes here</a></h3>
                                    <h4 class="product-price">$980.00 <del class="product-old-price">$990.00</del>
                                    </h4>
                                </div>
                            </div>
                            <!-- /product widget -->

                            <!-- product widget -->
                            <div class="product-widget">
                                <div class="product-img">
                                    <img src="{{ asset('front//img/product02.png') }}" alt="">
                                </div>
                                <div class="product-body">
                                    <p class="product-category">Category</p>
                                    <h3 class="product-name"><a href="#">product name goes here</a></h3>
                                    <h4 class="product-price">$980.00 <del class="product-old-price">$990.00</del>
                                    </h4>
                                </div>
                            </div>
                            <!-- /product widget -->

                            <!-- product widget -->
                            <div class="product-widget">
                                <div class="product-img">
                                    <img src="{{ asset('front//img/product03.png') }}" alt="">
                                </div>
                                <div class="product-body">
                                    <p class="product-category">Category</p>
                                    <h3 class="product-name"><a href="#">product name goes here</a></h3>
                                    <h4 class="product-price">$980.00 <del class="product-old-price">$990.00</del>
                                    </h4>
                                </div>
                            </div>
                            <!-- product widget -->
                        </div>

                        <div>
                            <!-- product widget -->
                            <div class="product-widget">
                                <div class="product-img">
                                    <img src="{{ asset('front//img/product04.png') }}" alt="">
                                </div>
                                <div class="product-body">
                                    <p class="product-category">Category</p>
                                    <h3 class="product-name"><a href="#">product name goes here</a></h3>
                                    <h4 class="product-price">$980.00 <del class="product-old-price">$990.00</del>
                                    </h4>
                                </div>
                            </div>
                            <!-- /product widget -->

                            <!-- product widget -->
                            <div class="product-widget">
                                <div class="product-img">
                                    <img src="{{ asset('front//img/product05.png') }}" alt="">
                                </div>
                                <div class="product-body">
                                    <p class="product-category">Category</p>
                                    <h3 class="product-name"><a href="#">product name goes here</a></h3>
                                    <h4 class="product-price">$980.00 <del class="product-old-price">$990.00</del>
                                    </h4>
                                </div>
                            </div>
                            <!-- /product widget -->

                            <!-- product widget -->
                            <div class="product-widget">
                                <div class="product-img">
                                    <img src="{{ asset('front//img/product06.png') }}" alt="">
                                </div>
                                <div class="product-body">
                                    <p class="product-category">Category</p>
                                    <h3 class="product-name"><a href="#">product name goes here</a></h3>
                                    <h4 class="product-price">$980.00 <del class="product-old-price">$990.00</del>
                                    </h4>
                                </div>
                            </div>
                            <!-- product widget -->
                        </div>
                    </div>
                </div>

            </div>
            <!-- /row -->
        </div>
        <!-- /container -->
    </div> --}}
    <!-- /SECTION -->

    <!-- NEWSLETTER -->
    {{-- <div id="newsletter" class="section">
        <!-- container -->
        <div class="container">
            <!-- row -->
            <div class="row">
                <div class="col-md-12">
                    <div class="newsletter">
                        <p>Sign Up for the <strong>NEWSLETTER</strong></p>
                        <form>
                            <input class="input" type="email" placeholder="Enter Your Email">
                            <button class="newsletter-btn"><i class="fa fa-envelope"></i> Subscribe</button>
                        </form>
                        <ul class="newsletter-follow">
                            <li>
                                <a href="#"><i class="fa fa-facebook"></i></a>
                            </li>
                            <li>
                                <a href="#"><i class="fa fa-twitter"></i></a>
                            </li>
                            <li>
                                <a href="#"><i class="fa fa-instagram"></i></a>
                            </li>
                            <li>
                                <a href="#"><i class="fa fa-pinterest"></i></a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <!-- /row -->
        </div>
        <!-- /container -->
    </div> --}}
    <!-- /NEWSLETTER -->

    <!-- FOOTER -->
    <footer id="footer">
        <!-- top footer -->
        <div class="section">
            <!-- container -->
            <div class="container">
                <!-- row -->
                <div class="row">
                    <div class="col-md-6 col-xs-6">
                        <div class="footer">
                            <h3 class="footer-title">{{trans('layouts/footer.aboutus')}}</h3>
                            <p>{{trans('layouts/footer.aboutusdesc')}}</p>
                            <ul class="footer-links">
                                <li><a href="#"><i class="fa fa-map-marker"></i>{{trans('layouts/footer.address')}}</a></li>
                                <li><a href="#"><i class="fa fa-phone"></i>8004422221</a></li>
                                <li><a href="#"><i class="fa fa-envelope-o"></i>info@alsaifco-ksa.com</a></li>
                            </ul>
                        </div>
                    </div>

                    <div class="col-md-3 col-xs-6">
                        <div class="footer">
                            <h3 class="footer-title">{{trans('layouts/footer.LetUsHelpYou')}}</h3>
                            <ul class="footer-links">
                                <li><a href="#">{{trans('layouts/footer.AboutUS')}}</a></li>
                                <li><a href="#">{{trans('layouts/footer.ContactUs')}}</a></li>
                                <li><a href="#">{{trans('layouts/footer.ReturnPolicy')}}</a></li>
                                <li><a href="#">{{trans('layouts/footer.PrivacyPolicy')}}</a></li>
                                <li><a href="#">{{trans('layouts/footer.termsandconditions')}}</a></li>
                            </ul>
                        </div>
                    </div>

                    <div class="clearfix visible-xs"></div>

                    <div class="col-md-3 col-xs-6">
                        <div class="footer">
                            <h3 class="footer-title">{{trans('layouts/footer.ShopWithUs')}}</h3>
                            <ul class="footer-links">
                                <li><a href="#">{{trans('layouts/footer.myaccount')}}</a></li>
                                <li><a href="#">{{trans('layouts/footer.yourcart')}}</a></li>
                                <li><a href="#">{{trans('layouts/footer.wishlist')}}</a></li>
                                <li><a href="#">{{trans('layouts/footer.trackorder')}}</a></li>
                                <li><a href="#">{{trans('layouts/footer.help')}}</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <!-- /row -->
            </div>
            <!-- /container -->
        </div>
        <!-- /top footer -->

        <!-- bottom footer -->
        <div id="bottom-footer" class="section">
            <div class="container">
                <!-- row -->
                <div class="row">
                    <div class="col-md-12 text-center">
                        <ul class="footer-payments">
                            <li><a href="#"><i class="fa fa-cc-visa"></i></a></li>
                            <li><a href="#"><i class="fa fa-credit-card"></i></a></li>
                            <li><a href="#"><i class="fa fa-cc-paypal"></i></a></li>
                            <li><a href="#"><i class="fa fa-cc-mastercard"></i></a></li>
                            <li><a href="#"><i class="fa fa-cc-discover"></i></a></li>
                            <li><a href="#"><i class="fa fa-cc-amex"></i></a></li>
                        </ul>
                        <span class="copyright">
                            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                            Copyright &copy;
                            <script>
                                document.write(new Date().getFullYear());
                            </script> All rights reserved
                            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                        </span>
                    </div>
                </div>
                <!-- /row -->
            </div>
            <!-- /container -->
        </div>
        <!-- /bottom footer -->
    </footer>
    <!-- /FOOTER -->



    <!-- jQuery Plugins -->
    <!--<script src="{{ asset('front/js/jquery.min.js') }}"></script>-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
     <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <!--<script src="{{ asset('front/js/bootstrap.min.js') }}"></script>-->
    <script src="{{ asset('front/js/slick.min.j') }}s"></script>
    <script src="{{ asset('front/js/nouislider.min.js') }}"></script>
    <script src="{{ asset('front/js/jquery.zoom.min.js') }}"></script>
      @if(app()->getLocale() == 'ar')
      <script src="{{ asset('front/js/main_ar.js') }}"></script>
      @else
      <script src="{{ asset('front/js/main.js') }}"></script>
      @endif
     <script>
        $(document).ready(function(){
       /*Navigation: Hoverable dropdown*/

        $('.dropdown').hover(function() {
            $(this).addClass('open');
        },
        function() {
            $(this).removeClass('open');
        });
	
    });
    </script>
    <script>
        // $(window).scroll(function() {
        //     if ($(window).scrollTop() >= 300) {
        //         $('nav').addClass('fixed-header');
        //         $('nav div').addClass('visible-title');
        //     } else {
        //         $('nav').removeClass('fixed-header');
        //         $('nav div').removeClass('visible-title');
        //     }
        // });

        $(window).on('scroll', function() {
            var s = $(window).scrollTop(),
                d = $(document).height(),
                c = $(window).height();
            // var sec1 = document.getElementById("Gslider").clientHeight;
            console.log(s);
            console.log(d);
            console.log(c);
            var scrollPercent = (s / (d - c)) * 100;
            console.log(scrollPercent);
            if (scrollPercent < 5) {
                $('nav').removeClass('fixed-header');
                $('nav div').removeClass('visible-title');
            } else if (scrollPercent > 5 && scrollPercent < 40.1) {
                $('nav').addClass('fixed-header');
                $('nav div').addClass('visible-title');
            } else if (scrollPercent > 40.1) {
                $('nav').removeClass('fixed-header');
                $('nav div').removeClass('visible-title');
            }
        })
    </script>

</body>

</html>
