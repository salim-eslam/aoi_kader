<!-- FOOTER -->
<footer id="footer">
        <!-- top footer -->
        <div class="section">
            <!-- container -->
            <div class="container">
                <!-- row -->
                <div class="row">
                    <div class="col-md-6 col-xs-6">
                        <div class="footer">
                            <h3 class="footer-title">{{trans('layouts/footer.aboutus')}}</h3>
                            <p>{{trans('layouts/footer.aboutusdesc')}}</p>
                            <ul class="footer-links">
                                <li><a href="#"><i class="fa fa-map-marker"></i>{{trans('layouts/footer.address')}}</a></li>
                                <li><a href="#"><i class="fa fa-phone"></i>8004422221</a></li>
                                <li><a href="#"><i class="fa fa-envelope-o"></i>info@alsaifco-ksa.com</a></li>
                            </ul>
                        </div>
                    </div>

                    <div class="col-md-3 col-xs-6">
                        <div class="footer">
                            <h3 class="footer-title">{{trans('layouts/footer.LetUsHelpYou')}}</h3>
                            <ul class="footer-links">
                                <li><a href="#">{{trans('layouts/footer.AboutUS')}}</a></li>
                                <li><a href="#">{{trans('layouts/footer.ContactUs')}}</a></li>
                                <li><a href="#">{{trans('layouts/footer.ReturnPolicy')}}</a></li>
                                <li><a href="#">{{trans('layouts/footer.PrivacyPolicy')}}</a></li>
                                <li><a href="#">{{trans('layouts/footer.termsandconditions')}}</a></li>
                            </ul>
                        </div>
                    </div>

                    <div class="clearfix visible-xs"></div>

                    <div class="col-md-3 col-xs-6">
                        <div class="footer">
                            <h3 class="footer-title">{{trans('layouts/footer.ShopWithUs')}}</h3>
                            <ul class="footer-links">
                                <li><a href="#">{{trans('layouts/footer.myaccount')}}</a></li>
                                <li><a href="#">{{trans('layouts/footer.yourcart')}}</a></li>
                                <li><a href="#">{{trans('layouts/footer.wishlist')}}</a></li>
                                <li><a href="#">{{trans('layouts/footer.trackorder')}}</a></li>
                                <li><a href="#">{{trans('layouts/footer.help')}}</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <!-- /row -->
            </div>
            <!-- /container -->
        </div>
        <!-- /top footer -->

        <!-- bottom footer -->
        <div id="bottom-footer" class="section">
            <div class="container">
                <!-- row -->
                <div class="row">
                    <div class="col-md-12 text-center">
                        <ul class="footer-payments">
                            <li><a href="#"><i class="fa fa-cc-visa"></i></a></li>
                            <li><a href="#"><i class="fa fa-credit-card"></i></a></li>
                            <li><a href="#"><i class="fa fa-cc-paypal"></i></a></li>
                            <li><a href="#"><i class="fa fa-cc-mastercard"></i></a></li>
                            <li><a href="#"><i class="fa fa-cc-discover"></i></a></li>
                            <li><a href="#"><i class="fa fa-cc-amex"></i></a></li>
                        </ul>
                        <span class="copyright">
                            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                            Copyright &copy;
                            <script>
                                document.write(new Date().getFullYear());
                            </script> All rights reserved
                            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                        </span>
                    </div>
                </div>
                <!-- /row -->
            </div>
            <!-- /container -->
        </div>
        <!-- /bottom footer -->
    </footer>
    <!-- /FOOTER -->
    <!-- jQuery Plugins -->
    <!--<script src="{{ asset('front/js/jquery.min.js') }}"></script>-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
     <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <!--<script src="{{ asset('front/js/bootstrap.min.js') }}"></script>-->
    <script src="{{ asset('front/js/slick.min.j') }}s"></script>
    <script src="{{ asset('front/js/nouislider.min.js') }}"></script>
    <script src="{{ asset('front/js/jquery.zoom.min.js') }}"></script>
    <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
    <script src="https://www.jqueryscript.net/demo/Highly-Customizable-Range-Slider-Plugin-For-Bootstrap-Bootstrap-Slider/dist/bootstrap-slider.js"></script>
    @if(app()->getLocale() == 'ar')
    <script>
        $('.menu-toggle > a').on('click', function (e) {
		e.preventDefault();
		$('#sidebar').toggleClass('active');
	});
    </script>
    @endif
   <script>
// Get the elements with class="column"
var elements = document.getElementsByClassName("column");
console.log(elements.length);
console.log(elements);
// Declare a loop variable
var i;

// List View
function listView() {
  for (i = 0; i < elements.length; i++) {
    elements[i].style.width = "100%";
    // $('.product .product-body .product-btns>button')[i].style.padding = "90px 48px 0 28px";
    $('.product-price')[i].style.marginBottom="none";
     $('.add-to-compare')[i].style.padding="125px 49px 0px 25px";
  }
}

// Grid View
function gridView() {

  for (i = 0,len=elements.length;i<len;i++) {
    elements[i].style.width = "50%";
    //   $('.product')[i].style.height = "50%";
     $('.product-price')[i].style.marginBottom="-20px";
     $('.add-to-compare')[i].style.padding="110px 30px 0px 4px";
  }
}

/* Optional: Add active class to the current button (highlight it) */
var container = document.getElementById("btnContainer");
var btns = container.getElementsByClassName("btn");
for (var i = 0; i < btns.length; i++) {
  btns[i].addEventListener("click", function() {
    var current = document.getElementsByClassName("active");
    current[0].className = current[0].className.replace(" active", "");
    this.className += " active";
  });
}
</script>
    <script>
       $('#category_select').change(function ()
        {
            var id=$('#category_select :selected').val();
            window.location = "/products/"+id;
        });
    </script>
    <script>
        function hideCategoryFilters()
        {
            
             document.getElementById("sidebar").style.display = "none";
        }
         function showCategoryFilters()
        {
            
             document.getElementById("sidebar").style.display = "block";
        }
    </script>
<script>
    function open()
    {
        var x = document.getElementById("accordionContenttt");
  if (x.style.display === "none") {
    x.style.display = "block";
  } else {
    x.style.display = "none";
  }
    }
    const accordionItemHeaders = document.querySelectorAll(".accordion-item-header");

accordionItemHeaders.forEach(accordionItemHeader => {
   accordionItemHeader.addEventListener("click", event => {
    
   
     accordionItemHeader.classList.toggle("active");
     const accordionItemBody = accordionItemHeader.nextElementSibling;
     if(accordionItemHeader.classList.contains("active")) {
      accordionItemBody.style.maxHeight = accordionItemBody.scrollHeight + "px";
     }
     else {
       accordionItemBody.style.maxHeight = 0;
     }
    
   });
});
   </script>
      @if(app()->getLocale() == 'ar')
      <script src="{{ asset('front/js/main_ar.js') }}"></script>
      @else
      <script src="{{ asset('front/js/main.js') }}"></script>
      @endif
      @stack('scripts')
     <script>
        $(document).ready(function(){
       /*Navigation: Hoverable dropdown*/

        $('.dropdown').hover(function() {
            $(this).addClass('open');
        },
        function() {
            $(this).removeClass('open');
        });
	
    });
    </script>
    <script>
        $(window).on('scroll', function() {
            var s = $(window).scrollTop(),
                d = $(document).height(),
                c = $(window).height();
            // var sec1 = document.getElementById("Gslider").clientHeight;
            console.log(s);
            console.log(d);
            console.log(c);
            var scrollPercent = (s / (d - c)) * 100;
            console.log(scrollPercent);
            if (scrollPercent < 5) {
                $('nav').removeClass('fixed-header');
                $('nav div').removeClass('visible-title');
            } else if (scrollPercent > 5 && scrollPercent < 40.1) {
                $('nav').addClass('fixed-header');
                $('nav div').addClass('visible-title');
            } else if (scrollPercent > 40.1) {
                $('nav').removeClass('fixed-header');
                $('nav div').removeClass('visible-title');
            }
        })
    </script>
     <script>
        new Swiper('.slides-3', {
  speed: 600,
  loop: false,
  autoplay:false,
//   autoplay: {
//     delay: 5000,
//     disableOnInteraction: false
//   },
  slidesPerView: 'auto',
  pagination: {
    el: '.swiper-pagination',
    type: 'bullets',
    clickable: true
  },
  navigation: {
    nextEl: '.swiper-button-next',
    prevEl: '.swiper-button-prev',
  },
  breakpoints: {
    320: {
      slidesPerView: 1,
      spaceBetween: 40
    },

    1200: {
      slidesPerView: 3,
    }
  }
});
    </script>
    