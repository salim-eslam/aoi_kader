 <!-- NAVIGATION -->
 <nav id="navigation"
        style="box-shadow: 0 3px 1px -2px rgba(0,0,0,.2), 0 2px 2px 0 rgba(0,0,0,.14), 0 1px 5px 0 rgba(0,0,0,.12);">
        <!-- container -->
        <div class="container">
            <!-- responsive-nav -->
            <div id="responsive-nav">
                <!-- NAV -->
                @php
                            $categories = DB::table('categories')
                                ->where('status', 'active')
                                ->orderBy('created_at')
                                ->get();
                        @endphp 
                        @if(app()->getLocale() == 'ar')
                        <ul class="main-nav nav navbar-nav">
                            @foreach($categories as $category)
                            <?php 
                                $childCategories = \App\Models\Category::getChildByParentIDAr($category->id);                   
                            ?>                  
                            @if(count($childCategories) > 0 && $category->parent_id == null)                    
                                <li class="dropdown dd-main"><a href="#" class="dropdown-toggle" data-toggle="dropdown">{{$category->title_ar}}</a>
                            <ul class="dropdown-menu dropdown-menu-custom">
                                @foreach($childCategories as $key => $childCat)
                                <?php                        
                                $child_child_categories = \App\Models\Category::getChildByParentIDAr($key);
                                ?>
                                @if(count($child_child_categories) > 0)
                                <li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown">{{$childCat}}</a>
                                <ul class="dropdown-menu dropdown-menu-custom-sub">
                                @foreach($child_child_categories as $key => $child_child_cat)
                                <li><a href="{{route('product-grids',$key)}}">{{$child_child_cat}}</a></li>
                                @endforeach		
                            </ul>
                            </li>	
                                @else
                                
                                <li><a href="{{route('product-grids',$key)}}">{{$childCat}}</a></li>
                                @endif
                                @endforeach
                            </ul>
                            </li>
                            @endif
                            @endforeach                   
                        </ul>
                        @else                        
                        <ul class="main-nav nav navbar-nav">
                            @foreach($categories as $category)
                            <?php 
                                $childCategories = \App\Models\Category::getChildByParentID($category->id);                   
                            ?>                  
                            @if(count($childCategories) > 0 && $category->parent_id == null)                    
                                <li class="dropdown dd-main"><a href="#" class="dropdown-toggle" data-toggle="dropdown">{{$category->title}}</a>
                            <ul class="dropdown-menu dropdown-menu-custom">
                                @foreach($childCategories as $key => $childCat)
                                <?php                        
                                $child_child_categories = \App\Models\Category::getChildByParentID($key);
                                ?>
                                @if(count($child_child_categories) > 0)
                                <li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown">{{$childCat}}</a>
                                <ul class="dropdown-menu dropdown-menu-custom-sub">
                                @foreach($child_child_categories as $key => $child_child_cat)
                                <li><a href="{{route('product-grids',$key)}}">{{$child_child_cat}}</a></li>
                                @endforeach		
                            </ul>
                            </li>	
                                @else
                                
                                <li><a href="{{route('product-grids',$key)}}">{{$childCat}}</a></li>
                                @endif
                                @endforeach
                            </ul>
                            </li>
                            @endif
                            @endforeach                   
                        </ul>
                        @endif
                <!-- /NAV -->
            </div>
            <!-- /responsive-nav -->
        </div>
        <!-- /container -->
    </nav>
    <!-- /NAVIGATION -->