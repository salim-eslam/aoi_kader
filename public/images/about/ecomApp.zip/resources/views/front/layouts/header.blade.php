 <!-- HEADER -->
 <header class="header-pos">
        <!-- TOP HEADER -->
        <div id="top-header">
            <div class="container">
                @if(app()->getLocale() == 'ar')
                <ul class="header-links pull-right">
                @else
                <ul class="header-links pull-left">
                @endif
                    <li class="top-header-li"><a href="#"><i class="fa fa-phone"></i>8004422221</a></li>
                    <li class="top-header-li"><a href="#"><i class="fa fa-envelope-o"></i> info@alsaifco-ksa.com</a></li>
                    <li>
                     <a style="margin: 5px;" href="{{ LaravelLocalization::getLocalizedURL('en', null, [], true) }}">E &nbsp; <img style="max-width: 18%;" src="{{asset('/front/images/usa.png')}}" alt=""></a>
                     <a style="margin: 10px;"  href="{{ LaravelLocalization::getLocalizedURL('ar', null, [], true) }}"><img style=" max-width: 18%;" src="{{asset('/front/images/ksa.png')}}" alt=""> &nbsp; ع</a>
                    </li>
                    <!--<li><a  rel="alternate" hreflang="ar"  href="{{ LaravelLocalization::getLocalizedURL('ar', null, [], true) }}" class="dropdown-item">{{ trans('layouts/header.ar') }}</a><img src="/front/images/flag_sa.png" style="width:2.5rem;margin-left:5px;" alt=""/></li>-->
                   
                </ul>
                 @if(app()->getLocale() == 'ar')
                 <ul class="header-links pull-left">
                 @else
                <ul class="header-links pull-right">
                @endif    
                    <li>
                         @if(app()->getLocale() == 'ar')
                        <svg style="color: white;margin-right: 20%;" xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                            fill="currentColor" class="bi bi-geo-alt" viewBox="0 0 16 16">
                            @else
                            <svg style="color: white;margin-left: 40%;" xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                            fill="currentColor" class="bi bi-geo-alt" viewBox="0 0 16 16">
                            @endif
                            <path
                                d="M12.166 8.94c-.524 1.062-1.234 2.12-1.96 3.07A31.493 31.493 0 0 1 8 14.58a31.481 31.481 0 0 1-2.206-2.57c-.726-.95-1.436-2.008-1.96-3.07C3.304 7.867 3 6.862 3 6a5 5 0 0 1 10 0c0 .862-.305 1.867-.834 2.94M8 16s6-5.686 6-10A6 6 0 0 0 2 6c0 4.314 6 10 6 10" />
                            <path d="M8 8a2 2 0 1 1 0-4 2 2 0 0 1 0 4m0 1a3 3 0 1 0 0-6 3 3 0 0 0 0 6" />
                        </svg> <a href="{{ route('order.track') }}">{{trans('layouts/header.OrderTracking')}}</a>
                    </li>
                    <li>
                        @if(app()->getLocale() == 'ar')
                        <svg style="color: white;margin-right: 22%;" xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                            fill="currentColor" class="bi bi-power" viewBox="0 0 16 16">
                            @else
                             <svg style="color: white;margin-left: 20%;" xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                            fill="currentColor" class="bi bi-power" viewBox="0 0 16 16">
                            @endif
                            <path d="M7.5 1v7h1V1z" />
                            <path
                                d="M3 8.812a4.999 4.999 0 0 1 2.578-4.375l-.485-.874A6 6 0 1 0 11 3.616l-.501.865A5 5 0 1 1 3 8.812" />
                        </svg><a href="#">{{trans('layouts/header.login')}} /</a><a href="#">{{trans('layouts/header.register')}}</a></li>

                </ul>
            </div>
        </div>
        <!-- /TOP HEADER -->

        <!-- MAIN HEADER -->
         @if(app()->getLocale() == 'ar')
         <div id="header">
            <!-- container -->
            <div class="container">
                <!-- row -->
                <div class="row">
                @php
                            $categories = DB::table('categories')
                                ->where('status', 'active')
                                ->orderBy('created_at')
                                ->get();
                        @endphp
                        <!-- ACCOUNT -->
                    <div class="col-md-3 clearfix">
                        <div class="header-ctn">
                             <div class="menu-toggle">
                                <a href="#">
                                    <!--<i class='fas fa-filter'></i>-->
                                     <!--<i style="font-size:24px" class="fa header-filter">&#xf0b0;</i>-->
                                     <img src="/front/images/icon-filter-20.png" class="header-filter" alt="" style="padding-left: 35px;"/>  
                                     <span style="padding-left: 65px;">تصفية</span>
                                    <!--<img src="/front/images/icon-filter-2.png" class="header-filter" alt=""/>-->
                                                 </a>
                            </div>
                            <!-- Wishlist -->
                            <div>
                                <a href="#">
                                    <i class="fa fa-heart-o"></i>
                                    <span>{{trans('layouts/header.wishlist')}}</span>
                                    <div class="qty">2</div>
                                </a>
                            </div>
                            <!-- /Wishlist -->

                            <!-- Cart -->
                            <div class="dropdown">
                                <a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true">
                                    <i class="fa fa-shopping-cart"></i>
                                    <span>{{trans('layouts/header.YourCart')}}</span>
                                    <div class="qty">3</div>
                                </a>
                                <div class="cart-dropdown">
                                    <div class="cart-list">
                                        <div class="product-widget">
                                            <div class="product-img">
                                                <img src="{{ asset('front//img/product01.png') }}" alt="">
                                            </div>
                                            <div class="product-body">
                                                <h3 class="product-name"><a href="#">product name goes here</a>
                                                </h3>
                                                <h4 class="product-price"><span class="qty">1x</span>$980.00</h4>
                                            </div>
                                            <button class="delete"><i class="fa fa-close"></i></button>
                                        </div>

                                        <div class="product-widget">
                                            <div class="product-img">
                                                <img src="{{ asset('front//img/product02.png') }}" alt="">
                                            </div>
                                            <div class="product-body">
                                                <h3 class="product-name"><a href="#">product name goes here</a>
                                                </h3>
                                                <h4 class="product-price"><span class="qty">3x</span>$980.00</h4>
                                            </div>
                                            <button class="delete"><i class="fa fa-close"></i></button>
                                        </div>
                                    </div>
                                    <div class="cart-summary">
                                        <small>3 Item(s) selected</small>
                                        <h5>SUBTOTAL: $2940.00</h5>
                                    </div>
                                    <div class="cart-btns">
                                        <a href="#">View Cart</a>
                                        <a href="#">Checkout <i class="fa fa-arrow-circle-right"></i></a>
                                    </div>
                                </div>
                            </div>
                            <!-- /Cart -->
                           

                            <!-- Menu Toogle -->
                            <div class="menu-toggle1" style="display:none;">
                                <a href="#">
                                    <i class="fa fa-bars"></i>
                                    <span>{{trans('layouts/header.menu')}}</span>
                                </a>
                            </div>
                            <!-- /Menu Toogle -->
                        </div>
                    </div>
                    <!-- /ACCOUNT -->

                    <!-- SEARCH BAR -->
                    <div class="col-md-6">
                        <div class="header-search">
                        @php
                            $categories = DB::table('categories')
                                ->where('status', 'active')
                                ->orderBy('created_at')
                                ->get();
                        @endphp
                            <form>
                                <select id="category_select" class="input-select">
                                    <option value="0">{{trans('layouts/header.allcategories')}}</option>
                                    @foreach($categories as $category)
                                    <?php 
                                $childCategories = \App\Models\Category::getChildByParentIDAr($category->id);                   
                            ?> 
                              @if(app()->getLocale() == 'ar')
                                @if(count($childCategories) > 0)   
                               <optgroup label="{{$category->title_ar}}">
                                @foreach($childCategories as $key => $childCat)   
                                <option value="{{$key}}">{{$childCat}}</option>
                                @endforeach
                                </optgroup>
                                @endif
                                    @else
                                    <option value="{{$category->id}}">{{$category->title}}</option>
                                    @endif
                                    @endforeach
                                </select>
                                <input class="input" placeholder="{{trans('layouts/header.searchhere')}}">
                                <button class="search-btn"><img src="/front/images/icon-search.png" width="24px" alt=""/></button>
                            </form>
                        </div>
                    </div>
                    <!-- /SEARCH BAR -->
                    <!-- LOGO -->
                    <div class="col-md-3">
                        <div class="header-logo">
                            <a href="https://alsaifco-ksa.com/en"><img
                                    src="https://alsaifco-ksa.com/Dashboard/assets/Front/assets/img/alsaif.png"
                                    alt="logo" style="padding: 0; margin: 0;height: 140px; "></a>
                        </div>
                    </div>
                    <!-- /LOGO -->
                
                </div>
                <!-- row -->
            </div>
            <!-- container -->
        </div>
         @else
        <div id="header">
            <!-- container -->
            <div class="container">
                <!-- row -->
                <div class="row">
                    <!-- LOGO -->
                    <div class="col-md-3">
                        <div class="header-logo">
                            <a href="https://alsaifco-ksa.com/en"><img
                                    src="https://alsaifco-ksa.com/Dashboard/assets/Front/assets/img/alsaif.png"
                                    alt="logo" style="padding: 0; margin: 0;height: 140px; "></a>
                        </div>
                    </div>
                    <!-- /LOGO -->

                    <!-- SEARCH BAR -->
                    <div class="col-md-6">
                        <div class="header-search">
                        @php
                            $categories = DB::table('categories')
                                ->where('status', 'active')
                                ->orderBy('created_at')
                                ->get();
                        @endphp
                            <form>
                                <select id="category_select" class="input-select">
                                    <option value="0">{{trans('layouts/header.allcategories')}}</option>
                                    @foreach($categories as $category)
                                     <?php 
                                $childCategories = \App\Models\Category::getChildByParentID($category->id);                   
                            ?> 
                                    @if(app()->getLocale() == 'ar')
                                    <option value="{{$category->id}}">{{$category->title_ar}}</option>
                                    @else
                                        @if(count($childCategories) > 0)   
                                       <optgroup label="{{$category->title}}">
                                        @foreach($childCategories as $key => $childCat)   
                                        <option value="{{$key}}">{{$childCat}}</option>
                                        @endforeach
                                        </optgroup>
                                        @endif
                                    @endif
                                    @endforeach
                                </select>
                                <input class="input" placeholder="{{trans('layouts/header.searchhere')}}">
                                <button class="search-btn"><img src="/front/images/icon-search.png" width="24px" alt=""/></button>
                            </form>
                        </div>
                    </div>
                    <!-- /SEARCH BAR -->

                    <!-- ACCOUNT -->
                    <div class="col-md-3 clearfix">
                        <div class="header-ctn">
                            <!-- Wishlist -->
                            <div>
                                <a href="#">
                                    <i class="fa fa-heart-o"></i>
                                    <span>{{trans('layouts/header.wishlist')}}</span>
                                    <div class="qty">2</div>
                                </a>
                            </div>
                            <!-- /Wishlist -->

                            <!-- Cart -->
                            <div class="dropdown">
                                <a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true">
                                    <i class="fa fa-shopping-cart"></i>
                                    <span>{{trans('layouts/header.YourCart')}}</span>
                                    <div class="qty">3</div>
                                </a>
                                <div class="cart-dropdown">
                                    <div class="cart-list">
                                        <div class="product-widget">
                                            <div class="product-img">
                                                <img src="{{ asset('front//img/product01.png') }}" alt="">
                                            </div>
                                            <div class="product-body">
                                                <h3 class="product-name"><a href="#">product name goes here</a>
                                                </h3>
                                                <h4 class="product-price"><span class="qty">1x</span>$980.00</h4>
                                            </div>
                                            <button class="delete"><i class="fa fa-close"></i></button>
                                        </div>

                                        <div class="product-widget">
                                            <div class="product-img">
                                                <img src="{{ asset('front//img/product02.png') }}" alt="">
                                            </div>
                                            <div class="product-body">
                                                <h3 class="product-name"><a href="#">product name goes here</a>
                                                </h3>
                                                <h4 class="product-price"><span class="qty">3x</span>$980.00</h4>
                                            </div>
                                            <button class="delete"><i class="fa fa-close"></i></button>
                                        </div>
                                    </div>
                                    <div class="cart-summary">
                                        <small>3 Item(s) selected</small>
                                        <h5>SUBTOTAL: $2940.00</h5>
                                    </div>
                                    <div class="cart-btns">
                                        <a href="#">View Cart</a>
                                        <a href="#">Checkout <i class="fa fa-arrow-circle-right"></i></a>
                                    </div>
                                </div>
                            </div>
                            <!-- /Cart -->
                                <div class="menu-toggle">
                                   
                                <a href="#" type="button" onclick="showCategoryFilters()"> 
                                <!--<i style="font-size:24px" class="fa header-filter">&#xf0b0;</i>-->
                              
                                    <img src="/front/images/icon-filter-20.png" class="header-filter" alt="" style="padding-left: 35px;"/>  
                                     <span>Filtering</span>
                                </a>
                                </div>

                            <!-- Menu Toogle -->
                            <div class="menu-toggle1" style="display:none;">
                                <a href="#">
                                    <i class="fas fa-bars"></i>
                                    <span>{{trans('layouts/header.menu')}}</span>
                                </a>
                            </div>
                            <!-- /Menu Toogle -->
                        </div>
                    </div>
                    <!-- /ACCOUNT -->
                </div>
                <!-- row -->
            </div>
            <!-- container -->
        </div>
        @endif
        <!-- /MAIN HEADER -->
    </header>
    <!-- /HEADER -->