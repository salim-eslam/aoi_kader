<!DOCTYPE html>
@if(app()->getLocale() == 'ar')
<html dir="rtl" lang="ar">
@else
<html lang="en">
@endif
@include('front.layouts.head')
<body>
@include('front.layouts.header')    
@include('front.layouts.navigation')    
    <!--/ End Header -->
    @yield('main-content')
    @include('front.layouts.footer')
</body>
</html>
