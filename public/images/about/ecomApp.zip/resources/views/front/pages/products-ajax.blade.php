	
              
          
							<!--<div id="store" class="col-md-9">-->
						<!-- store top filter -->
						<div class="store-filter clearfix">
                        <div  class="slides-3 swiper-container swiper-container-initialized swiper-container-horizontal swiper-container-pointer-events"><div class="swiper-wrapper" style="transition-duration: 0ms; transform: translate3d(0px, 0px, 0px);">
                                             
                         @php $brands = \App\Models\Brand::all(); @endphp
                          @foreach($brands as $brand)
                        <div class="swiper-slide" style="margin-right: 20px;"><button type="button"  class="text-primary-700 px-4 flex items-center justify-center text-center has-active-state SubCategory__item brand_btn" value="{{$brand->slug}}" onclick="getProducts(this.value)" style="width:100%;"><span  class="text-sm font-bold m swiper-text">
                        {{$brand->title}}
                        </span></button></div>
                        @endforeach
        </div> <div class="flex mt-5"><button aria-label="next slide" class="swiper-button-next hologram-link text-white hover: mr-8"><img src="/front/images/prev.png" al=""/></button> <button data-v-3f2087ee="" aria-label="previous slide" class="swiper-button-prev hologram-link text-white mr-7"><img src="/front/images/next.png" alt=""/></button></div></div>
							
						</div>
						<!-- /store top filter -->

						<!-- store products -->
						<div class="row">                        
                        <!-- product -->
    @if(count($products)>0)
                            @foreach($products as $product)
                                      @php
                                         $category = \App\Models\Category::where('id',$product->cat_id)->first();
                                      @endphp
							<div class="col-sm-3 col-xs-6">					
                               
                                <div class="product">
                                    <div class="product-img">
                                         <div class="product-btns">
                                            <button class="add-to-wishlist"><i class="fa fa-heart-o"></i><span
                                                    class="tooltipp">add to wishlist</span></button> 
                                                    </div>
                                        <img  src="/{{$product->photo}}" alt="">
                                        <div class="product-label">
                                            <span class="new">{{trans('home/body.new')}}</span>
                                        </div>
                                    </div>
                                    <div class="product-body">
                                        <p class="product-category">{{$category->title}}</p>
                                        <h3 class="product-name"><a href="#">{{$product->title}}</a></h3>
                                        @php
                                                    $after_discount=($product->price-($product->price*$product->discount)/100);
                                                @endphp
                                        <h4 class="product-price">{{number_format($after_discount,2)}} <del
                                                class="product-old-price">{{$product->price}}</del></h4>
            <!--                            <div class="product-rating">-->
												<!--</div>-->
                                         <div class="product-btns">
                                            <!--<button class="add-to-wishlist"><i class="fa fa-heart-o"></i><span-->
                                            <!--        class="tooltipp">add to wishlist</span></button>-->
                                            <button class="add-to-compare"><i class="fa fa-exchange"></i><span
                                                    class="tooltipp">add to compare</span></button> 
                                            <button type="button"
                                                style="background-color: #642221; width:auto;  text-transform: uppercase; font-weight: 700;border-radius: 40px;text-transform: uppercase;font-size:13px;padding:0px 25px 5px 25px;"
                                                class="btn btn-danger"> {{trans('home/body.addtocart')}}</button>

                                            <a data-toggle="modal" data-target="#{{$product->id}}" title="Quick View" href="#" class="quick-view"><i class="fa fa-eye"></i><span
                                                    class="tooltipp">quick view</span></a>                                                    
                                        </div>
                                    </div>
                                    <!--<div class="add-to-cart">-->
                                    <!--    <button class="add-to-cart-btn"><i class="fa fa-shopping-cart"></i> add to-->
                                    <!--        cart</button>-->
                                    <!--</div>-->
                                </div>                              
							</div>
							<!-- /product -->
                            @endforeach		
                            @else
                            <h4 class="text-warning" style="margin:100px auto;">There are no products.</h4>
                            @endif				
						</div>
						<!-- /store products -->
                       

						
						
			
           