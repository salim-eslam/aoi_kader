@extends('front.layouts.master')

@section('title','Alsaif || Home')

@section('main-content')
<div class="section CategoryPage__inner ">
     <!-- container -->
     <div class="container-fluid">    
                <!-- row -->
  <div class="row">
  <!-- <b id="min_value">Rs. 0</b> <input id="ex2" type="text" class="span2" value="" data-slider-min="0" data-slider-max="5000" data-slider-step="5" data-slider-value="[0,5000]"/> <b id="max_value">Rs. 5000 </b> -->
  @if(app()->getLocale() == 'ar')
  <div id="store" class="col-md-9">
  <div id="ajax_result">

						<!-- store top filter -->
						<div class="store-filter clearfix">
                        <div  class="slides-3 swiper-container swiper-container-initialized swiper-container-horizontal swiper-container-pointer-events"><div class="swiper-wrapper" style="transition-duration: 0ms; transform: translate3d(0px, 0px, 0px);">
                                             
                                        
                        @php $brands = \App\Models\Brand::all(); @endphp
                        @foreach($brands as $brand)
                        <div class="swiper-slide" style="margin-right: 20px;"><button type="button"  class="text-primary-700 px-4 flex items-center justify-center text-center has-active-state SubCategory__item brand_btn" value="{{$brand->slug}}" onclick="getProducts(this.value)" style="width:100%;"><span  class="text-sm font-bold m swiper-text">
                        @if(app()->getLocale() == 'ar')
                        {{$brand->title_ar}}
                        @else
                        {{$brand->title}}
                        @endif
                        </span></button></div>
                        @endforeach
        </div> <div class="flex mt-5"><button aria-label="next slide" class="swiper-button-next hologram-link text-white hover: mr-8"><img src="/front/images/next.png" alt=""/></button> <button data-v-3f2087ee="" aria-label="previous slide" class="swiper-button-prev hologram-link text-white mr-7"><img src="/front/images/prev.png" al=""/></button></div></div>
							<div id="btnContainer" style="float:left;">
  <button class="btn" onclick="listView()"><i class="fa fa-bars"></i></button> 
  <button class="btn active" onclick="gridView()"><i class="fa fa-th-large"></i></button>
</div>
						</div>
						<!-- /store top filter -->

						<!-- store products -->
						<div class="row">                        
                        <!-- product -->
    @if(count($products)>0)
                            @foreach($products as $product)
                                      @php
                                         $category = \App\Models\Category::where('id',$product->cat_id)->first();
                                      @endphp
							<div class="col-sm-3 col-xs-6 column">					
                               
                                <div class="product">
                                    <div class="product-img">
                                         <div class="product-btns">
                                            <button class="add-to-wishlist"><i class="fa fa-heart-o"></i><span
                                                    class="tooltipp">add to wishlist</span></button> 
                                                    </div>
                                        <img  src="/{{$product->photo}}" alt="">
                                        <div class="product-label">
                                            <span class="new">{{trans('home/body.new')}}</span>
                                        </div>
                                    </div>
                                    <div class="product-body">
                                         <p class="product-category">{{$category->title_ar}}</p>
                                        <h3 class="product-name"><a href="#">{{$product->title_ar}}</a></h3>
                                        @php
                                                    $after_discount=($product->price-($product->price*$product->discount)/100);
                                                @endphp
                                        <h4 class="product-price"> {{number_format($after_discount,2)}}
                                            ريال سعودي
                                        @if($product->discount == 0)
                                        @else
                                        <del class="product-old-price">{{$product->price}}</del>
                                        @endif
                                                </h4>
            <!--                            <div class="product-rating">-->
												<!--</div>-->
                                         <div class="product-btns">
                                            <!--<button class="add-to-wishlist"><i class="fa fa-heart-o"></i><span-->
                                            <!--        class="tooltipp">add to wishlist</span></button>-->
                                            <button class="add-to-compare"><i class="fa fa-exchange"></i><span
                                                    class="tooltipp">add to compare</span></button> 
                                            <button type="button"
                                                style="background-color: #642221; width:auto;  text-transform: uppercase; font-weight: 700;border-radius: 40px;text-transform: uppercase;font-size:13px;padding:0px 25px 5px 25px;"
                                                class="btn btn-danger"> {{trans('home/body.addtocart')}}</button>

                                            <a data-toggle="modal" data-target="#{{$product->id}}" title="Quick View" href="#" class="quick-view"><i class="fa fa-eye"></i><span
                                                    class="tooltipp">quick view</span></a>                                                    
                                        </div>
                                    </div>
                                    <!--<div class="add-to-cart">-->
                                    <!--    <button class="add-to-cart-btn"><i class="fa fa-shopping-cart"></i> add to-->
                                    <!--        cart</button>-->
                                    <!--</div>-->
                                </div>                              
							</div>
							<!-- /product -->
                            @endforeach		
                            @else
                            <h4 class="text-warning" style="margin:100px auto;">There are no products.</h4>
                            @endif				
						</div>
						<!-- /store products -->
                        <!-- store bottom filter -->

		
</div>
<div class="store-filter clearfix">
							<!-- <span class="store-qty">Showing 20-100 products</span> -->
							<ul class="store-pagination">
                            {{$products->appends($_GET)->links()}}							
							</ul>
						</div>
						<!-- /store bottom filter -->
					</div>
					<!-- /STORE -->
<div id="store" class="col-md-3">
              
                    <div class="CategoryPage__filters sidebar" id="sidebar">
                    <h2 class="text-primary-700 text-3xl font-display font-bold antialiased mb-5 relative" style="margin-right: 21%;">
                    @if(app()->getLocale() == 'ar')
                    تسوق حسب
                    @else
                        Filter by
                    @endif
                    </h2>
                     <div class="accordion">
  <div class="accordion-item">
    <div class="accordion-item-header">
      السعر
     </div> 
    <!-- /.accordion-item-header -->
 <div class="accordion-item-body">
      <div class="accordion-item-body-content">
     <!-- <span id="slider_value2" style="color:red;font-weight:bold;"></span><br>
      Rs. 0 <input type="range" min="0" max="5000" step="1" name="sld6" value="" onchange="show_value2(this.value)" tooltip="this.value"> Rs. 5000 -->
      <!-- <span class="current-value">0</span> -->
         <div class="d-flex">
    <div class="wrapper">
        <div class="slider">
        <div class="progress"></div>
      </div>
      <div class="range-input">
        <input type="range" class="range-min" min="0" max="5000" value="0" step="100">
        <input type="range" class="range-max" min="0" max="5000" value="5000" step="100">
      </div>
      <div class="price-input">
        <div class="field">
          <span>من</span>
          <input type="number" id="from" class="input-min" value="0">
           <span>ريال</span>
        </div>
        <div class="separator"></div>
        <div class="field" style="text-align:right;">
          <span>الي</span>
          <input type="number" class="input-max" value="5000">
          <span>ريال</span>
        </div>
      </div>
      
    </div>

    
  </div>
       </div> 
     </div> 
    <!-- /.accordion-item-body -->
   </div> 
  <!-- /.accordion-item -->
 </div> 
@php                     $os_ids = \App\Models\Product::whereNotNull('os_id')
                        ->where('child_cat_id',$cat_id)->get();
                        $os_ids_count = $os_ids->count();
                         @endphp
@if($os_ids_count > 0)                        
<div class="accordion"> 
  <div class="accordion-item">
    <div class="accordion-item-header">
    @if(app()->getLocale() == 'ar')
    نظام التشغيل
    @else
      Operating System
     @endif 
    </div><!-- /.accordion-item-header -->
    <div class="accordion-item-body">
      <div class="accordion-item-body-content">                              
              @php $osList = \App\Models\OperatingSystems::all(); @endphp
              @foreach($osList as $os)   
              @if(app()->getLocale() == 'ar')
              <div class="form-group"> <input class="os_check" type="checkbox" value="{{$os->slug}}" id="{{$os->slug}}"> <label for="25">{{ $os->title_ar }}</label> </div>      
              @else     
             <div class="form-group"> <input class="os_check" type="checkbox" value="{{$os->slug}}" id="{{$os->slug}}"> <label for="25">{{ $os->title }}</label> </div>          
            @endif
            @endforeach
      </div>
    </div><!-- /.accordion-item-body -->
  </div><!-- /.accordion-item -->
</div>
@endif
@php                     $hard_type_ids = \App\Models\Product::whereNotNull('hard_type_id')->where('child_cat_id',$cat_id)->get();
                         $hard_types_count = $hard_type_ids->count();
                         @endphp
@if($hard_types_count > 0)                         
<div class="accordion"> 
  <div class="accordion-item">
    <div class="accordion-item-header">
    @if(app()->getLocale() == 'ar')
    مواصفات القرص الصلب 
    @else
     Hard Drive Type
     @endif
    </div><!-- /.accordion-item-header -->
    <div class="accordion-item-body">
      <div class="accordion-item-body-content">       
           @php $hardTypes = \App\Models\HardType::all(); @endphp
           @foreach($hardTypes as $hardType)     
           @if(app()->getLocale() == 'ar')
           <div class="form-group"> <input class="hard_type_check" type="checkbox" value="{{$hardType->slug}}" id="{{$hardType->slug}}"> <label for="25">{{ $hardType->title_ar }}</label> </div>
           @else                  
            <div class="form-group"> <input class="hard_type_check" type="checkbox" value="{{$hardType->slug}}" id="{{$hardType->slug}}"> <label for="25">{{ $hardType->title }}</label> </div>
            @endif
          @endforeach
      </div>
    </div><!-- /.accordion-item-body -->
  </div><!-- /.accordion-item -->
</div>
@endif
@php  
                           $hard_capacity_ids = \App\Models\Product::whereNotNull('hard_capacity_id')->where('child_cat_id',$cat_id)->get();
                         @endphp
@if($hard_capacity_ids->count() > 0)                       
<div class="accordion"> 
  <div class="accordion-item">
    <div class="accordion-item-header">
    @if(app()->getLocale() == 'ar')
    سعة التخزين
    @endif
    </div><!-- /.accordion-item-header -->
    <div class="accordion-item-body">
      <div class="accordion-item-body-content">                               
            @php $hardCapcities = \App\Models\HardCapacity::all(); @endphp
            @foreach($hardCapcities as $hardCapcity)
             @if(app()->getLocale() == 'ar')
            <div class="form-group"> <input class="hard_capcity_check" type="checkbox" value="{{$hardCapcity->slug}}" id="{{$hardCapcity->slug}}"> <label for="25">{{ $hardCapcity->title_ar }}</label> </div>          
            @else
            <div class="form-group"> <input class="hard_capcity_check" type="checkbox" value="{{$hardCapcity->slug}}" id="{{$hardCapcity->slug}}"> <label for="25">{{ $hardCapcity->title }}</label> </div>
            @endif
            @endforeach
      </div>
    </div><!-- /.accordion-item-body -->
  </div><!-- /.accordion-item -->
</div>
@endif    
@php  
                           $installed_ram_ids = \App\Models\Product::whereNotNull('installed_ram_id')->where('child_cat_id',$cat_id)->get();
                         @endphp
@if($installed_ram_ids->count() > 0)                       
<div class="accordion"> 
  <div class="accordion-item">
    <div class="accordion-item-header">
    @if(app()->getLocale() == 'ar')
   سعة التخزين
    @else  
    RAM Capcity
    @endif
    </div><!-- /.accordion-item-header -->
    <div class="accordion-item-body">
      <div class="accordion-item-body-content">                               
            @php $ramCapcities = \App\Models\InstalledRAM::all(); @endphp
            @foreach($ramCapcities as $ramCapcity)
             @if(app()->getLocale() == 'ar')
            <div class="form-group"> <input class="ram_capcity_check" type="checkbox" value="{{$ramCapcity->slug}}" id="{{$ramCapcity->slug}}"> <label for="25">{{ $ramCapcity->title_ar }}</label> </div>          
            @else
            <div class="form-group"> <input class="ram_capcity_check" type="checkbox" value="{{$ramCapcity->slug}}" id="{{$ramCapcity->slug}}"> <label for="25">{{ $ramCapcity->title }}</label> </div>
            @endif
            @endforeach
      </div>
    </div><!-- /.accordion-item-body -->
  </div><!-- /.accordion-item -->
</div>
@endif    
@php                     $cpu_type_ids = \App\Models\Product::whereNotNull('cpu_type_id')
                              ->where('child_cat_id',$cat_id)->get();
                         @endphp
@if($cpu_type_ids->count() > 0)                        
<div class="accordion"> 
  <div class="accordion-item">
    <div class="accordion-item-header">
    @if(app()->getLocale() == 'ar')
    فئة المعالج
    @else
    Processor Core
    @endif
    </div><!-- /.accordion-item-header -->
    <div class="accordion-item-body">
      <div class="accordion-item-body-content">             
            @php $cpuTypes = \App\Models\CpuType::all(); @endphp
            @foreach($cpuTypes as $cpuType)
            @if(app()->getLocale() == 'ar')
            <div class="form-group"> <input class="cpu_type_check" type="checkbox" value="{{$cpuType->slug}}" id="{{$cpuType->slug}}"> <label for="25">{{ $cpuType->title_ar }}</label> </div>
            @else
            <div class="form-group"> <input class="cpu_type_check" type="checkbox" value="{{$cpuType->slug}}" id="{{$cpuType->slug}}"> <label for="25">{{ $cpuType->title }}</label> </div>            
            @endif
            @endforeach
      </div>
    </div><!-- /.accordion-item-body -->
  </div><!-- /.accordion-item -->
</div>
@endif                   
@php                     $graphics_corprocessor_ids = \App\Models\Product::where(function($q){
                         return $q->whereNotNull('graphics_corprocessor_id')
                               ->orWhereNotNull('cat_id');
                        })->where('cat_id',$cat_id)->get();
                         @endphp
@if($graphics_corprocessor_ids->count() > 0)                         
<div class="accordion"> 
  <div class="accordion-item">
    <div class="accordion-item-header">
    @if(app()->getLocale() == 'ar')
    معالج الرسومات 
    @else
    Graphics Coprocessor
    @endif
    </div><!-- /.accordion-item-header -->
    <div class="accordion-item-body">
      <div class="accordion-item-body-content">                         
            @php $graphicCoprocessors = \App\Models\GraphicsCoprocessor::all(); @endphp
            @foreach($graphicCoprocessors as $graphicCoprocessor)
            @if(app()->getLocale() == 'ar')
            <div class="form-group"> <input class="graphic_coprocessor_check" type="checkbox" value="{{$graphicCoprocessor->slug}}" id="{{$graphicCoprocessor->slug}}"> <label for="25">{{ $graphicCoprocessor->title_ar }}</label> </div>
            @else
            <div class="form-group"> <input class="graphic_coprocessor_check" type="checkbox" value="{{$graphicCoprocessor->slug}}" id="{{$graphicCoprocessor->slug}}"> <label for="25">{{ $graphicCoprocessor->title }}</label> </div>
            @endif
            @endforeach
      </div>
    </div><!-- /.accordion-item-body -->
  </div><!-- /.accordion-item -->
</div>
@endif      
@php                     $display_types_ids = \App\Models\Product::whereNotNull('display_type_id')
                        ->where('child_cat_id',$cat_id)->get();
                         @endphp
@if($display_types_ids->count() > 0)                        
<div class="accordion"> 
  <div class="accordion-item">
    <div class="accordion-item-header">
    @if(app()->getLocale() == 'ar')
    نوع العرض
    @else
     Display Type
     @endif
    </div><!-- /.accordion-item-header -->
    <div class="accordion-item-body">
      <div class="accordion-item-body-content">       
            @php $displayTypes = \App\Models\DisplayType::all(); @endphp
            @foreach($displayTypes as $key => $displayType)
            @if(app()->getLocale() == 'ar')
            <div class="form-group"> <input class="display_type_check" type="checkbox" value="{{$displayType->slug}}" id="{{$displayType->slug}}"> <label for="25">{{ $displayType->title_ar}}</label> </div>
            @else
            <div class="form-group"> <input class="display_type_check" type="checkbox" value="{{$displayType->slug}}" id="{{$displayType->slug}}"> <label for="25">{{ $displayType->title }}</label> </div>
            @endif
            @endforeach
      </div>
    </div><!-- /.accordion-item-body -->
  </div><!-- /.accordion-item -->
</div>
@endif   
@php                     $conn_tech_ids = \App\Models\Product::whereNotNull('conn_tech_id')
                        ->where('child_cat_id',$cat_id)->get();
                         @endphp
@if($conn_tech_ids->count() > 0 )                    
<div class="accordion"> 
  <div class="accordion-item">
    <div class="accordion-item-header">
    @if(app()->getLocale() == 'ar')
    تقنية الاتصال
    @else
    Connectivity Technology
    @endif
    </div><!-- /.accordion-item-header -->
    <div class="accordion-item-body">
      <div class="accordion-item-body-content">       
            @php $connTechs= \App\Models\ConnectivityTechnology::all(); @endphp
            @foreach($connTechs as $connTech)
            @if(app()->getLocale() == 'ar')
            <div class="form-group"> <input class="conn_tech_check" type="checkbox" value="{{$connTech->slug}}" id="{{$connTech->slug}}"> <label for="25">{{ $connTech->title_ar }}</label> </div>
            @else
            <div class="form-group"> <input class="conn_tech_check" type="checkbox" value="{{$connTech->slug}}" id="{{$connTech->slug}}"> <label for="25">{{ $connTech->title }}</label> </div>
            @endif
            @endforeach
      </div>
    </div><!-- /.accordion-item-body -->
  </div><!-- /.accordion-item -->
</div>
@endif     
@php                     $natv_res_ids = \App\Models\Product::whereNotNull('native_resolution_id')
                               ->where('cat_id',$cat_id)->get();
                         @endphp
@if($natv_res_ids->count() > 0)                      
<div class="accordion"> 
  <div class="accordion-item">
    <div class="accordion-item-header">
    @if(app()->getLocale() == 'ar')
    الدقة الأصلية
    @else
    Native Resolution
    @endif
    </div><!-- /.accordion-item-header -->
    <div class="accordion-item-body">
      <div class="accordion-item-body-content">       
            @php $natvResloutions= \App\Models\NativeResolution::all(); @endphp
            @foreach($natvResloutions as $natvRes)
            @if(app()->getLocale() == 'ar')
            <div class="form-group"> <input class="natv_res_check" type="checkbox" value="{{$natvRes->slug}}" id="{{$natvRes->slug}}"> <label for="25">{{ $natvRes->title_ar }}</label> </div>
            @else
            <div class="form-group"> <input class="natv_res_check" type="checkbox" value="{{$natvRes->slug}}" id="{{$natvRes->slug}}"> <label for="25">{{ $natvRes->title }}</label> </div>
            @endif
            @endforeach
      </div>
    </div><!-- /.accordion-item-body -->
  </div><!-- /.accordion-item -->
</div>
@endif     
@php                     $inc_comp_ids = \App\Models\Product::whereNotNull('inc_comp_id')
                       ->where('child_cat_id',$cat_id)->get();
                         @endphp
@if($inc_comp_ids->count() > 0)                          
<div class="accordion"> 
  <div class="accordion-item">
    <div class="accordion-item-header">
    @if(app()->getLocale() == 'ar')
    المكونات الاضافية
    @else  
    Include Components
    @endif
    </div><!-- /.accordion-item-header -->
    <div class="accordion-item-body">
      <div class="accordion-item-body-content">       
            @php $incCompnents= \App\Models\IncludeComponents::all(); @endphp
            @foreach($incCompnents as $incComp)
            @if(app()->getLocale() == 'ar')
            <div class="form-group"> <input class="inc_comp_check" type="checkbox" value="{{$incComp->slug}}" id="{{$incComp->slug}}"> <label for="25">{{ $incComp->title_ar }}</label> </div>
            @else
            <div class="form-group"> <input class="inc_comp_check" type="checkbox" value="{{$incComp->slug}}" id="{{$incComp->slug}}"> <label for="25">{{ $incComp->title }}</label> </div>
            @endif
            @endforeach
      </div>
    </div><!-- /.accordion-item-body -->
  </div><!-- /.accordion-item -->
</div>
@endif  
@php                     $display_res_ids = \App\Models\Product::whereNotNull('display_res_id')
                              ->where('cat_id',$cat_id)->get();
                         @endphp
@if($display_res_ids->count() > 0)                          
<div class="accordion"> 
  <div class="accordion-item">
    <div class="accordion-item-header">
    @if(app()->getLocale() == 'ar')
    دقة الشاشة
    @else
    Monitor Display Resolution
    @endif
    </div><!-- /.accordion-item-header -->
    <div class="accordion-item-body">
      <div class="accordion-item-body-content">       
            @php $displayResolutions= \App\Models\DisplayResolution::all(); @endphp
            @foreach($displayResolutions as $displayResolution)
            @if(app()->getLocale() == 'ar')
            <div class="form-group"> <input class="display_res_check" type="checkbox" value="{{$displayResolution->slug}}" id="{{$displayResolution->slug}}"> <label for="25">{{ $displayResolution->title_ar }}</label> </div>
            @else
            <div class="form-group"> <input class="display_res_check" type="checkbox" value="{{$displayResolution->slug}}" id="{{$displayResolution->slug}}"> <label for="25">{{ $displayResolution->title }}</label> </div>
            @endif
            @endforeach
      </div>
    </div><!-- /.accordion-item-body -->
  </div><!-- /.accordion-item -->
</div>
@endif    
@php                     $screen_size_ids = \App\Models\Product::where(function($q){
                         return $q->whereNotNull('screen_size_id')
                               ->orWhereNotNull('cat_id');
                        })->where('cat_id',$cat_id)->get();
                         @endphp
@if($screen_size_ids->count() > 0)                          
<div class="accordion"> 
  <div class="accordion-item">
    <div class="accordion-item-header">
    @if(app()->getLocale() == 'ar')
    حجم الشاشة
    @else
    Screen Size
    @endif
    </div><!-- /.accordion-item-header -->
    <div class="accordion-item-body">
      <div class="accordion-item-body-content">       
            @php $screenSizes= \App\Models\ScreenSize::all(); @endphp
            @foreach($screenSizes as $screenSize)
            @if(app()->getLocale() == 'ar')
            <div class="form-group"> <input class="screen_size_check" type="checkbox" value="{{$screenSize->slug}}" id="{{$screenSize->slug}}"> <label for="25">{{ $screenSize->title_ar }}</label> </div>
            @else
            <div class="form-group"> <input class="screen_size_check" type="checkbox" value="{{$screenSize->slug}}" id="{{$screenSize->slug}}"> <label for="25">{{ $screenSize->title }}</label> </div>
            @endif
            @endforeach
      </div>
    </div><!-- /.accordion-item-body -->
  </div><!-- /.accordion-item -->
</div>
@endif
@php                     $monitor_feature_ids = \App\Models\Product::where(function($q){
                         return $q->whereNotNull('monitor_feature_id')
                               ->orWhereNotNull('cat_id');
                        })->where('cat_id',$cat_id)->get();
                         @endphp
@if($monitor_feature_ids->count() > 0)                          
<div class="accordion"> 
  <div class="accordion-item">
    <div class="accordion-item-header">
    @if(app()->getLocale() == 'ar')
    خصائص الشاشة
    @else 
    Monitors Features
    @endif
    </div><!-- /.accordion-item-header -->
    <div class="accordion-item-body">
      <div class="accordion-item-body-content">       
            @php $monitorFeatures= \App\Models\MonitorFeatures::all(); @endphp
            @foreach($monitorFeatures as $monitorFeature)
            @if(app()->getLocale() == 'ar')
            <div class="form-group"> <input class="screen_size_check" type="checkbox" value="{{$monitorFeature->slug}}" id="{{$monitorFeature->slug}}"> <label for="25">{{ $monitorFeature->title_ar }}</label> </div>
            @else
            <div class="form-group"> <input class="screen_size_check" type="checkbox" value="{{$monitorFeature->slug}}" id="{{$monitorFeature->slug}}"> <label for="25">{{ $monitorFeature->title }}</label> </div>
            @endif
            @endforeach
      </div>
    </div><!-- /.accordion-item-body -->
  </div><!-- /.accordion-item -->
</div>
@endif  
@php                     $product_length_ids = \App\Models\Product::whereNotNull('product_length_id')->where('cat_id',$cat_id)->WhereNotNull('cat_id')->orwhere('child_cat_id',$cat_id)->whereNotNull('child_cat_id')->get();
                         @endphp
@if($product_length_ids->count() > 0)                          
<div class="accordion"> 
  <div class="accordion-item">
    <div class="accordion-item-header">
    طول المنتج
    </div><!-- /.accordion-item-header -->
    <div class="accordion-item-body">
      <div class="accordion-item-body-content">       
            @php $productLengths= \App\Models\ProductLength::all(); @endphp
            @foreach($productLengths as $productLength)
            @if(app()->getLocale() == 'ar')
            <div class="form-group"> <input class="product_length_check" type="checkbox" value="{{$productLength->slug}}" id="{{$productLength->slug}}"> <label for="25">{{ $productLength->title_ar }}</label> </div>
            @else
            <div class="form-group"> <input class="product_length_check" type="checkbox" value="{{$productLength->slug}}" id="{{$productLength->slug}}"> <label for="25">{{ $productLength->title }}</label> </div>
            @endif
            @endforeach
      </div>
    </div><!-- /.accordion-item-body -->
  </div><!-- /.accordion-item -->
</div>
@endif         
@php                     $brands_ids = \App\Models\Product::whereNotNull('brand_id')->where('cat_id',$cat_id)->WhereNotNull('cat_id')->orwhere('child_cat_id',$cat_id)->whereNotNull('child_cat_id')->get();
                         @endphp
@if($brands_ids->count() > 0)                                                                                               
<div class="accordion">
  <div class="accordion-item">
    <div class="accordion-item-header">
    @if(app()->getLocale() == 'ar')
    البراند
    @else
      Brand
    @endif
    </div><!-- /.accordion-item-header -->
    <div class="accordion-item-body">
      <div class="accordion-item-body-content">        
            @php $brands = \App\Models\Brand::all(); @endphp
            @foreach($brands as $brand)
            @if(app()->getLocale() == 'ar')
            <div class="form-group"> <input class="brand_check" type="checkbox" value="{{$brand->slug}}" id="{{$brand->slug}}"> <label for="25">{{ $brand->title_ar }}</label> </div>
            @else
            <div class="form-group"> <input class="brand_check" type="checkbox" value="{{$brand->slug}}" id="{{$brand->slug}}"> <label for="25">{{ $brand->title }}</label> </div>
            @endif
            @endforeach
      </div>
    </div><!-- /.accordion-item-body -->
  </div><!-- /.accordion-item -->
</div>
@endif
<div class="accordion">
  <div class="accordion-item">
    <div class="accordion-item-header text-primary-700">
    @if(app()->getLocale() == 'ar')
    الفئة
    @else
      Category
    @endif
    </div><!-- /.accordion-item-header -->
    <div class="accordion-item-body">
      <div class="accordion-item-body-content">
      @php
                        $category = \App\Models\Category::where('id',$cat_id)->first();
                        @endphp
                        @if(app()->getLocale() == 'ar')
                        <div class="form-group"> <input class="category_check" type="checkbox" value="{{$category->id}}" id="{{$category->id}}"> <label for="25">{{ $category->title_ar }}</label> </div>
                        @else    
                        <div class="form-group"> <input class="category_check" type="checkbox" value="{{$category->id}}" id="{{$category->id}}"> <label for="25">{{ $category->title }}</label> </div>
                        @endif               
      </div>
    </div><!-- /.accordion-item-body -->
  </div><!-- /.accordion-item -->
</div>                
                   
                
                    </div>
                 </div>
  @else
  
                 <div id="store" class="col-md-3">
              
                    <div class="CategoryPage__filters sidebar" id="sidebar">
                    <h2 class="text-primary-700 text-3xl font-display font-bold antialiased mb-5 relative" style="margin-left: 16%;">
                    @if(app()->getLocale() == 'ar')
                    تسوق حسب
                    @else
                        Filter by
                    @endif
                    </h2>
                     <div class="accordion">
  <div class="accordion-item">
    <div class="accordion-item-header">
      Price
     </div> 
    <!-- /.accordion-item-header -->
  <div class="accordion-item-body">
      <div class="accordion-item-body-content">
      <!--<span id="slider_value2" style="color:red;font-weight:bold;"></span><br>-->
      <!--Rs. 0 <input type="range" min="0" max="5000" step="1" name="sld6" value="" onchange="show_value2(this.value)" tooltip="this.value"> Rs. 5000 -->
     <div class="d-flex">
    <div class="wrapper">
        <div class="slider">
        <div class="progress"></div>
      </div>
      <div class="range-input">
        <input type="range" class="range-min" min="0" max="5000" value="0" step="100">
        <input type="range" class="range-max" min="0" max="5000" value="5000" step="100">
      </div>
      <div class="price-input">
        <div class="field">
          <span>From</span>
          <input type="number" id="from" class="input-min" value="0" onchange="productPrice(this.value)">
           <span>Rs</span>
        </div>
        <div class="separator"></div>
        <div class="field" style="text-align:right;">
          <span>To</span>
          <input type="number" class="input-max" value="5000">
          <span>Rs</span>
        </div>
      </div>
      
    </div>

    
  </div>
      <!-- <span class="current-value">0</span> -->
       </div> 
     </div> 
    <!-- /.accordion-item-body -->
   </div> 
  <!-- /.accordion-item -->
 </div> 
@php                     $os_ids = \App\Models\Product::whereNotNull('os_id')
                             ->where('child_cat_id',$cat_id)->get();
                         $os_ids_count = $os_ids->count();               
                         @endphp
@if($os_ids_count > 0)                        
<div class="accordion"> 
  <div class="accordion-item">
    <div class="accordion-item-header">
    @if(app()->getLocale() == 'ar')
    نظام التشغيل
    @else
      Operating System
     @endif 
    </div><!-- /.accordion-item-header -->
    <div class="accordion-item-body">
      <div class="accordion-item-body-content">                              
              @php $osList = \App\Models\OperatingSystems::all(); @endphp
              @foreach($osList as $os)   
              @if(app()->getLocale() == 'ar')
              <div class="form-group"> <input class="os_check" type="checkbox" value="{{$os->slug}}" id="{{$os->slug}}"> <label for="25">{{ $os->title_ar }}</label> </div>      
              @else     
             <div class="form-group"> <input class="os_check" type="checkbox" value="{{$os->slug}}" id="{{$os->slug}}"> <label for="25">{{ $os->title }}</label> </div>          
            @endif
            @endforeach
      </div>
    </div><!-- /.accordion-item-body -->
  </div><!-- /.accordion-item -->
</div>
@endif
@php
               $hard_type_ids = \App\Models\Product::whereNotNull('hard_type_id')
                              ->where('child_cat_id',$cat_id)->get();
                         $hard_types_count = $hard_type_ids->count();
                         @endphp
@if($hard_types_count > 0)                         
<div class="accordion"> 
  <div class="accordion-item">
    <div class="accordion-item-header">
    @if(app()->getLocale() == 'ar')
    مواصفات القرص الصلب 
    @else
     Hard Drive Type
     @endif
    </div><!-- /.accordion-item-header -->
    <div class="accordion-item-body">
      <div class="accordion-item-body-content">       
           @php $hardTypes = \App\Models\HardType::all(); @endphp
           @foreach($hardTypes as $hardType)     
           @if(app()->getLocale() == 'ar')
           <div class="form-group"> <input class="hard_type_check" type="checkbox" value="{{$hardType->slug}}" id="{{$hardType->slug}}"> <label for="25">{{ $hardType->title_ar }}</label> </div>
           @else                  
            <div class="form-group"> <input class="hard_type_check" type="checkbox" value="{{$hardType->slug}}" id="{{$hardType->slug}}"> <label for="25">{{ $hardType->title }}</label> </div>
            @endif
          @endforeach
      </div>
    </div><!-- /.accordion-item-body -->
  </div><!-- /.accordion-item -->
</div>
@endif
@php                     $installed_ram_ids = \App\Models\Product::whereNotNull('installed_ram_id')
                             ->where('child_cat_id',$cat_id)->get();
                         @endphp
@if($installed_ram_ids->count() > 0)                       
<div class="accordion"> 
  <div class="accordion-item">
    <div class="accordion-item-header">
    @if(app()->getLocale() == 'ar')
    سعة الرام
    @else  
    RAM Capcity
    @endif
    </div><!-- /.accordion-item-header -->
    <div class="accordion-item-body">
      <div class="accordion-item-body-content">                               
            @php $ramCapcities = \App\Models\InstalledRAM::all(); @endphp
            @foreach($ramCapcities as $ramCapcity)
             @if(app()->getLocale() == 'ar')
            <div class="form-group"> <input class="ram_capcity_check" type="checkbox" value="{{$ramCapcity->slug}}" id="{{$ramCapcity->slug}}"> <label for="25">{{ $ramCapcity->title_ar }}</label> </div>          
            @else
            <div class="form-group"> <input class="ram_capcity_check" type="checkbox" value="{{$ramCapcity->slug}}" id="{{$ramCapcity->slug}}"> <label for="25">{{ $ramCapcity->title }}</label> </div>
            @endif
            @endforeach
      </div>
    </div><!-- /.accordion-item-body -->
  </div><!-- /.accordion-item -->
</div>
@endif     
@php  
                           $hard_capacity_ids = \App\Models\Product::where('hard_capacity_id','!=',0)->orWhereNotNull('hard_capacity_id')->where('child_cat_id',$cat_id)->get();
                         @endphp
@if($hard_capacity_ids->count() > 0)                       
<div class="accordion"> 
  <div class="accordion-item">
    <div class="accordion-item-header">
    Hard Disk Capcity
    </div><!-- /.accordion-item-header -->
    <div class="accordion-item-body">
      <div class="accordion-item-body-content">                               
            @php $hardCapcities = \App\Models\HardCapacity::all(); @endphp
            @foreach($hardCapcities as $hardCapcity)
             @if(app()->getLocale() == 'ar')
            <div class="form-group"> <input class="hard_capcity_check" type="checkbox" value="{{$hardCapcity->slug}}" id="{{$hardCapcity->slug}}"> <label for="25">{{ $hardCapcity->title_ar }}</label> </div>          
            @else
            <div class="form-group"> <input class="hard_capcity_check" type="checkbox" value="{{$hardCapcity->slug}}" id="{{$hardCapcity->slug}}"> <label for="25">{{ $hardCapcity->title }}</label> </div>
            @endif
            @endforeach
      </div>
    </div><!-- /.accordion-item-body -->
  </div><!-- /.accordion-item -->
</div>
@endif    
@php                     $cpu_type_ids = \App\Models\Product::whereNotNull('cpu_type_id')
                               ->where('child_cat_id',$cat_id)->get();
                         @endphp
@if($cpu_type_ids->count() > 0)                        
<div class="accordion"> 
  <div class="accordion-item">
    <div class="accordion-item-header">
    @if(app()->getLocale() == 'ar')
    فئة المعالج
    @else
    Processor Core
    @endif
    </div><!-- /.accordion-item-header -->
    <div class="accordion-item-body">
      <div class="accordion-item-body-content">             
            @php $cpuTypes = \App\Models\CpuType::all(); @endphp
            @foreach($cpuTypes as $cpuType)
            @if(app()->getLocale() == 'ar')
            <div class="form-group"> <input class="cpu_type_check" type="checkbox" value="{{$cpuType->slug}}" id="{{$cpuType->slug}}"> <label for="25">{{ $cpuType->title_ar }}</label> </div>
            @else
            <div class="form-group"> <input class="cpu_type_check" type="checkbox" value="{{$cpuType->slug}}" id="{{$cpuType->slug}}"> <label for="25">{{ $cpuType->title }}</label> </div>            
            @endif
            @endforeach
      </div>
    </div><!-- /.accordion-item-body -->
  </div><!-- /.accordion-item -->
</div>
@endif                   
@php  $graphics_corprocessor_ids = \App\Models\Product::whereNotNull('graphics_corprocessor_id')
                         ->where('cat_id',$cat_id)
                         ->get(); 
                         @endphp
@if($graphics_corprocessor_ids->count() > 0)                         
<div class="accordion"> 
  <div class="accordion-item">
    <div class="accordion-item-header">
    @if(app()->getLocale() == 'ar')
    معالج الرسومات 
    @else
    Graphics Coprocessor
    @endif
    </div><!-- /.accordion-item-header -->
    <div class="accordion-item-body">
      <div class="accordion-item-body-content">                         
            @php $graphicCoprocessors = \App\Models\GraphicsCoprocessor::all(); @endphp
            @foreach($graphicCoprocessors as $graphicCoprocessor)
            @if(app()->getLocale() == 'ar')
            <div class="form-group"> <input class="graphic_coprocessor_check" type="checkbox" value="{{$graphicCoprocessor->slug}}" id="{{$graphicCoprocessor->slug}}"> <label for="25">{{ $graphicCoprocessor->title_ar }}</label> </div>
            @else
            <div class="form-group"> <input class="graphic_coprocessor_check" type="checkbox" value="{{$graphicCoprocessor->slug}}" id="{{$graphicCoprocessor->slug}}"> <label for="25">{{ $graphicCoprocessor->title }}</label> </div>
            @endif
            @endforeach
      </div>
    </div><!-- /.accordion-item-body -->
  </div><!-- /.accordion-item -->
</div>
@endif      
@php  $display_types_ids = \App\Models\Product::whereNotNull('display_type_id')
                         ->where('child_cat_id',$cat_id)
                         ->get(); 
                         @endphp
@if($display_types_ids->count() > 0)                        
<div class="accordion"> 
  <div class="accordion-item">
    <div class="accordion-item-header">
    @if(app()->getLocale() == 'ar')
    نوع العرض
    @else
     Display Type
     @endif
    </div><!-- /.accordion-item-header -->
    <div class="accordion-item-body">
      <div class="accordion-item-body-content">       
            @php $displayTypes = \App\Models\DisplayType::all(); @endphp
            @foreach($displayTypes as $key => $displayType)
            @if(app()->getLocale() == 'ar')
            <div class="form-group"> <input class="display_type_check" type="checkbox" value="{{$displayType->slug}}" id="{{$displayType->slug}}"> <label for="25">{{ $displayType->title_ar}}</label> </div>
            @else
            <div class="form-group"> <input class="display_type_check" type="checkbox" value="{{$displayType->slug}}" id="{{$displayType->slug}}"> <label for="25">{{ $displayType->title }}</label> </div>
            @endif
            @endforeach
      </div>
    </div><!-- /.accordion-item-body -->
  </div><!-- /.accordion-item -->
</div>
@endif   
@php  $conn_tech_ids = \App\Models\Product::whereNotNull('conn_tech_id')
                         ->where('child_cat_id',$cat_id)
                         ->get();                          
                         @endphp
@if($conn_tech_ids->count() > 0 )                    
<div class="accordion"> 
  <div class="accordion-item">
    <div class="accordion-item-header">
    @if(app()->getLocale() == 'ar')
    تقنية الاتصال
    @else
    Connectivity Technology
    @endif
    </div><!-- /.accordion-item-header -->
    <div class="accordion-item-body">
      <div class="accordion-item-body-content">       
            @php $connTechs= \App\Models\ConnectivityTechnology::all(); @endphp
            @foreach($connTechs as $connTech)
            @if(app()->getLocale() == 'ar')
            <div class="form-group"> <input class="conn_tech_check" type="checkbox" value="{{$connTech->slug}}" id="{{$connTech->slug}}"> <label for="25">{{ $connTech->title_ar }}</label> </div>
            @else
            <div class="form-group"> <input class="conn_tech_check" type="checkbox" value="{{$connTech->slug}}" id="{{$connTech->slug}}"> <label for="25">{{ $connTech->title }}</label> </div>
            @endif
            @endforeach
      </div>
    </div><!-- /.accordion-item-body -->
  </div><!-- /.accordion-item -->
</div>
@endif     
@php  $natv_res_ids = \App\Models\Product::whereNotNull('native_resolution_id')
                        ->where('cat_id',$cat_id)
                        ->get(); 
                         @endphp
@if($natv_res_ids->count() > 0)                      
<div class="accordion"> 
  <div class="accordion-item">
    <div class="accordion-item-header">
    @if(app()->getLocale() == 'ar')
    الدقة الأصلية
    @else
    Native Resolution
    @endif
    </div><!-- /.accordion-item-header -->
    <div class="accordion-item-body">
      <div class="accordion-item-body-content">       
            @php $natvResloutions= \App\Models\NativeResolution::all(); @endphp
            @foreach($natvResloutions as $natvRes)
            @if(app()->getLocale() == 'ar')
            <div class="form-group"> <input class="natv_res_check" type="checkbox" value="{{$natvRes->slug}}" id="{{$natvRes->slug}}"> <label for="25">{{ $natvRes->title_ar }}</label> </div>
            @else
            <div class="form-group"> <input class="natv_res_check" type="checkbox" value="{{$natvRes->slug}}" id="{{$natvRes->slug}}"> <label for="25">{{ $natvRes->title }}</label> </div>
            @endif
            @endforeach
      </div>
    </div><!-- /.accordion-item-body -->
  </div><!-- /.accordion-item -->
</div>
@endif     
@php  $inc_comp_ids = \App\Models\Product::whereNotNull('inc_comp_id')
                         ->where('child_cat_id',$cat_id)
                         ->get(); 
                         @endphp
@if($inc_comp_ids->count() > 0)                          
<div class="accordion"> 
  <div class="accordion-item">
    <div class="accordion-item-header">
    @if(app()->getLocale() == 'ar')
    المكونات الاضافية
    @else  
    Include Components
    @endif
    </div><!-- /.accordion-item-header -->
    <div class="accordion-item-body">
      <div class="accordion-item-body-content">       
            @php $incCompnents= \App\Models\IncludeComponents::all(); @endphp
            @foreach($incCompnents as $incComp)
            @if(app()->getLocale() == 'ar')
            <div class="form-group"> <input class="inc_comp_check" type="checkbox" value="{{$incComp->slug}}" id="{{$incComp->slug}}"> <label for="25">{{ $incComp->title_ar }}</label> </div>
            @else
            <div class="form-group"> <input class="inc_comp_check" type="checkbox" value="{{$incComp->slug}}" id="{{$incComp->slug}}"> <label for="25">{{ $incComp->title }}</label> </div>
            @endif
            @endforeach
      </div>
    </div><!-- /.accordion-item-body -->
  </div><!-- /.accordion-item -->
</div>
@endif  
@php  $display_res_ids = \App\Models\Product::whereNotNull('display_res_id')
                         ->where('cat_id',$cat_id)
                         ->get(); 
                         @endphp
@if($display_res_ids->count() > 0)                          
<div class="accordion"> 
  <div class="accordion-item">
    <div class="accordion-item-header">
    @if(app()->getLocale() == 'ar')
    دقة الشاشة
    @else
    Monitor Display Resolution
    @endif
    </div><!-- /.accordion-item-header -->
    <div class="accordion-item-body">
      <div class="accordion-item-body-content">       
            @php $displayResolutions= \App\Models\DisplayResolution::all(); @endphp
            @foreach($displayResolutions as $displayResolution)
            @if(app()->getLocale() == 'ar')
            <div class="form-group"> <input class="display_res_check" type="checkbox" value="{{$displayResolution->slug}}" id="{{$displayResolution->slug}}"> <label for="25">{{ $displayResolution->title_ar }}</label> </div>
            @else
            <div class="form-group"> <input class="display_res_check" type="checkbox" value="{{$displayResolution->slug}}" id="{{$displayResolution->slug}}"> <label for="25">{{ $displayResolution->title }}</label> </div>
            @endif
            @endforeach
      </div>
    </div><!-- /.accordion-item-body -->
  </div><!-- /.accordion-item -->
</div>
@endif    
@php  $screen_size_ids = \App\Models\Product::whereNotNull('screen_size_id')
                         ->where('cat_id',$cat_id)
                         ->get(); 
                         @endphp
@if($screen_size_ids->count() > 0)                          
<div class="accordion"> 
  <div class="accordion-item">
    <div class="accordion-item-header">
    @if(app()->getLocale() == 'ar')
    حجم الشاشة
    @else
    Screen Size
    @endif
    </div><!-- /.accordion-item-header -->
    <div class="accordion-item-body">
      <div class="accordion-item-body-content">       
            @php $screenSizes= \App\Models\ScreenSize::all(); @endphp
            @foreach($screenSizes as $screenSize)
            @if(app()->getLocale() == 'ar')
            <div class="form-group"> <input class="screen_size_check" type="checkbox" value="{{$screenSize->slug}}" id="{{$screenSize->slug}}"> <label for="25">{{ $screenSize->title_ar }}</label> </div>
            @else
            <div class="form-group"> <input class="screen_size_check" type="checkbox" value="{{$screenSize->slug}}" id="{{$screenSize->slug}}"> <label for="25">{{ $screenSize->title }}</label> </div>
            @endif
            @endforeach
      </div>
    </div><!-- /.accordion-item-body -->
  </div><!-- /.accordion-item -->
</div>
@endif
@php  $monitor_feature_ids = \App\Models\Product::whereNotNull('monitor_feature_id')
                         ->where('cat_id',$cat_id)
                         ->get(); 
                         @endphp
@if($monitor_feature_ids->count() > 0)                          
<div class="accordion"> 
  <div class="accordion-item">
    <div class="accordion-item-header">
    @if(app()->getLocale() == 'ar')
    خصائص الشاشة
    @else 
    Monitors Features
    @endif
    </div><!-- /.accordion-item-header -->
    <div class="accordion-item-body">
      <div class="accordion-item-body-content">       
            @php $monitorFeatures= \App\Models\MonitorFeatures::all(); @endphp
            @foreach($monitorFeatures as $monitorFeature)
            @if(app()->getLocale() == 'ar')
            <div class="form-group"> <input class="monitor_feature_check" type="checkbox" value="{{$monitorFeature->slug}}" id="{{$monitorFeature->slug}}"> <label for="25">{{ $monitorFeature->title_ar }}</label> </div>
            @else
            <div class="form-group"> <input class="monitor_feature_check" type="checkbox" value="{{$monitorFeature->slug}}" id="{{$monitorFeature->slug}}"> <label for="25">{{ $monitorFeature->title }}</label> </div>
            @endif
            @endforeach
      </div>
    </div><!-- /.accordion-item-body -->
  </div><!-- /.accordion-item -->
</div>
@endif     
@php  $product_length_ids = \App\Models\Product::whereNotNull('product_length_id')
                         ->where('cat_id',$cat_id)
                         ->get(); 
                         @endphp
@if($product_length_ids->count() > 0)                          
<div class="accordion"> 
  <div class="accordion-item">
    <div class="accordion-item-header">
    @if(app()->getLocale() == 'ar')
    طول المنتج
    @else
    Product Length
    @endif
    </div><!-- /.accordion-item-header -->
    <div class="accordion-item-body">
      <div class="accordion-item-body-content">       
            @php $productLengths= \App\Models\ProductLength::all(); @endphp
            @foreach($productLengths as $productLength)
            @if(app()->getLocale() == 'ar')
            <div class="form-group"> <input class="product_length_check" type="checkbox" value="{{$productLength->slug}}" id="{{$productLength->slug}}"> <label for="25">{{ $productLength->title_ar }}</label> </div>
            @else
            <div class="form-group"> <input class="product_length_check" type="checkbox" value="{{$productLength->slug}}" id="{{$productLength->slug}}"> <label for="25">{{ $productLength->title }}</label> </div>
            @endif
            @endforeach
      </div>
    </div><!-- /.accordion-item-body -->
  </div><!-- /.accordion-item -->
</div>
@endif         
@php                     $brands_ids = \App\Models\Product::where(function($q){
                         return $q->whereNotNull('brand_id')
                               ->orWhereNotNull('cat_id')
                               ->orWhereNotNull('child_cat_id')
                               ->orWhereNotNull('child_child_cat_id');
                        })->distinct()->where('cat_id',$cat_id)->orWhere('child_cat_id',$cat_id)->orWhere('child_child_cat_id',$cat_id)->get();
                         @endphp
@if($brands_ids->count() > 0)                                                                                               
<div class="accordion">
  <div class="accordion-item">
    <div class="accordion-item-header">
    @if(app()->getLocale() == 'ar')
    البراند
    @else
      Brand
    @endif
    </div><!-- /.accordion-item-header -->
    <div class="accordion-item-body">
      <div class="accordion-item-body-content">        
            @php $brands = \App\Models\Brand::all(); @endphp
            @foreach($brands as $brand)
            @if(app()->getLocale() == 'ar')
            <div class="form-group"> <input class="brand_check" type="checkbox" value="{{$brand->slug}}" id="{{$brand->slug}}"> <label for="25">{{ $brand->title_ar }}</label> </div>
            @else
            <div class="form-group"> <input class="brand_check" type="checkbox" value="{{$brand->slug}}" id="{{$brand->slug}}"> <label for="25">{{ $brand->title }}</label> </div>
            @endif
            @endforeach
      </div>
    </div><!-- /.accordion-item-body -->
  </div><!-- /.accordion-item -->
</div>
@endif
<div class="accordion">
  <div class="accordion-item">
    <div class="accordion-item-header">
    @if(app()->getLocale() == 'ar')
    الفئة
    @else
      Category
    @endif
    </div><!-- /.accordion-item-header -->
    <div class="accordion-item-body">
      <div class="accordion-item-body-content">
      @php
                        $category = \App\Models\Category::where('id',$cat_id)->first();
                        @endphp
                        @if(app()->getLocale() == 'ar')
                        <div class="form-group"> <input class="category_check" type="checkbox" value="{{$category->id}}" id="{{$category->id}}"> <label for="25">{{ $category->title_ar }}</label> </div>
                        @else    
                        <div class="form-group"> <input class="category_check" type="checkbox" value="{{$category->id}}" id="{{$category->id}}"> <label for="25">{{ $category->title }}</label> </div>
                        @endif       
                        
      </div>
    </div><!-- /.accordion-item-body -->
  </div><!-- /.accordion-item -->
</div>         
                 <button type="button" class="apply-filter" onclick="hideCategoryFilters()" style="background-color: #642221;
    color: #fff;
    width: 100%;
    font-weight: 700;
    border-radius: 10px;
    font-size: 16px;
    padding: 30px 25px 30px 25px;">Apply Filters</button>
                
                    </div>
                 </div>
					<!-- STORE -->
					<div id="store" class="col-md-9">
<div id="ajax_result">

						<!-- store top filter -->
						<div class="store-filter clearfix">
                        <div  class="slides-3 swiper-container swiper-container-initialized swiper-container-horizontal swiper-container-pointer-events"><div class="swiper-wrapper" style="transition-duration: 0ms; transform: translate3d(0px, 0px, 0px);">
                                             
                        @php $brands_ids = collect($brands_ids); @endphp                       
                        @php $brands = \App\Models\Brand::all(); @endphp
                        @foreach($brands as $brand)
                        <div class="swiper-slide" style="margin-right: 20px;"><button type="button"  class="text-primary-700 px-4 flex items-center justify-center text-center has-active-state SubCategory__item brand_btn" value="{{$brand->slug}}" onclick="getProducts(this.value)" style="width:100%;"><span  class="text-sm font-bold m swiper-text">
                        @if(app()->getLocale() == 'ar')
                        {{$brand->title_ar}}
                        @else
                        {{$brand->title}}
                        @endif
                        </span></button></div>
                        @endforeach
        </div> <div class="flex mt-5"><button aria-label="next slide" class="swiper-button-next hologram-link text-white hover: mr-8"><img src="/front/images/prev.png" al=""/></button> <button data-v-3f2087ee="" aria-label="previous slide" class="swiper-button-prev hologram-link text-white mr-7"><img src="/front/images/next.png" alt=""/></button></div></div>
                        <div id="btnContainer" style="float:right;">
                          <button class="btn" onclick="listView()"><i class="fa fa-bars"></i></button> 
                          <button class="btn active" onclick="gridView()"><i class="fa fa-th-large"></i></button>
                        </div>
						</div>
						<!-- /store top filter -->

						<!-- store products -->
						<div class="row">                        
                        <!-- product -->
    @if(count($products)>0)
                            @foreach($products as $product)
                                      @php
                                         $category = \App\Models\Category::where('id',$product->cat_id)->first();
                                      @endphp
							<div class="col-sm-3 col-xs-6 column">					
                               
                                <div class="product">
                                    <div class="product-img">
                                         <div class="product-btns">
                                            <button class="add-to-wishlist"><i class="fa fa-heart-o"></i><span
                                                    class="tooltipp">add to wishlist</span></button> 
                                                    </div>
                                        <img  src="/{{$product->photo}}" alt="">
                                        <div class="product-label">
                                            <span class="new">{{trans('home/body.new')}}</span>
                                        </div>
                                    </div>
                                    <div class="product-body">
                                         @if(app()->getLocale() == 'ar')
                                         <p class="product-category">{{$category->title_ar}}</p>
                                        <h3 class="product-name"><a href="#">{{$product->title_ar}}</a></h3>
                                         @else
                                        <p class="product-category">{{$category->title}}</p>
                                        <h3 class="product-name"><a href="#">{{$product->title}}</a></h3>
                                        @endif
                                        @php
                                                    $after_discount=($product->price-($product->price*$product->discount)/100);
                                                @endphp
                                        <h4 class="product-price">{{number_format($after_discount,2)}} Rs
                                        @if($product->discount == 0)
                                        @else
                                        <del class="product-old-price">{{$product->price}}</del>
                                        @endif
                                        </h4>
            <!--                            <div class="product-rating">-->
												<!--</div>-->
                                         <div class="product-btns">
                                            <!--<button class="add-to-wishlist"><i class="fa fa-heart-o"></i><span-->
                                            <!--        class="tooltipp">add to wishlist</span></button>-->
                                            <button class="add-to-compare" id="compare"><i class="fa fa-exchange"></i><span
                                                    class="tooltipp">add to compare</span></button> 
                                            <button type="button"
                                                style="background-color: #642221; width:auto;  text-transform: uppercase; font-weight: 700;border-radius: 40px;text-transform: uppercase;font-size:13px;padding:0px 25px 5px 25px;"
                                                class="btn btn-danger" id="add"> {{trans('home/body.addtocart')}}</button>

                                            <a data-toggle="modal" data-target="#{{$product->id}}" title="Quick View" href="#" class="quick-view"><i class="fa fa-eye"></i><span
                                                    class="tooltipp">quick view</span></a>                                                    
                                        </div>
                                    </div>
                                    <!--<div class="add-to-cart">-->
                                    <!--    <button class="add-to-cart-btn"><i class="fa fa-shopping-cart"></i> add to-->
                                    <!--        cart</button>-->
                                    <!--</div>-->
                                </div>                              
							</div>
							<!-- /product -->
                            @endforeach		
                            @else
                            <h4 class="text-warning" style="margin:100px auto;">There are no products.</h4>
                            @endif				
						</div>
						<!-- /store products -->
                        
		
</div>
<!-- store bottom filter -->
<div class="store-filter clearfix">
							<!-- <span class="store-qty">Showing 20-100 products</span> -->
							<ul class="store-pagination">
                            {{$products->appends($_GET)->links()}}							
							</ul>
						</div>
						<!-- /store bottom filter -->
					</div>
					<!-- /STORE -->
@endif
</div>
				<!-- /row -->
			</div>
			<!-- /container -->
		</div>

          <!-- Modal -->
          @if($products)
        @foreach($products as $key=>$product)
            <div class="modal fade" id="{{$product->id}}" tabindex="-1" role="dialog">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span class="ti-close" aria-hidden="true"></span></button>
                            </div>
                            <div class="modal-body">
                                <div class="row no-gutters">
                                    <div class="col-lg-6 col-md-12 col-sm-12 col-xs-12">
                                        <!-- Product Slider -->
                                            <div class="product-gallery">
                                                <div class="quickview-slider-active">
                                                    @if(str_contains($product->photo, ','))
                                                    @php
                                                        $photo=explode(',',$product->photo);
                                                    // dd($photo);
                                                    @endphp
                                                    @foreach($photo as $data)
                                                        <div class="single-slider">
                                                            <img src="{{$data}}" alt="{{$data}}">
                                                        </div>
                                                    @endforeach
                                                    @else
                                                    <div class="single-slider">
                                                            <img src="/{{$product->photo}}" alt="{{$product->photo}}" style="width:100%;">
                                                        </div>
                                                    @endif
                                                </div>
                                            </div>
                                        <!-- End Product slider -->
                                    </div>
                                    <div class="col-lg-6 col-md-12 col-sm-12 col-xs-12">
                                        <div class="quickview-content">
                                            <h2>{{$product->title}}</h2>
                                            <div class="quickview-ratting-review">
                                                <div class="quickview-ratting-wrap">
                                                    <div class="quickview-ratting">
                                                        {{-- <i class="yellow fa fa-star"></i>
                                                        <i class="yellow fa fa-star"></i>
                                                        <i class="yellow fa fa-star"></i>
                                                        <i class="yellow fa fa-star"></i>
                                                        <i class="fa fa-star"></i> --}}
                                                        @php
                                                            $rate=DB::table('product_reviews')->where('product_id',$product->id)->avg('rate');
                                                            $rate_count=DB::table('product_reviews')->where('product_id',$product->id)->count();
                                                        @endphp
                                                        @for($i=1; $i<=5; $i++)
                                                            @if($rate>=$i)
                                                                <i class="yellow fa fa-star"></i>
                                                            @else
                                                            <i class="fa fa-star"></i>
                                                            @endif
                                                        @endfor
                                                    </div>
                                                    <a href="#"> ({{$rate_count}} customer review)</a>
                                                </div>
                                                <div class="quickview-stock">
                                                    @if($product->stock >0)
                                                    <span><i class="fa fa-check-circle-o"></i> {{$product->stock}} in stock</span>
                                                    @else
                                                    <span><i class="fa fa-times-circle-o text-danger"></i> {{$product->stock}} out stock</span>
                                                    @endif
                                                </div>
                                            </div>
                                            @php
                                                $after_discount=($product->price-($product->price*$product->discount)/100);
                                            @endphp
                                            <h3><small><del class="text-muted">${{number_format($product->price,2)}}</del></small>    ${{number_format($after_discount,2)}}  </h3>
                                            <div class="quickview-peragraph">
                                                <p style="text-align:left;">{!! html_entity_decode($product->summary) !!}</p>
                                            </div>
                                            @if($product->size)
                                                <div class="size">
                                                    <h4>Size</h4>
                                                    <ul>
                                                        @php
                                                            $sizes=explode(',',$product->size);
                                                            // dd($sizes);
                                                        @endphp
                                                        @foreach($sizes as $size)
                                                        <li><a href="#" class="one">{{$size}}</a></li>
                                                        @endforeach
                                                    </ul>
                                                </div>
                                            @endif
                                            <div class="size">
                                                <div class="row">
                                                    <div class="col-lg-6 col-12">
                                                        <h5 class="title">Size</h5>
                                                        <select>
                                                            @php
                                                            $sizes=explode(',',$product->size);
                                                            // dd($sizes);
                                                            @endphp
                                                            @foreach($sizes as $size)
                                                                <option>{{$size}}</option>
                                                            @endforeach
                                                        </select>
                                                    </div>
                                                    {{-- <div class="col-lg-6 col-12">
                                                        <h5 class="title">Color</h5>
                                                        <select>
                                                            <option selected="selected">orange</option>
                                                            <option>purple</option>
                                                            <option>black</option>
                                                            <option>pink</option>
                                                        </select>
                                                    </div> --}}
                                                </div>
                                            </div>
                                            <form action="{{route('single-add-to-cart')}}" method="POST">
                                                @csrf
                                                <div class="quantity">
                                                    <!-- Input Order -->
                                                    <div class="input-group">
                                                        <div class="button minus">
                                                            <button type="button" class="btn btn-primary btn-number" disabled="disabled" data-type="minus" data-field="quant[1]">
                                                                <i class="ti-minus"></i>
                                                            </button>
                                                        </div>
                                                        <input type="hidden" name="slug" value="{{$product->slug}}">
                                                        <input type="text" name="quant[1]" class="input-number"  data-min="1" data-max="1000" value="1">
                                                        <div class="button plus">
                                                            <button type="button" class="btn btn-primary btn-number" data-type="plus" data-field="quant[1]">
                                                                <i class="ti-plus"></i>
                                                            </button>
                                                        </div>
                                                    </div>
                                                    <!--/ End Input Order -->
                                                </div>
                                                <div class="add-to-cart">
                                                    <button type="submit" class="btn" style="background-color: #642221; width:auto;  text-transform: uppercase; font-weight: 700;border-radius: 40px;text-transform: uppercase;font-size:13px;padding:0px 25px 5px 25px;color:#fff;">Add to cart</button>
                                                    <a href="{{route('add-to-wishlist',$product->slug)}}" class="btn min"><i class="ti-heart"></i></a>
                                                </div>
                                            </form>
                                            <div class="default-social">
                                            <!-- ShareThis BEGIN --><div class="sharethis-inline-share-buttons"></div><!-- ShareThis END -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
            </div>
        @endforeach
    @endif
    <!-- Modal end -->

    
@endsection
@push('styles')
<style>
    .pagination{
        display:inline-flex;
    }
    .filter_button{
        /* height:20px; */
        text-align: center;
        background:#F7941D;
        padding:8px 16px;
        margin-top:10px;
        color: white;
    }
</style>
@endpush
@push('scripts')
    <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>
    {{-- <script>
        $('.cart').click(function(){
            var quantity=1;
            var pro_id=$(this).data('id');
            $.ajax({
                url:"{{route('add-to-cart')}}",
                type:"POST",
                data:{
                    _token:"{{csrf_token()}}",
                    quantity:quantity,
                    pro_id:pro_id
                },
                success:function(response){
                    console.log(response);
					if(typeof(response)!='object'){
						response=$.parseJSON(response);
					}
					if(response.status){
						swal('success',response.msg,'success').then(function(){
							document.location.href=document.location.href;
						});
					}
                    else{
                        swal('error',response.msg,'error').then(function(){
							// document.location.href=document.location.href;
						});
                    }
                }
            })
        });
    </script> --}}
    <script>
        $(document).ready(function(){            
        /*----------------------------------------------------*/
        /*  Jquery Ui slider js
        /*----------------------------------------------------*/
        if ($("#slider-range").length > 0) {
            const max_value = parseInt( $("#slider-range").data('max') ) || 500;
            const min_value = parseInt($("#slider-range").data('min')) || 0;
            const currency = $("#slider-range").data('currency') || '';
            let price_range = min_value+'-'+max_value;
            if($("#price_range").length > 0 && $("#price_range").val()){
                price_range = $("#price_range").val().trim();
            }

            let price = price_range.split('-');
            $("#slider-range").slider({
                range: true,
                min: min_value,
                max: max_value,
                values: price,
                slide: function (event, ui) {
                    $("#amount").val(currency + ui.values[0] + " -  "+currency+ ui.values[1]);
                    $("#price_range").val(ui.values[0] + "-" + ui.values[1]);
                }
            });
            }
        if ($("#amount").length > 0) {
            const m_currency = $("#slider-range").data('currency') || '';
            $("#amount").val(m_currency + $("#slider-range").slider("values", 0) +
                "  -  "+m_currency + $("#slider-range").slider("values", 1));
            }
        })
       
    </script>
    
    <script>
      const os_Ids = [];
      const brands_Ids = [];
      const hard_type_Ids = [];
      const installed_ram_Ids = [];
      const cpu_types_Ids = [];
      const graphic_coprocessor_Ids = [];
      const display_types_Ids = [];  
      const conn_tech_Ids = []; 
      const natv_res_Ids = []; 
      const inc_comp_Ids = []; 
      const display_res_Ids = [];
      const monitor_feature_Ids = [];
      const price = [];
      const product_length_Ids = [];
      const hard_capacity_Ids = [];
      $('.os_check').click(function() {
        var prodId = window.location.href.split('/').reverse()[0];        
        os_Ids.push($(this).attr('id'));
        var dataString = 'id=' + prodId +  '&os=' + os_Ids + '&brands=' + brands_Ids + '&hard_types=' + hard_type_Ids + '&ram_capcity=' + installed_ram_Ids + '&cpu_type=' + cpu_types_Ids +
                         '&graphic_coprocessor=' + graphic_coprocessor_Ids + '&display_type=' + display_types_Ids + '&conn_tech=' + conn_tech_Ids + '&natv_res=' + natv_res_Ids + 
                         '&inc_comp=' + inc_comp_Ids + '&display_res=' + display_res_Ids + '&monitor_feature=' + monitor_feature_Ids + '&price=' + price + '&product_length=' + product_length_Ids + '&hard_capacity_Ids=' +hard_capacity_Ids;  
       if(this.checked){
            $.ajax({
                type: "get",
                url: "{{ url('get-products-ajax') }}",
                data: dataString, //--> send id of checked checkbox on other page
                success: function(data) {                                    
                    $('#ajax_result').html(data);                    
                },
                 error: function() {
                    console.log('it broke');
                },
                complete: function() {
                  console.log('it completed');
                }
            });

            }
      });
      </script>
      <script>      
      $('.hard_type_check').click(function() {
        var prodId = window.location.href.split('/').reverse()[0];        
        hard_type_Ids.push($(this).attr('id'));
        var dataString = 'id=' + prodId +  '&os=' + os_Ids + '&brands=' + brands_Ids + '&hard_types=' + hard_type_Ids + '&ram_capcity=' + installed_ram_Ids + '&cpu_type=' + cpu_types_Ids +
                         '&graphic_coprocessor=' + graphic_coprocessor_Ids + '&display_type=' + display_types_Ids + '&conn_tech=' + conn_tech_Ids + '&natv_res=' + natv_res_Ids + 
                         '&inc_comp=' + inc_comp_Ids + '&display_res=' + display_res_Ids + '&monitor_feature=' + monitor_feature_Ids + '&price=' + price + '&product_length=' + product_length_Ids + '&hard_capacity_Ids=' +hard_capacity_Ids;   
       if(this.checked){
            $.ajax({
                type: "get",
                url: "{{ url('get-products-ajax') }}",
                data: dataString, //--> send id of checked checkbox on other page
                success: function(data) {                                       
                    $('#ajax_result').html(data);                    
                },
                 error: function() {
                    console.log('it broke');
                },
                complete: function() {
                  console.log('it completed');
                }
            });

            }
      });
      </script>
      <script>       
      $('.ram_capcity_check').click(function() {
        var prodId = window.location.href.split('/').reverse()[0];        
        installed_ram_Ids.push($(this).attr('id'));
        var dataString = 'id=' + prodId +  '&os=' + os_Ids + '&brands=' + brands_Ids + '&hard_types=' + hard_type_Ids + '&ram_capcity=' + installed_ram_Ids + '&cpu_type=' + cpu_types_Ids +
                         '&graphic_coprocessor=' + graphic_coprocessor_Ids + '&display_type=' + display_types_Ids + '&conn_tech=' + conn_tech_Ids + '&natv_res=' + natv_res_Ids + 
                         '&inc_comp=' + inc_comp_Ids + '&display_res=' + display_res_Ids + '&monitor_feature=' + monitor_feature_Ids + '&price=' + price + '&product_length=' + product_length_Ids + '&hard_capacity_Ids=' +hard_capacity_Ids;    
       if(this.checked){
            $.ajax({
                type: "get",
                url: "{{ url('get-products-ajax') }}",
                data: dataString, //--> send id of checked checkbox on other page
                success: function(data) {                                      
                    $('#ajax_result').html(data);                    
                },
                 error: function() {
                    console.log('it broke');
                },
                complete: function() {
                  console.log('it completed');
                }
            });

            }
      });
      </script>  
       <script>       
      $('.hard_capcity_check').click(function() {
        var prodId = window.location.href.split('/').reverse()[0];        
        hard_capacity_Ids.push($(this).attr('id'));
        var dataString = 'id=' + prodId +  '&os=' + os_Ids + '&brands=' + brands_Ids + '&hard_types=' + hard_type_Ids + '&ram_capcity=' + installed_ram_Ids + '&cpu_type=' + cpu_types_Ids +
                         '&graphic_coprocessor=' + graphic_coprocessor_Ids + '&display_type=' + display_types_Ids + '&conn_tech=' + conn_tech_Ids + '&natv_res=' + natv_res_Ids + 
                         '&inc_comp=' + inc_comp_Ids + '&display_res=' + display_res_Ids + '&monitor_feature=' + monitor_feature_Ids + '&price=' + price + '&product_length=' + product_length_Ids + '&hard_capacity_Ids=' +hard_capacity_Ids;    
       if(this.checked){
            $.ajax({
                type: "get",
                url: "{{ url('get-products-ajax') }}",
                data: dataString, //--> send id of checked checkbox on other page
                success: function(data) {                                      
                    $('#ajax_result').html(data);                    
                },
                 error: function() {
                    console.log('it broke');
                },
                complete: function() {
                  console.log('it completed');
                }
            });

            }
      });
      </script>
       <script>         
      $('.cpu_type_check').click(function() {
        var prodId = window.location.href.split('/').reverse()[0];        
        cpu_types_Ids.push($(this).attr('id'));
        var dataString = 'id=' + prodId +  '&os=' + os_Ids + '&brands=' + brands_Ids + '&hard_types=' + hard_type_Ids + '&ram_capcity=' + installed_ram_Ids + '&cpu_type=' + cpu_types_Ids +
                         '&graphic_coprocessor=' + graphic_coprocessor_Ids + '&display_type=' + display_types_Ids + '&conn_tech=' + conn_tech_Ids + '&natv_res=' + natv_res_Ids + 
                         '&inc_comp=' + inc_comp_Ids + '&display_res=' + display_res_Ids + '&monitor_feature=' + monitor_feature_Ids + '&price=' + price + '&product_length=' + product_length_Ids + '&hard_capacity_Ids=' +hard_capacity_Ids;     
       if(this.checked){
            $.ajax({
                type: "get",
                url: "{{ url('get-products-ajax') }}",
                data: dataString, //--> send id of checked checkbox on other page
                success: function(data) {                                    
                    $('#ajax_result').html(data);                    
                },
                 error: function() {
                    console.log('it broke');
                },
                complete: function() {
                  console.log('it completed');
                }
            });

            }
      });
      </script>
        <script>       
      $('.graphic_coprocessor_check').click(function() {
        var prodId = window.location.href.split('/').reverse()[0];        
        graphic_coprocessor_Ids.push($(this).attr('id'));
        var dataString = 'id=' + prodId +  '&os=' + os_Ids + '&brands=' + brands_Ids + '&hard_types=' + hard_type_Ids + '&ram_capcity=' + installed_ram_Ids + '&cpu_type=' + cpu_types_Ids +
                         '&graphic_coprocessor=' + graphic_coprocessor_Ids + '&display_type=' + display_types_Ids + '&conn_tech=' + conn_tech_Ids + '&natv_res=' + natv_res_Ids + 
                         '&inc_comp=' + inc_comp_Ids + '&display_res=' + display_res_Ids + '&monitor_feature=' + monitor_feature_Ids + '&price=' + price + '&product_length=' + product_length_Ids + '&hard_capacity_Ids=' +hard_capacity_Ids;   
       if(this.checked){
            $.ajax({
                type: "get",
                url: "{{ url('get-products-ajax') }}",
                data: dataString, //--> send id of checked checkbox on other page
                success: function(data) {                                      
                    $('#ajax_result').html(data);                    
                },
                 error: function() {
                    console.log('it broke');
                },
                complete: function() {
                  console.log('it completed');
                }
            });

            }
      });
      </script>
      <script>       
      $('.display_type_check').click(function() {
        var prodId = window.location.href.split('/').reverse()[0];        
        display_types_Ids.push($(this).attr('id'));
        var dataString = 'id=' + prodId +  '&os=' + os_Ids + '&brands=' + brands_Ids + '&hard_types=' + hard_type_Ids + '&ram_capcity=' + installed_ram_Ids + '&cpu_type=' + cpu_types_Ids +
                         '&graphic_coprocessor=' + graphic_coprocessor_Ids + '&display_type=' + display_types_Ids + '&conn_tech=' + conn_tech_Ids + '&natv_res=' + natv_res_Ids + 
                         '&inc_comp=' + inc_comp_Ids + '&display_res=' + display_res_Ids + '&monitor_feature=' + monitor_feature_Ids + '&price=' + price + '&product_length=' + product_length_Ids + '&hard_capacity_Ids=' +hard_capacity_Ids;     
       if(this.checked){
            $.ajax({
                type: "get",
                url: "{{ url('get-products-ajax') }}",
                data: dataString, //--> send id of checked checkbox on other page
                success: function(data) {                                      
                    $('#ajax_result').html(data);                    
                },
                 error: function() {
                    console.log('it broke');
                },
                complete: function() {
                  console.log('it completed');
                }
            });

            }
      });
      </script>
       <script>      
      $('.conn_tech_check').click(function() {
        var prodId = window.location.href.split('/').reverse()[0];        
        conn_tech_Ids.push($(this).attr('id'));
        var dataString = 'id=' + prodId +  '&os=' + os_Ids + '&brands=' + brands_Ids + '&hard_types=' + hard_type_Ids + '&ram_capcity=' + installed_ram_Ids + '&cpu_type=' + cpu_types_Ids +
                         '&graphic_coprocessor=' + graphic_coprocessor_Ids + '&display_type=' + display_types_Ids + '&conn_tech=' + conn_tech_Ids + '&natv_res=' + natv_res_Ids + 
                         '&inc_comp=' + inc_comp_Ids + '&display_res=' + display_res_Ids + '&monitor_feature=' + monitor_feature_Ids + '&price=' + price + '&product_length=' + product_length_Ids + '&hard_capacity_Ids=' +hard_capacity_Ids;    
       if(this.checked){
            $.ajax({
                type: "get",
                url: "{{ url('get-products-ajax') }}",
                data: dataString, //--> send id of checked checkbox on other page
                success: function(data) {                                      
                    $('#ajax_result').html(data);                    
                },
                 error: function() {
                    console.log('it broke');
                },
                complete: function() {
                  console.log('it completed');
                }
            });

            }
      });
      </script>
       <script>       
      $('.natv_res_check').click(function() {
        var prodId = window.location.href.split('/').reverse()[0];        
        natv_res_Ids.push($(this).attr('id'));
        var dataString = 'id=' + prodId +  '&os=' + os_Ids + '&brands=' + brands_Ids + '&hard_types=' + hard_type_Ids + '&ram_capcity=' + installed_ram_Ids + '&cpu_type=' + cpu_types_Ids +
                         '&graphic_coprocessor=' + graphic_coprocessor_Ids + '&display_type=' + display_types_Ids + '&conn_tech=' + conn_tech_Ids + '&natv_res=' + natv_res_Ids + 
                         '&inc_comp=' + inc_comp_Ids + '&display_res=' + display_res_Ids + '&monitor_feature=' + monitor_feature_Ids + '&price=' + price + '&product_length=' + product_length_Ids + '&hard_capacity_Ids=' +hard_capacity_Ids;     
       if(this.checked){
            $.ajax({
                type: "get",
                url: "{{ url('get-products-ajax') }}",
                data: dataString, //--> send id of checked checkbox on other page
                success: function(data) {                                      
                    $('#ajax_result').html(data);                    
                },
                 error: function() {
                    console.log('it broke');
                },
                complete: function() {
                  console.log('it completed');
                }
            });

            }
      });
      </script>
        <script>       
      $('.inc_comp_check').click(function() {
        var prodId = window.location.href.split('/').reverse()[0];        
        inc_comp_Ids.push($(this).attr('id'));
        var dataString = 'id=' + prodId +  '&os=' + os_Ids + '&brands=' + brands_Ids + '&hard_types=' + hard_type_Ids + '&ram_capcity=' + installed_ram_Ids + '&cpu_type=' + cpu_types_Ids +
                         '&graphic_coprocessor=' + graphic_coprocessor_Ids + '&display_type=' + display_types_Ids + '&conn_tech=' + conn_tech_Ids + '&natv_res=' + natv_res_Ids + 
                         '&inc_comp=' + inc_comp_Ids + '&display_res=' + display_res_Ids + '&monitor_feature=' + monitor_feature_Ids + '&price=' + price + '&product_length=' + product_length_Ids + '&hard_capacity_Ids=' +hard_capacity_Ids;     
       if(this.checked){
            $.ajax({
                type: "get",
                url: "{{ url('get-products-ajax') }}",
                data: dataString, //--> send id of checked checkbox on other page
                success: function(data) {                                      
                    $('#ajax_result').html(data);                    
                },
                 error: function() {
                    console.log('it broke');
                },
                complete: function() {
                  console.log('it completed');
                }
            });

            }
      });
      </script> 
        <script>       
      $('.display_res_check').click(function() {
        var prodId = window.location.href.split('/').reverse()[0];        
        display_res_Ids.push($(this).attr('id'));
        var dataString = 'id=' + prodId +  '&os=' + os_Ids + '&brands=' + brands_Ids + '&hard_types=' + hard_type_Ids + '&ram_capcity=' + installed_ram_Ids + '&cpu_type=' + cpu_types_Ids +
                         '&graphic_coprocessor=' + graphic_coprocessor_Ids + '&display_type=' + display_types_Ids + '&conn_tech=' + conn_tech_Ids + '&natv_res=' + natv_res_Ids + 
                         '&inc_comp=' + inc_comp_Ids + '&display_res=' + display_res_Ids + '&monitor_feature=' + monitor_feature_Ids + '&price=' + price + '&product_length=' + product_length_Ids + '&hard_capacity_Ids=' +hard_capacity_Ids;     
       if(this.checked){
            $.ajax({
                type: "get",
                url: "{{ url('get-products-ajax') }}",
                data: dataString, //--> send id of checked checkbox on other page
                success: function(data) {                                      
                    $('#ajax_result').html(data);                    
                },
                 error: function() {
                    console.log('it broke');
                },
                complete: function() {
                  console.log('it completed');
                }
            });

            }
      });
      </script> 
       <script>       
      $('.monitor_feature_check').click(function() {
        var prodId = window.location.href.split('/').reverse()[0];        
        monitor_feature_Ids.push($(this).attr('id'));
        var dataString = 'id=' + prodId +  '&os=' + os_Ids + '&brands=' + brands_Ids + '&hard_types=' + hard_type_Ids + '&ram_capcity=' + installed_ram_Ids + '&cpu_type=' + cpu_types_Ids +
                         '&graphic_coprocessor=' + graphic_coprocessor_Ids + '&display_type=' + display_types_Ids + '&conn_tech=' + conn_tech_Ids + '&natv_res=' + natv_res_Ids + 
                         '&inc_comp=' + inc_comp_Ids + '&display_res=' + display_res_Ids + '&monitor_feature=' + monitor_feature_Ids + '&price=' + price + '&product_length=' + product_length_Ids + '&hard_capacity_Ids=' +hard_capacity_Ids;     
       if(this.checked){
            $.ajax({
                type: "get",
                url: "{{ url('get-products-ajax') }}",
                data: dataString, //--> send id of checked checkbox on other page
                success: function(data) {                                      
                    $('#ajax_result').html(data);                    
                },
                 error: function() {
                    console.log('it broke');
                },
                complete: function() {
                  console.log('it completed');
                }
            });

            }
      });
      </script> 
       <script>       
      $('.product_length_check').click(function() {
        var prodId = window.location.href.split('/').reverse()[0];        
        product_length_Ids.push($(this).attr('id'));
        var dataString = 'id=' + prodId +  '&os=' + os_Ids + '&brands=' + brands_Ids + '&hard_types=' + hard_type_Ids + '&ram_capcity=' + installed_ram_Ids + '&cpu_type=' + cpu_types_Ids +
                         '&graphic_coprocessor=' + graphic_coprocessor_Ids + '&display_type=' + display_types_Ids + '&conn_tech=' + conn_tech_Ids + '&natv_res=' + natv_res_Ids + 
                         '&inc_comp=' + inc_comp_Ids + '&display_res=' + display_res_Ids + '&monitor_feature=' + monitor_feature_Ids + '&price=' + price + '&product_length=' + product_length_Ids + '&hard_capacity_Ids=' +hard_capacity_Ids;     
       if(this.checked){
            $.ajax({
                type: "get",
                url: "{{ url('get-products-ajax') }}",
                data: dataString, //--> send id of checked checkbox on other page
                success: function(data) {                                      
                    $('#ajax_result').html(data);                    
                },
                 error: function() {
                    console.log('it broke');
                },
                complete: function() {
                  console.log('it completed');
                }
            });

            }
      });
      </script> 
      <script>
     //   var minValue = 0;
        // jQuery(function($) {
        //   $('#from').on('input', function() {
        //       var fromValue = $('#from').val();
        //       price[0] = minValue;
        //       price[1] = fromValue;
        //     var dataString = 'id=' + prodId +  '&os=' + os_Ids + '&brands=' + brands_Ids + '&hard_types=' + hard_type_Ids + '&ram_capcity=' + installed_ram_Ids + '&cpu_type=' + cpu_types_Ids +
        //                  '&graphic_coprocessor=' + graphic_coprocessor_Ids + '&display_type=' + display_types_Ids + '&conn_tech=' + conn_tech_Ids + '&natv_res=' + natv_res_Ids + 
        //                  '&inc_comp=' + inc_comp_Ids + '&display_res=' + display_res_Ids + '&monitor_feature=' + monitor_feature_Ids + '&price=' + price;     
      
        //     $.ajax({
        //         type: "get",
        //         url: "{{ url('get-products-ajax') }}",
        //         data: dataString, //--> send id of checked checkbox on other page
        //         success: function(data) {                                      
        //             $('#ajax_result').html(data);                    
        //         },
        //          error: function() {
        //             console.log('it broke');
        //         },
        //         complete: function() {
        //           console.log('it completed');
        //         }
        //     });
        // });
        // });
      </script>
      <script>
        const rangeInput = document.querySelectorAll(".range-input input"),
  priceInput = document.querySelectorAll(".price-input input"),
  range = document.querySelector(".slider .progress");
let priceGap = 0;

priceInput.forEach((input) => {
  input.addEventListener("input", (e) => {
    let minPrice = parseInt(priceInput[0].value),
      maxPrice = parseInt(priceInput[1].value);

    if (maxPrice - minPrice >= priceGap && maxPrice <= rangeInput[1].max) {
      if (e.target.className === "input-min") {
        rangeInput[0].value = minPrice;
        range.style.left = (minPrice / rangeInput[0].max) * 100 + "%";
      } else {
        rangeInput[1].value = maxPrice;
        range.style.right = 100 - (maxPrice / rangeInput[1].max) * 100 + "%";
      }
    }
  });
});

rangeInput.forEach((input) => {
  input.addEventListener("input", (e) => {
    let minVal = parseInt(rangeInput[0].value),
      maxVal = parseInt(rangeInput[1].value);
      var prodId = window.location.href.split('/').reverse()[0];  
      price[0] = 0;
              price[1] = minVal;
              $('.range-input input').css('background','#642221');
              $('.range-input input').css('height','5px');
            var dataString = 'id=' + prodId +  '&os=' + os_Ids + '&brands=' + brands_Ids + '&hard_types=' + hard_type_Ids + '&ram_capcity=' + installed_ram_Ids + '&cpu_type=' + cpu_types_Ids +
                         '&graphic_coprocessor=' + graphic_coprocessor_Ids + '&display_type=' + display_types_Ids + '&conn_tech=' + conn_tech_Ids + '&natv_res=' + natv_res_Ids + 
                         '&inc_comp=' + inc_comp_Ids + '&display_res=' + display_res_Ids + '&monitor_feature=' + monitor_feature_Ids + '&price=' + price + '&product_length=' + product_length_Ids + '&hard_capacity_Ids=' +hard_capacity_Ids;     
      
    if (maxVal - minVal < priceGap) {
      if (e.target.className === "range-min") {
        rangeInput[0].value = maxVal - priceGap;
      } else {
        rangeInput[1].value = minVal + priceGap;
      }
    } else {
      priceInput[0].value = minVal;
      priceInput[1].value = maxVal;
      range.style.left = (minVal / rangeInput[0].max) * 100 + "%";
      range.style.right = 100 - (maxVal / rangeInput[1].max) * 100 + "%";
    }
    
            $.ajax({
                type: "get",
                url: "{{ url('get-products-ajax') }}",
                data: dataString, //--> send id of checked checkbox on other page
                success: function(data) {                                      
                    $('#ajax_result').html(data);                    
                },
                 error: function() {
                    console.log('it broke');
                },
                complete: function() {
                  console.log('it completed');
                }
            });
  });
});

    </script>
    <script>      
      $('.brand_check').click(function() {
        var prodId = window.location.href.split('/').reverse()[0];        
        brands_Ids.push($(this).attr('id'));
        var dataString = 'id=' + prodId +  '&os=' + os_Ids + '&brands=' + brands_Ids + '&hard_types=' + hard_type_Ids + '&ram_capcity=' + installed_ram_Ids + '&cpu_type=' + cpu_types_Ids +
                         '&graphic_coprocessor=' + graphic_coprocessor_Ids + '&display_type=' + display_types_Ids + '&conn_tech=' + conn_tech_Ids + '&natv_res=' + natv_res_Ids + 
                         '&inc_comp=' + inc_comp_Ids + '&display_res=' + display_res_Ids + '&monitor_feature=' + monitor_feature_Ids + '&price=' + price + '&product_length=' + product_length_Ids + '&hard_capacity_Ids=' +hard_capacity_Ids;  
   // alert($(this).attr('id'));  //-->this will alert id of checked checkbox.
   console.log(dataString);
       if(this.checked){
            $.ajax({
                type: "get",
                url: "{{ url('get-products-ajax') }}",
                data: dataString, //--> send id of checked checkbox on other page
                success: function(data) {
                    // alert('it worked');
                    // alert(data);
                    
                    $('#ajax_result').html(data);
                    var arrayLength = brands_Ids.length;
                    for (var i = 0; i < arrayLength; i++) {
                       // console.log(myStringArray[i]);
                     //   document.getElementById("+brands_Ids[i]+").checked = true;
                        //Do something
                    }
                },
                 error: function() {
                    console.log('it broke');
                },
                complete: function() {
                  console.log('it completed');
                }
            });

            }
      });
      </script>
      <script>
              $('.category_check').click(function() {
       // var prodId = window.location.href.split('/').reverse()[0];        
        //brands_Ids.push($(this).attr('id'));
            var dataString = 'id=' + $(this).attr('id');
    //alert($(this).attr('id'));  //-->this will alert id of checked checkbox.
   console.log(dataString);
       if(this.checked){
            $.ajax({
                type: "get",
                url: "{{ url('get-products-ajax') }}",
                data: dataString, //--> send id of checked checkbox on other page
                success: function(data) {
                    // alert('it worked');
                    console.log(data);
                    
                    $('#ajax_result').html(data);                   
                },
                 error: function() {
                    console.log('it broke');
                },
                complete: function() {
                  console.log('it completed');
                }
            });

            }
      });
      </script>
      <script>
        function getProducts(val)
        {
            var prodId = window.location.href.split('/').reverse()[0];  
          var dataString = 'id=' + prodId + '&brands=' + val;
          console.log(dataString);
          $.ajax({
                type: "get",
                url: "{{ url('get-products-ajax') }}",
                data: dataString, //--> send id of checked checkbox on other page
                success: function(data) {
                    // alert('it worked');
                    // alert(data);
                    
                    $('#ajax_result').html(data);                   
                },
                 error: function() {
                    console.log('it broke');
                },
                complete: function() {
                  console.log('it completed');
                }
            }); 

        }
        
      </script>
     
@endpush

