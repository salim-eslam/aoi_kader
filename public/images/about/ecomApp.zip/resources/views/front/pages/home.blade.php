@extends('front.layouts.master')

@section('title','Alsaif || Home')

@section('main-content')
{{-- Slider  --}}

<div style=" padding-right: inherit;
padding-left: inherit;" class="container-fluid">

    <div id="myCarousel" class="carousel slide" data-ride="carousel">
        <!-- Indicators -->
        <ol class="carousel-indicators">
            <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
            <li data-target="#myCarousel" data-slide-to="1"></li>
            <li data-target="#myCarousel" data-slide-to="2"></li>
        </ol>

        <!-- Wrapper for slides -->
        <div class="carousel-inner">
            <div class="item active">
                 @if(app()->getLocale() == 'ar')
                  <img src="{{ asset('front/images/Banner/1.jpg') }}" alt="Los Angeles" style="width:100%;">
                 @else
                <img src="{{ asset('front/images/Banner/1 EN.jpg') }}" alt="Los Angeles" style="width:100%;">
                @endif
            </div>

            <div class="item">
                 @if(app()->getLocale() == 'ar')
                  <img src="{{ asset('front/images/Banner/2.jpg') }}" alt="Los Angeles" style="width:100%;">
                 @else
                <img src="{{ asset('front/images/Banner/2 EN.jpg') }}" alt="Chicago" style="width:100%;">
                @endif
            </div>

            <div class="item">
                 @if(app()->getLocale() == 'ar')
                  <img src="{{ asset('front/images/Banner/3.jpg') }}" alt="Los Angeles" style="width:100%;">
                 @else
                <img src="{{ asset('front/images/Banner/3 EN.jpg') }}" alt="New york" style="width:100%;">
                @endif
            </div>
        </div>

        <!-- Left and right controls -->
        <a class="left carousel-control" href="#myCarousel" data-slide="prev">
            <span class="glyphicon glyphicon-chevron-left"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="right carousel-control" href="#myCarousel" data-slide="next">
            <span class="glyphicon glyphicon-chevron-right"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>
</div>

<!-- SECTION -->
<div class="section">
    <!-- container -->
    <div class="container">
        <!-- row -->
        <div class="row">

            <!-- section title -->
            <div class="col-md-12">
                <div class="section-title">
                    <h3 class="title">{{trans('home/body.RECOMMENDEDCOLLECTIONS')}}
                    </h3>
                    
                </div>
            </div>
            <!-- /section title -->

            <!-- Products tab & slick -->
            <div class="col-md-12">
                <div class="row">
                    <div class="products-tabs">
                        <!-- tab -->
                        <div id="tab1" class="tab-pane active">
                             @if(app()->getLocale() == 'ar')
                               <div class="products-slick" data-nav="#slick-nav-1" dir="rtl">
                             @else
                            <div class="products-slick" data-nav="#slick-nav-1">
                             @endif
                                <!-- product -->
                                <div class="product">
                                    <div class="product-img">
                                         <div class="product-btns">
                                      <button class="add-to-wishlist"><i class="fa fa-heart-o"></i><span
                                                    class="tooltipp">add to wishlist</span></button>
                                                    </div>
                                        <img src="{{ asset('front//img/product01.png') }}" alt="">
                                        <div class="product-label">
                                            <span class="sale">-30%</span>
                                            <span class="new">{{trans('home/body.new')}}</span>
                                        </div>
                                    </div>
                                    <div class="product-body">
                                        <p class="product-category">Category</p>
                                        <h3 class="product-name"><a href="#">product name goes here</a></h3>
                                        <h4 class="product-price">$980.00 <del
                                                class="product-old-price">$990.00</del></h4>
                                        <div class="product-rating">
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                        </div>
                                          <div class="product-btns">
                                            <!--<button class="add-to-wishlist"><i class="fa fa-heart-o"></i><span-->
                                            <!--        class="tooltipp">add to wishlist</span></button>-->
                                            <button class="add-to-compare"><i class="fa fa-exchange"></i><span
                                                    class="tooltipp">add to compare</span></button> 
                                            <button type="button"
                                                style="background-color: #642221; width:auto;  text-transform: uppercase; font-weight: 700;border-radius: 40px;text-transform: uppercase;font-size:13px;padding:0px 25px 5px 25px;"
                                                class="btn btn-danger"> <span>{{trans('home/body.addtocart')}}</span></button>

                                            <button class="quick-view"><i class="fa fa-eye"></i><span
                                                    class="tooltipp">quick view</span></button>
                                        </div>
                                    </div>
                                    <!--<div class="add-to-cart">-->
                                    <!--    <button class="add-to-cart-btn"><i class="fa fa-shopping-cart"></i> add to-->
                                    <!--        cart</button>-->
                                    <!--</div>-->
                                </div>
                                <!-- /product -->

                                <!-- product -->
                                <div class="product">
                                    <div class="product-img">
                                         <div class="product-btns">
                                         <button class="add-to-wishlist"><i class="fa fa-heart-o"></i><span
                                                    class="tooltipp">add to wishlist</span></button>
                                                    </div>
                                        <img src="{{ asset('front//img/product02.png') }}" alt="">
                                        <div class="product-label">
                                            <span class="new">{{trans('home/body.new')}}</span>
                                        </div>
                                    </div>
                                    <div class="product-body">
                                        <p class="product-category">Category</p>
                                        <h3 class="product-name"><a href="#">product name goes here</a></h3>
                                        <h4 class="product-price">$980.00 <del
                                                class="product-old-price">$990.00</del></h4>
                                        <div class="product-rating">
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star-o"></i>
                                        </div>
                                         <div class="product-btns">
                                            <!--<button class="add-to-wishlist"><i class="fa fa-heart-o"></i><span-->
                                            <!--        class="tooltipp">add to wishlist</span></button>-->
                                            <button class="add-to-compare"><i class="fa fa-exchange"></i><span
                                                    class="tooltipp">add to compare</span></button> 
                                            <button type="button"
                                                style="background-color: #642221; width:auto;  text-transform: uppercase; font-weight: 700;border-radius: 40px;text-transform: uppercase;font-size:13px;padding: 0px 25px 5px 25px;"
                                                class="btn btn-danger">  <span>{{trans('home/body.addtocart')}}</span></button>

                                            <button class="quick-view"><i class="fa fa-eye"></i><span
                                                    class="tooltipp">quick view</span></button>
                                        </div>
                                    </div>
                                    <!--<div class="add-to-cart">-->
                                    <!--    <button class="add-to-cart-btn"><i class="fa fa-shopping-cart"></i> add to-->
                                    <!--        cart</button>-->
                                    <!--</div>-->
                                </div>
                                <!-- /product -->

                                <!-- product -->
                                <div class="product">
                                    <div class="product-img">
                                         <div class="product-btns">
                                            <button class="add-to-wishlist"><i class="fa fa-heart-o"></i><span
                                                    class="tooltipp">add to wishlist</span></button> 
                                                    </div>
                                        <img src="{{ asset('front//img/product03.png') }}" alt="">
                                        <div class="product-label">
                                            <span class="sale">-30%</span>
                                        </div>
                                    </div>
                                    <div class="product-body">
                                        <p class="product-category">Category</p>
                                        <h3 class="product-name"><a href="#">product name goes here</a></h3>
                                        <h4 class="product-price">$980.00 <del
                                                class="product-old-price">$990.00</del></h4>
                                        <div class="product-rating">
                                        </div>
                                       
                                          <div class="product-btns">
                                            <!--<button class="add-to-wishlist"><i class="fa fa-heart-o"></i><span-->
                                            <!--        class="tooltipp">add to wishlist</span></button>-->
                                            <button class="add-to-compare"><i class="fa fa-exchange"></i><span
                                                    class="tooltipp">add to compare</span></button> 
                                            <button type="button"
                                                style="background-color: #642221; width:auto;  text-transform: uppercase; font-weight: 700;border-radius: 40px;text-transform: uppercase;font-size:13px;padding: 0px 25px 5px 25px;"
                                                class="btn btn-danger">  <span>{{trans('home/body.addtocart')}}</span></button>

                                            <button class="quick-view"><i class="fa fa-eye"></i><span
                                                    class="tooltipp">quick view</span></button>
                                        </div>
                                    </div>
                                    <!--<div class="add-to-cart">-->
                                    <!--    <button class="add-to-cart-btn"><i class="fa fa-shopping-cart"></i> add to-->
                                    <!--        cart</button>-->
                                    <!--</div>-->
                                </div>
                                <!-- /product -->

                                <!-- product -->
                                <div class="product">
                                    <div class="product-img">
                                         <div class="product-btns">
                                            <button class="add-to-wishlist"><i class="fa fa-heart-o"></i><span
                                                    class="tooltipp">add to wishlist</span></button> 
                                                    </div>
                                        <img src="{{ asset('front//img/product04.png') }}" alt="">
                                    </div>
                                    <div class="product-body">
                                        <p class="product-category">Category</p>
                                        <h3 class="product-name"><a href="#">product name goes here</a></h3>
                                        <h4 class="product-price">$980.00 <del
                                                class="product-old-price">$990.00</del></h4>
                                        <div class="product-rating">
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                        </div>
                                        <div class="product-btns">
                                            <!--<button class="add-to-wishlist"><i class="fa fa-heart-o"></i><span-->
                                            <!--        class="tooltipp">add to wishlist</span></button>-->
                                            <button class="add-to-compare"><i class="fa fa-exchange"></i><span
                                                    class="tooltipp">add to compare</span></button> 
                                            <button type="button"
                                                style="background-color: #642221; width:auto;  text-transform: uppercase; font-weight: 700;border-radius: 40px;text-transform: uppercase;font-size:13px;padding:0px 25px 5px 25px;"
                                                class="btn btn-danger">  <span>{{trans('home/body.addtocart')}}</span></button>

                                            <button class="quick-view"><i class="fa fa-eye"></i><span
                                                    class="tooltipp">quick view</span></button>
                                        </div>
                                    </div>
                                    <!--<div class="add-to-cart">-->
                                    <!--    <button class="add-to-cart-btn"><i class="fa fa-shopping-cart"></i> add to-->
                                    <!--        cart</button>-->
                                    <!--</div>-->
                                </div>
                                <!-- /product -->

                                <!-- product -->
                                <div class="product">
                                    <div class="product-img">
                                         <div class="product-btns">
                                            <button class="add-to-wishlist"><i class="fa fa-heart-o"></i><span
                                                    class="tooltipp">add to wishlist</span></button> 
                                                    </div>
                                        <img src="{{ asset('front//img/product05.png') }}" alt="">
                                    </div>
                                    <div class="product-body">
                                        <p class="product-category">Category</p>
                                        <h3 class="product-name"><a href="#">product name goes here</a></h3>
                                        <h4 class="product-price">$980.00 <del
                                                class="product-old-price">$990.00</del></h4>
                                        <div class="product-rating">
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                        </div>
                                        <div class="product-btns">
                                            <!--<button class="add-to-wishlist"><i class="fa fa-heart-o"></i><span-->
                                            <!--        class="tooltipp">add to wishlist</span></button>-->
                                            <button class="add-to-compare"><i class="fa fa-exchange"></i><span
                                                    class="tooltipp">add to compare</span></button> 
                                            <button type="button"
                                                style="background-color: #642221; width:auto;  text-transform: uppercase; font-weight: 700;border-radius: 40px;text-transform: uppercase;font-size:13px;padding: 0px 25px 5px 25px;"
                                                class="btn btn-danger">  <span>{{trans('home/body.addtocart')}}</span></button>

                                            <button class="quick-view"><i class="fa fa-eye"></i><span
                                                    class="tooltipp">quick view</span></button>
                                        </div>
                                    </div>
                                    <!--<div class="add-to-cart">-->
                                    <!--    <button class="add-to-cart-btn"><i class="fa fa-shopping-cart"></i> add to-->
                                    <!--        cart</button>-->
                                    <!--</div>-->
                                </div>
                                <!-- /product -->
                            </div>
                            <div id="slick-nav-1" class="products-slick-nav"></div>
                        </div>
                        <!-- /tab -->
                    </div>
                </div>
            </div>
            <!-- Products tab & slick -->
        </div>
        <!-- /row -->
    </div>
    <!-- /container -->
</div>
<!-- /SECTION -->

<!-- HOT DEAL SECTION -->

<!-- /HOT DEAL SECTION -->

<!-- SECTION -->
<div class="section">
    <!-- container -->
    <div class="container">
        <!-- row -->
        <div class="row">

            <!-- section title -->
            <div class="col-md-12">
                <div class="section-title">
                    <h3 class="title">{{trans('home/body.Latestoffers')}}</h3>
                    <div class="section-nav">
                        {{-- <ul class="section-tab-nav tab-nav">
                            <li class="active"><a data-toggle="tab" href="#tab2">Laptops</a></li>
                            <li><a data-toggle="tab" href="#tab2">Smartphones</a></li>
                            <li><a data-toggle="tab" href="#tab2">Cameras</a></li>
                            <li><a data-toggle="tab" href="#tab2">Accessories</a></li>
                        </ul> --}}
                    </div>
                </div>
            </div>
            <!-- /section title -->

            <!-- Products tab & slick -->
            <div class="col-md-12">
                <div class="row">
                    <div class="products-tabs">
                        <!-- tab -->
                        <div id="tab2" class="tab-pane fade in active">
                            @if(app()->getLocale() == 'ar')
                             <div class="products-slick" data-nav="#slick-nav-2">
                            @else
                            <div class="products-slick" data-nav="#slick-nav-2">
                            @endif    
                                <!-- product -->
                                <div class="product">
                                    <div class="product-img">
                                         <div class="product-btns">
                                            <button class="add-to-wishlist"><i class="fa fa-heart-o"></i><span
                                                    class="tooltipp">add to wishlist</span></button> 
                                                    </div>
                                        <img src="{{ asset('front//img/product06.png') }}" alt="">
                                        <div class="product-label">
                                            <span class="sale">-30%</span>
                                            <span class="new">{{trans('home/body.new')}}</span>
                                        </div>
                                    </div>
                                    <div class="product-body">
                                        <p class="product-category">Category</p>
                                        <h3 class="product-name"><a href="#">product name goes here</a></h3>
                                        <h4 class="product-price">$980.00 <del
                                                class="product-old-price">$990.00</del></h4>
                                        <div class="product-rating">
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                        </div>
                                        <div class="product-btns">
                                            <!--<button class="add-to-wishlist"><i class="fa fa-heart-o"></i><span-->
                                            <!--        class="tooltipp">add to wishlist</span></button>-->
                                            <button class="add-to-compare"><i class="fa fa-exchange"></i><span
                                                    class="tooltipp">add to compare</span></button> 
                                            <button type="button"
                                                style="background-color: #642221; width:auto;  text-transform: uppercase; font-weight: 700;border-radius: 40px;text-transform: uppercase;font-size:13px;padding:0px 25px 5px 25px;"
                                                class="btn btn-danger"> {{trans('home/body.addtocart')}}</button>

                                            <button class="quick-view"><i class="fa fa-eye"></i><span
                                                    class="tooltipp">quick view</span></button>
                                        </div>
                                    </div>
                                    <!--<div class="add-to-cart">-->
                                    <!--    <button class="add-to-cart-btn"><i class="fa fa-shopping-cart"></i> add to-->
                                    <!--        cart</button>-->
                                    <!--</div>-->
                                </div>
                                <!-- /product -->

                                <!-- product -->
                                <div class="product">
                                    <div class="product-img">
                                         <div class="product-btns">
                                            <button class="add-to-wishlist"><i class="fa fa-heart-o"></i><span
                                                    class="tooltipp">add to wishlist</span></button> 
                                                    </div>
                                        <img src="{{ asset('front//img/product07.png') }}" alt="">
                                        <div class="product-label">
                                            <span class="new">{{trans('home/body.new')}}</span>
                                        </div>
                                    </div>
                                    <div class="product-body">
                                        <p class="product-category">Category</p>
                                        <h3 class="product-name"><a href="#">product name goes here</a></h3>
                                        <h4 class="product-price">$980.00 <del
                                                class="product-old-price">$990.00</del></h4>
                                        <div class="product-rating">
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star-o"></i>
                                        </div>
                                         <div class="product-btns">
                                            <!--<button class="add-to-wishlist"><i class="fa fa-heart-o"></i><span-->
                                            <!--        class="tooltipp">add to wishlist</span></button>-->
                                            <button class="add-to-compare"><i class="fa fa-exchange"></i><span
                                                    class="tooltipp">add to compare</span></button> 
                                            <button type="button"
                                                style="background-color: #642221; width:auto;  text-transform: uppercase; font-weight: 700;border-radius: 40px;text-transform: uppercase;font-size:13px;padding:0px 25px 5px 25px;"
                                                class="btn btn-danger"> {{trans('home/body.addtocart')}}</button>

                                            <button class="quick-view"><i class="fa fa-eye"></i><span
                                                    class="tooltipp">quick view</span></button>
                                        </div>
                                    </div>
                                    <!--<div class="add-to-cart">-->
                                    <!--    <button class="add-to-cart-btn"><i class="fa fa-shopping-cart"></i> add to-->
                                    <!--        cart</button>-->
                                    <!--</div>-->
                                </div>
                                <!-- /product -->

                                <!-- product -->
                                <div class="product">
                                    <div class="product-img">
                                         <div class="product-btns">
                                            <button class="add-to-wishlist"><i class="fa fa-heart-o"></i><span
                                                    class="tooltipp">add to wishlist</span></button>
                                                    </div>
                                        <img src="{{ asset('front//img/product08.png') }}" alt="">
                                        <div class="product-label">
                                            <span class="sale">-30%</span>
                                        </div>
                                    </div>
                                    <div class="product-body">
                                        <p class="product-category">Category</p>
                                        <h3 class="product-name"><a href="#">product name goes here</a></h3>
                                        <h4 class="product-price">$980.00 <del
                                                class="product-old-price">$990.00</del></h4>
                                        <div class="product-rating">
                                        </div>
                                       <div class="product-btns">
                                            <!--<button class="add-to-wishlist"><i class="fa fa-heart-o"></i><span-->
                                            <!--        class="tooltipp">add to wishlist</span></button>-->
                                            <button class="add-to-compare"><i class="fa fa-exchange"></i><span
                                                    class="tooltipp">add to compare</span></button> 
                                            <button type="button"
                                                style="background-color: #642221; width:auto;  text-transform: uppercase; font-weight: 700;border-radius: 40px;text-transform: uppercase;font-size:13px;padding:0px 25px 5px 25px;"
                                                class="btn btn-danger"> {{trans('home/body.addtocart')}}</button>

                                            <button class="quick-view"><i class="fa fa-eye"></i><span
                                                    class="tooltipp">quick view</span></button>
                                        </div>
                                    </div>
                                    <!--<div class="add-to-cart">-->
                                    <!--    <button class="add-to-cart-btn"><i class="fa fa-shopping-cart"></i> add to-->
                                    <!--        cart</button>-->
                                    <!--</div>-->
                                </div>
                                <!-- /product -->

                                <!-- product -->
                                <div class="product">
                                    <div class="product-img">
                                         <div class="product-btns">
                                            <button class="add-to-wishlist"><i class="fa fa-heart-o"></i><span
                                                    class="tooltipp">add to wishlist</span></button> 
                                                    </div>
                                        <img src="{{ asset('front//img/product09.png') }}" alt="">
                                    </div>
                                    <div class="product-body">
                                        <p class="product-category">Category</p>
                                        <h3 class="product-name"><a href="#">product name goes here</a></h3>
                                        <h4 class="product-price">$980.00 <del
                                                class="product-old-price">$990.00</del></h4>
                                        <div class="product-rating">
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                        </div>
                                         <div class="product-btns">
                                            <!--<button class="add-to-wishlist"><i class="fa fa-heart-o"></i><span-->
                                            <!--        class="tooltipp">add to wishlist</span></button>-->
                                            <button class="add-to-compare"><i class="fa fa-exchange"></i><span
                                                    class="tooltipp">add to compare</span></button> 
                                            <button type="button"
                                                style="background-color: #642221; width:auto;  text-transform: uppercase; font-weight: 700;border-radius: 40px;text-transform: uppercase;font-size:13px;padding:0px 25px 5px 25px;"
                                                class="btn btn-danger"> {{trans('home/body.addtocart')}} </button>

                                            <button class="quick-view"><i class="fa fa-eye"></i><span
                                                    class="tooltipp">quick view</span></button>
                                        </div>
                                    </div>
                                    <!--<div class="add-to-cart">-->
                                    <!--    <button class="add-to-cart-btn"><i class="fa fa-shopping-cart"></i> add to-->
                                    <!--        cart</button>-->
                                    <!--</div>-->
                                </div>
                                <!-- /product -->

                                <!-- product -->
                                <div class="product">
                                    <div class="product-img">
                                         <div class="product-btns">
                                                <button class="add-to-wishlist"><i class="fa fa-heart-o"></i><span
                                                    class="tooltipp">add to wishlist</span></button> 
                                            </div>
                                        <img src="{{ asset('front//img/product01.png') }}" alt="">
                                    </div>
                                    <div class="product-body">
                                       
                                        <p class="product-category">Category</p>
                                        <h3 class="product-name"><a href="#">product name goes here</a></h3>
                                        <h4 class="product-price">$980.00 <del
                                                class="product-old-price">$990.00</del></h4>
                                        <div class="product-rating">
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                        </div>
                                       <div class="product-btns">
                                            <!--<button class="add-to-wishlist"><i class="fa fa-heart-o"></i><span-->
                                            <!--        class="tooltipp">add to wishlist</span></button>-->
                                            <button class="add-to-compare"><i class="fa fa-exchange"></i><span
                                                    class="tooltipp">add to compare</span></button> 
                                            <button type="button"
                                                style="background-color: #642221; width:auto;  text-transform: uppercase; font-weight: 700;border-radius: 40px;text-transform: uppercase;font-size:13px;padding:0px 25px 5px 25px;"
                                                class="btn btn-danger"> {{trans('home/body.addtocart')}}</button>

                                            <button class="quick-view"><i class="fa fa-eye"></i><span
                                                    class="tooltipp">quick view</span></button>
                                        </div>
                                    </div>
                                    <!--<div class="add-to-cart">-->
                                    <!--    <button class="add-to-cart-btn"><i class="fa fa-shopping-cart"></i> add to-->
                                    <!--        cart</button>-->
                                    <!--</div>-->
                                </div>
                                <!-- /product -->
                            </div>
                            <div id="slick-nav-2" class="products-slick-nav"></div>
                        </div>
                        <!-- /tab -->
                    </div>
                </div>
            </div>
            <!-- /Products tab & slick -->
        </div>
        <!-- /row -->
    </div>
    <!-- /container -->
</div>
<div class="product_section layout_padding">
        <div class="container">
            <h1 class="feature_taital">{{trans('home/body.PopularCategories')}}</h1>
            {{-- <p class="feature_text">It is a long established fact that a reader will be distracted by the readable
                content of a page when looking</p> --}}
            <div class="product_section_2">
                <div class="row">
                    <div class="col-sm-3">
                        <div class="feature_box">
                              <h1 class="readable_text">{{trans('home/body.surveillancecameras')}}</h1>
                               <div><img src="{{ asset('front//img/camera.png') }}" class="image_7"></div>
                            
                        </div>
                        <div class="feature_box_1">
                            <h1 class="readable_text">{{trans('home/body.projector')}}</h1>
                            <div><img src="{{ asset('front//img/projector.png') }}" class="image_7"></div>
                        </div>

                    </div>
                    <div class="col-sm-3">
                        <div class="feature_box">
                            <h1 class="readable_text">{{trans('home/body.printer')}}</h1>
                            <div><img src="{{ asset('front//img/printer.png') }}" class="image_7"></div>
                        </div>
                        <div class="feature_box_1">
                            <h1 class="readable_text">{{trans('home/body.labtop')}}</h1>
                            <div><img src="{{ asset('front//img/laptop.png') }}" class="image_7"></div>
                        </div>

                    </div>
                    <div class="col-sm-6">
                        <div class="feature_box_2">
                             <h1 class="readable_text">{{trans('home/body.computeraccessories')}}</h1>
                            <div><img src="{{ asset('front//img/computer-accessories.png') }}" class="image_8"></div>
                            <!--<div class="seemore_bt"><a href="#">see More</a></div>-->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
