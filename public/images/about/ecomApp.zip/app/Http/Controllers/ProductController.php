<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;
use App\Models\Category;
use App\Models\Brand;
use App\Models\DisplayType;
use App\Models\ConnectivityTechnology;
use App\Models\NativeResolution;
use App\Models\IncludeComponents;
use App\Models\DisplayResolution;
use App\Models\ScreenSize;
use App\Models\MonitorFeatures;
use App\Models\LaptopScreenSizes;
use App\Models\WaterResistanceLevel;
use App\Models\OperatingSystems;
use App\Models\ProductLength;
use App\Models\CpuType;
use App\Models\HardType;
use App\Models\GraphicsCoprocessor;
use App\Models\DedicatedGraphicsMemory;
use App\Models\InstalledRAM;
use App\Models\HardCapacity;
use App\Models\NightVisionRange;
use App\Models\CameraUsage;
use Illuminate\Support\Str;

class ProductController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $products = Product::getAllProduct();
        // dd($products->links()->elements) ;
        return view('backend.product.index')->with('products', $products);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $brand = Brand::get();
        $category = Category::where('is_parent', 1)->get();
        $displayTypes = DisplayType::all();
        $connectivityTechnologies = ConnectivityTechnology::all();
        $nativeResolutions = NativeResolution::all();
        $includeComponents = IncludeComponents::all();
        $displayResolutions = DisplayResolution::all();
        $screenSizes = ScreenSize::all();
        $monitorFeatures = MonitorFeatures::all();
        $productLengths = ProductLength::all();
        $laptopScreenSizes = LaptopScreenSizes::all();
        $waterResistanceLevels = WaterResistanceLevel::all();
        $operatingSystems = OperatingSystems::all();
        $cpuTypes = CpuType::all();
        $hardTypes = HardType::all();
        $graphicsCoprocessors = GraphicsCoprocessor::all();
        $dedicatedGraphicsMemories = DedicatedGraphicsMemory::all();
        $installedRAMs = InstalledRAM::all();
        $hardCapacities = HardCapacity::all();
        $usages = CameraUsage::all();
        $nightVisionRanges = NightVisionRange::all();
        // return $category;
         return view('backend.product.create')->with('categories', $category)->with('brands', $brand)
                                             ->with('displayTypes',$displayTypes)->with('connectivityTechnologies', $connectivityTechnologies)
                                             ->with('nativeResolutions',$nativeResolutions)
                                             ->with('includeComponents',$includeComponents)
                                             ->with('displayResolutions',$displayResolutions)
                                             ->with('screenSizes',$screenSizes)
                                             ->with('monitorFeatures',$monitorFeatures)
                                             ->with('productLengths',$productLengths)
                                             ->with('productLengths',$productLengths)                                             
                                             ->with('operatingSystems',$operatingSystems)
                                             ->with('cpuTypes',$cpuTypes)
                                             ->with('hardTypes',$hardTypes)
                                             ->with('graphicsCoprocessors',$graphicsCoprocessors)                                             
                                             ->with('installedRAMs',$installedRAMs)
                                             ->with('hardCapacities',$hardCapacities)
                                             ->with('laptopScreenSizes',$laptopScreenSizes)
                                             ->with('waterResistanceLevels',$waterResistanceLevels)
                                             ->with('dedicatedGraphicsMemories',$dedicatedGraphicsMemories)
                                             ->with('usages',$usages)
                                             ->with('nightVisionRanges',$nightVisionRanges);
    }


    public function store(Request $request)
    {
        
        $this->validate($request, [
            'title' => 'string|required',
            'title_ar' => 'string|required',
            'summary' => 'string|required',
            'summary_ar' => 'string|required',
            'photo' => 'required|image|mimes:jpeg,png,jpg,gif,webp,svg|max:2048',
            'stock' => "required|numeric",
            'cat_id' => 'required|exists:categories,id',
            'condition' => 'required|in:default,new,Special',
            'price' => 'required|numeric',
            'discount' => 'nullable|numeric'
        ]);

 


        $data = $request->all();
        $slug = Str::slug($request->title);
        $count = Product::where('slug', $slug)->count();
        if ($count > 0) {
            $slug = $slug . '-' . date('ymdis') . '-' . rand(0, 999);
        }
        $data['slug'] = $slug;
        $data['is_featured'] = $request->input('is_featured', 0);


        $logoImage = $request->file('photo');
        $name = 'images/Product/'.$logoImage->getClientOriginalName();
        $request->photo->move(public_path('images/Product'), $name);


        $size = $request->input('size');
        if ($size) {
            $data['size'] = implode(',', $size);
        } else {
            $data['size'] = '';
        }
        // return $size;
        // return $data;
        $status = Product::create([
            'title' => $request->title,
            'title_ar' => $request->title_ar,
            'summary' => $request->summary,
            'summary_ar' => $request->summary_ar,
            'photo' => $name,
            'description' => $request->description,
            'stock' => $request->stock,
            'cat_id' => $request->cat_id,
            'child_cat_id'=>$request->child_cat_id,
            'child_child_cat_id'=>$request->child_child_cat_id,
            'brand_id' => $request->brand_id,
            'is_featured' => $request->is_featured,
            'status' => $request->status,
            'condition' => $request->condition,
            'price' => $request->price,
            'discount' => $request->discount,
            'slug' => $slug,
            'brand_id' => $request->brand_id,
            'os_id'=>$request->os_id,
            'cpu_type_id'=>$request->cpu_type_id,
            'graphics_corprocessor_id'=>$request->graphics_corprocessor_id,
            'installed_ram_id'=>$request->installed_ram_id,
            'hard_type_id'=>$request->hard_type_id,
            'display_type_id'=>$request->display_type_id,
            'dedicated_graphics_memory_id'=>$request->dedicated_graphics_memory_id,
            'native_resolution_id'=>$request->native_resolution_id,
            'conn_tech_id'=>$request->conn_tech_id,
            'inc_comp_id'=>$request->inc_comp_id,
            'display_res_id'=>$request->display_res_id,
            'screen_size_id'=>$request->screen_size_id,
            'monitor_feature_id'=>$request->monitor_feature_id,
            'product_length_id'=>$request->product_length_id,
            'usage_id'=>$request->usage_id,
            'night_vision_range_id'=>$request->night_vision_range_id,
            'wa_res_level_id'=>$request->wa_res_level_id,
        ]);

        if ($status) {
            request()->session()->flash('success', 'Product Successfully added');
        } else {
            request()->session()->flash('error', 'Please try again!!');
        }
        return redirect()->route('product.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $brand = Brand::get();
        $product = Product::findOrFail($id);
        $category = Category::where('is_parent', 1)->get();
        $items = Product::where('id', $id)->get();
        // return $items;
        return view('backend.product.edit')->with('product', $product)
            ->with('brands', $brand)
            ->with('categories', $category)->with('items', $items);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $product = Product::findOrFail($id);
        $this->validate($request, [
            'title' => 'string|required',
            'title_ar' => 'string|required',
            'summary' => 'string|required',
            'summary_ar' => 'string|required',
            'description' => 'string|nullable',
            'photo' => 'required',
            'size' => 'nullable',
            'stock' => "required|numeric",
            'cat_id' => 'required|exists:categories,id',
            'child_cat_id' => 'nullable|exists:categories,id',
            'is_featured' => 'nullable|sometimes|in:1',
            'brand_id' => 'nullable|exists:brands,id',
            'status' => 'required|in:active,inactive',
            'condition' => 'nullable|in:default,new,hot',
            'price' => 'required|numeric',
            'discount' => 'nullable|numeric'
        ]);

        $slug = Str::slug($request->title);

        if ($request->photo != null) {
            $logoImage = $request->file('photo');
            $name = 'images/Product/'.$logoImage->getClientOriginalName();
            $request->photo->move(public_path('images/Product'), $name);
            $product->update([
                'title' => $request->title,
                'title_ar' => $request->title_ar,
                'summary' => $request->summary,
                'summary_ar' => $request->summary_ar,
                'photo' => $name,
                'description' => $request->description,
                'stock' => $request->stock,
                'cat_id' => $request->cat_id,
                'brand_id' => $request->brand_id,
                'child_cat_id' => $request->child_cat_id,
                'is_featured' => $request->is_featured,
                'status' => $request->status,
                'condition' => $request->condition,
                'price' => $request->price,
                'discount' => $request->discount,
                'slug' => $slug,
                'brand_id' => $request->brand_id,
            ]);
        } else
            $product->update([
                'title' => $request->title,
                'title_ar' => $request->title_ar,
                'summary' => $request->summary,
                 'summary_ar' => $request->summary_ar,
                'description' => $request->description,
                'stock' => $request->stock,
                'cat_id' => $request->cat_id,
                'brand_id' => $request->brand_id,
                'child_cat_id' => $request->child_cat_id,
                'is_featured' => $request->is_featured,
                'status' => $request->status,
                'condition' => $request->condition,
                'price' => $request->price,
                'discount' => $request->discount,
                'slug' => $slug,
                'brand_id' => $request->brand_id,
            ]);


        $data = $request->all();
        $data['is_featured'] = $request->input('is_featured', 0);
        $size = $request->input('size');
        if ($size) {
            $data['size'] = implode(',', $size);
        } else {
            $data['size'] = '';
        }
        // return $data;
        // $status = $product->fill($data)->save();
        if ($product) {
            request()->session()->flash('success', 'Product Successfully updated');
        } else {
            request()->session()->flash('error', 'Please try again!!');
        }
        return redirect()->route('product.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $product = Product::findOrFail($id);
        $status = $product->delete();

        if ($status) {
            request()->session()->flash('success', 'Product successfully deleted');
        } else {
            request()->session()->flash('error', 'Error while deleting product');
        }
        return redirect()->route('product.index');
    }
}
