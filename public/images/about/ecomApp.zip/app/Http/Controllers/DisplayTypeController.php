<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\DisplayType;
use Illuminate\Support\Str;

class DisplayTypeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $displayTypes=DisplayType::orderBy('id','DESC')->paginate();
        return view('backend.display-type.index')->with('displayTypes',$displayTypes);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('backend.display-type.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request,[
            'title'=>'string|required',
            'title_ar'=>'string|required',
        ]);
        $data=$request->all();
        $slug=Str::slug($request->title);
        $count=DisplayType::where('slug',$slug)->count();
        if($count>0){
            $slug=$slug.'-'.date('ymdis').'-'.rand(0,999);
        }
        $data['slug']=$slug;
        // return $data;
        $status=DisplayType::create($data);
        if($status){
            request()->session()->flash('success','display Type successfully created');
        }
        else{
            request()->session()->flash('error','Error, Please try again');
        }
        return redirect()->route('display-type.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $displayType=DisplayType::find($id);
        if(!$displayType){
            request()->session()->flash('error','display Type not found');
        }
        return view('backend.display-type.edit')->with('displayType',$displayType);
    }


    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $displayType=DisplayType::find($id);
        $this->validate($request,[
            'title'=>'string|required',
            'title_ar'=>'string|required',
        ]);
        $data=$request->all();
       
        $status=$displayType->fill($data)->save();
        if($status){
            request()->session()->flash('success','display Type successfully updated');
        }
        else{
            request()->session()->flash('error','Error, Please try again');
        }
        return redirect()->route('display-type.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $displayType=DisplayType::find($id);
        if($cpuType){
            $status=$displayType->delete();
            if($status){
                request()->session()->flash('success','display Type successfully deleted');
            }
            else{
                request()->session()->flash('error','Error, Please try again');
            }
            return redirect()->route('display-type.index');
        }
        else{
            request()->session()->flash('error','display Type not found');
            return redirect()->back();
        }
    }
}
