<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\InstalledRAM;
use Illuminate\Support\Str;

class InstalledRAMController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $installedRAMs=InstalledRAM::orderBy('id','DESC')->paginate();
        return view('backend.installed-rams.index')->with('installedRAMs',$installedRAMs);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('backend.installed-rams.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request,[
            'title'=>'string|required',
            'title_ar'=>'string|required',
        ]);
        $data=$request->all();
        $slug=Str::slug($request->title);
        $count=InstalledRAM::where('slug',$slug)->count();
        if($count>0){
            $slug=$slug.'-'.date('ymdis').'-'.rand(0,999);
        }
        $data['slug']=$slug;
        // return $data;
        $status=InstalledRAM::create($data);
        if($status){
            request()->session()->flash('success','Installed RAM successfully created');
        }
        else{
            request()->session()->flash('error','Error, Please try again');
        }
        return redirect()->route('installed-ram.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $installedRAM=InstalledRAM::find($id);
        if(!$installedRAM){
            request()->session()->flash('error','Installed RAM not found');
        }
        return view('backend.installed-rams.edit')->with('installedRAM',$installedRAM);
    }


    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $installedRAM=InstalledRAM::find($id);
        $this->validate($request,[
            'title'=>'string|required',
            'title_ar'=>'string|required',
        ]);
        $data=$request->all();
       
        $status=$installedRAM->fill($data)->save();
        if($status){
            request()->session()->flash('success','Installed RAM successfully updated');
        }
        else{
            request()->session()->flash('error','Error, Please try again');
        }
        return redirect()->route('installed-ram.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $installedRAM=InstalledRAM::find($id);
        if($installedRAM){
            $status=$installedRAM->delete();
            if($status){
                request()->session()->flash('success','Installed RAM successfully deleted');
            }
            else{
                request()->session()->flash('error','Error, Please try again');
            }
            return redirect()->route('installed-ram.index');
        }
        else{
            request()->session()->flash('error','Installed RAM not found');
            return redirect()->back();
        }
    }
}