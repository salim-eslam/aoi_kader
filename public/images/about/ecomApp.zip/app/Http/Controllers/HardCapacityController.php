<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\HardCapacity;
use Illuminate\Support\Str;

class HardCapacityController extends Controller
{
     /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $hardCapacities=HardCapacity::orderBy('id','DESC')->paginate();
        return view('backend.hard-capacity.index')->with('hardCapacities',$hardCapacities);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('backend.hard-capacity.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request,[
            'title'=>'string|required',
            'title_ar'=>'string|required',
        ]);
        $data=$request->all();
        $slug=Str::slug($request->title);
        $count=HardCapacity::where('slug',$slug)->count();
        if($count>0){
            $slug=$slug.'-'.date('ymdis').'-'.rand(0,999);
        }
        $data['slug']=$slug;
        // return $data;
        $status=HardCapacity::create($data);
        if($status){
            request()->session()->flash('success','Hard Capacity successfully created');
        }
        else{
            request()->session()->flash('error','Error, Please try again');
        }
        return redirect()->route('hard-capacity.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $hardCapacity=HardCapacity::find($id);
        if(!$hardCapacity){
            request()->session()->flash('error','Hard Capacity not found');
        }
        return view('backend.hard-capacity.edit')->with('hardCapacity',$hardCapacity);
    }


    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $hardCapacity=HardCapacity::find($id);
        $this->validate($request,[
            'title'=>'string|required',
            'title_ar'=>'string|required',
        ]);
        $data=$request->all();
       
        $status=$hardCapacity->fill($data)->save();
        if($status){
            request()->session()->flash('success','Hard Capacity successfully updated');
        }
        else{
            request()->session()->flash('error','Error, Please try again');
        }
        return redirect()->route('hard-capacity.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $hardCapacity=HardCapacity::find($id);
        if($hardCapacity){
            $status=$hardCapacity->delete();
            if($status){
                request()->session()->flash('success','Hard Capacity successfully deleted');
            }
            else{
                request()->session()->flash('error','Error, Please try again');
            }
            return redirect()->route('hard-capacity.index');
        }
        else{
            request()->session()->flash('error','Hard Capacity not found');
            return redirect()->back();
        }
    }
}
