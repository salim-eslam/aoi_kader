<?php

namespace App\Http\Controllers;
use App\Models\Banner;
use App\Models\Product;
use App\Models\Category;
use App\Models\PostTag;
use App\Models\PostCategory;
use App\Models\Post;
use App\Models\Cart;
use App\Models\Brand;
use App\Models\HardType;
use App\Models\InstalledRAM;
use App\Models\CpuType;
use App\Models\OperatingSystems;
use App\Models\GraphicsCoprocessor;
use App\Models\DisplayType;
use App\Models\ConnectivityTechnology;
use App\Models\NativeResolution;
use App\Models\IncludeComponents;
use App\Models\DisplayResolution;
use App\Models\MonitorFeatures;
use App\Models\ProductLength;
use App\Models\HardCapacity;
use App\User;
use Auth;
use Session;
use Newsletter;
use DB;
use Hash;
use Illuminate\Support\Str;
use Illuminate\Http\Request;

class FrontendController extends Controller
{
   
    public function index(Request $request){
        return redirect()->route($request->user()->role);
    }

    public function home(){
        // $featured=Product::where('status','active')->where('is_featured',1)->orderBy('price','DESC')->limit(2)->get();
        // $posts=Post::where('status','active')->orderBy('id','DESC')->limit(3)->get();
        // $banners=Banner::where('status','active')->limit(3)->orderBy('id','DESC')->get();
     //   return $banner;
        // $products=Product::where('status','active')->orderBy('id','DESC')->get();
      //  dd($products);
        // $category=Category::where('status','active')->where('is_parent',1)->orderBy('title','ASC')->get();
        //return $category;
        // return view('frontend.index')
        //         ->with('featured',$featured)
        //         ->with('posts',$posts)
        //         ->with('banners',$banners)
        //         ->with('product_lists',$products)
        //         ->with('category_lists',$category);
        return view('front.pages.home');
    }   

    public function aboutUs(){
        return view('frontend.pages.about-us');
    }

    public function contact(){
        return view('frontend.pages.contact');
    }

    public function productDetail($slug){
        $product_detail= Product::getProductBySlug($slug);
        // dd($product_detail);
        return view('frontend.pages.product_detail')->with('product_detail',$product_detail);
    }
     public function products($cat_id){
        $query = DB::table('products');
        if(isset($cat_id)){
            $query->where('cat_id',$cat_id)->orwhere('child_cat_id',$cat_id)->orwhere('child_child_cat_id',$cat_id);            
        }
        $products = $query->where('status','active')->paginate(12);
        return view('front.pages.product-grids')->with('cat_id',$cat_id)->with('products',$products);
    }
    public function productGrids(Request $request){
        $cat_id = $request->id;
        $brand = $request->brands;
        $os = $request->os;
        $hardTypes = $request->hard_types;
        $installed_ram_ids = $request->ram_capcity;
        $cpu_type = $request->cpu_type;
        $graphic_coprocessor = $request->graphic_coprocessor;
        $display_type = $request->display_type;
        $conn_tech = $request->conn_tech;
        $natv_res = $request->natv_res;
        $inc_comp = $request->inc_comp;
        $display_res = $request->display_res;
        $monitor_feature = $request->monitor_feature;
        $price = $request->price;
        $product_length = $request->product_length;
        $hard_capacity = $request->hard_capacity_Ids;
      
        $query = DB::table('products');
        if(isset($cat_id)){
            $query->where(function($query)use($cat_id){
            $columns = ['cat_id', 'child_cat_id', 'child_child_cat_id'];
            foreach($columns as $column){
            $query->OrWhere($column,  '=', $cat_id);}});
        }
        if(isset($brand)){
                    $slugs= explode(',',$brand);
                    $brand_ids=Brand::select('id')->whereIn('slug',$slugs)->pluck('id')->toArray();
                    $query->whereIn('brand_id',$brand_ids);
                }
                if(isset($os)){
                    $slugs= explode(',',$os);
                    $os_ids=OperatingSystems::select('id')->whereIn('slug',$slugs)->pluck('id')->toArray();
                    $query->whereIn('os_id',$os_ids);
                } 
                if(isset($hardTypes)){
                    $slugs= explode(',',$hardTypes);
                    $hard_types_ids=HardType::select('id')->whereIn('slug',$slugs)->pluck('id')->toArray();
                    $query->whereIn('hard_type_id',$hard_types_ids); 
                } 
                if(isset($installed_ram_ids)){
                    $slugs= explode(',',$installed_ram_ids);
                    $installed_rams_ids=InstalledRAM::select('id')->whereIn('slug',$slugs)->pluck('id')->toArray();
                    $query->whereIn('installed_ram_id',$installed_rams_ids);   
                } 
                if(isset($cpu_type)){
                    $slugs= explode(',',$cpu_type);
                    $cpu_types_ids=CpuType::select('id')->whereIn('slug',$slugs)->pluck('id')->toArray();
                    $query->whereIn('cpu_type_id',$cpu_types_ids);   
                } 
                if(isset($graphic_coprocessor)){
                    $slugs= explode(',',$graphic_coprocessor);
                    $graphic_coprocessor_ids=GraphicsCoprocessor::select('id')->whereIn('slug',$slugs)->pluck('id')->toArray();
                    $query->whereIn('graphics_corprocessor_id',$graphic_coprocessor_ids);    
                } 
                if(isset($display_type)){
                    $slugs= explode(',',$display_type);
                    $display_types_ids=DisplayType::select('id')->whereIn('slug',$slugs)->pluck('id')->toArray();
                    $query->whereIn('display_type_id',$display_types_ids);   
                } 
                if(isset($conn_tech)){
                    $slugs= explode(',',$conn_tech);
                    $conn_techs_ids=ConnectivityTechnology::select('id')->whereIn('slug',$slugs)->pluck('id')->toArray();
                    $query->whereIn('conn_tech_id',$conn_techs_ids);   
                } 
                if(isset($natv_res)){
                    $slugs= explode(',',$natv_res);
                    $natv_res_ids=NativeResolution::select('id')->whereIn('slug',$slugs)->pluck('id')->toArray();
                    $query->whereIn('native_resolution_id',$natv_res_ids);   
                } 
                if(isset($inc_comp)){
                    $slugs= explode(',',$inc_comp);
                    $inc_comp_ids=IncludeComponents::select('id')->whereIn('slug',$slugs)->pluck('id')->toArray();
                    $query->whereIn('inc_comp_id',$inc_comp_ids);   
                } 
                if(isset($display_res)){
                    $slugs= explode(',',$display_res);
                    $display_res_ids=DisplayResolution::select('id')->whereIn('slug',$slugs)->pluck('id')->toArray();
                    $query->whereIn('display_res_id',$display_res_ids);   
                } 
                 if(isset($monitor_feature)){
                    $slugs= explode(',',$monitor_feature);
                    $monitor_features_ids=MonitorFeatures::select('id')->whereIn('slug',$slugs)->pluck('id')->toArray();
                    $query->whereIn('monitor_feature_id',$monitor_features_ids);   
                } 
                 if(isset($price)){
                    $query->whereBetween('price', [explode(',',$price)]);
                } 
                  if(isset($product_length)){
                    $slugs= explode(',',$product_length);
                    $product_lengths_ids=ProductLength::select('id')->whereIn('slug',$slugs)->pluck('id')->toArray();
                    $query->whereIn('product_length_id',$product_lengths_ids);   
                } 
                  if(isset($hard_capacity)){
                    $slugs= explode(',',$hard_capacity);
                    $hard_capacities_ids=HardCapacity::select('id')->whereIn('slug',$slugs)->pluck('id')->toArray();
                    $query->whereIn('hard_capacity_id',$hard_capacities_ids);   
                } 
          $products = $query->where('status','active')->paginate(12);        
          $brands_ids = Product::select('brand_id')
                         ->distinct()
                         ->where('cat_id',$cat_id)
                         ->get(); 
     
        return view('front.pages.products-ajax')->with('products',$products)->with('cat_id',$cat_id)->with('brands_ids', $brands_ids);
    }

    
    public function monitorsLists()
    {
        return view('front.pages.monitors');

    }
    public function projectorsLists()
    {
        return view('front.pages.projectors');        
    }
    public function routersLists()
    {
        return view('front.pages.projectors');        
    }
    public function adaptorsLists()
    {
        return view('front.pages.projectors');        
    }
    public function accessPointsLists()
    {
        return view('front.pages.projectors');        
    }
    public function switchesLists()
    {
        return view('front.pages.projectors');        
    }
    public function labTopBagsLists()
    {
        return view('front.pages.projectors');        
    }
   
    public function productLists($cat_id){
      //  $products=Product::query();
        $products=Product::where('cat_id',$cat_id)->where('status','active')->paginate(6);
        
        // if(!empty($_GET['category'])){
        //     $slug=explode(',',$_GET['category']);
        //     // dd($slug);
        //     $cat_ids=Category::select('id')->whereIn('slug',$slug)->pluck('id')->toArray();
        //     // dd($cat_ids);
        //     $products->whereIn('cat_id',$cat_ids)->paginate;
        //     // return $products;
        // }
        // if(!empty($_GET['brand'])){
        //     $slugs=explode(',',$_GET['brand']);
        //     $brand_ids=Brand::select('id')->whereIn('slug',$slugs)->pluck('id')->toArray();
        //     return $brand_ids;
        //     $products->whereIn('brand_id',$brand_ids);
        // }
        // if(!empty($_GET['sortBy'])){
        //     if($_GET['sortBy']=='title'){
        //         $products=$products->where('status','active')->orderBy('title','ASC');
        //     }
        //     if($_GET['sortBy']=='price'){
        //         $products=$products->orderBy('price','ASC');
        //     }
        // }

        // if(!empty($_GET['price'])){
        //     $price=explode('-',$_GET['price']);
        //     // return $price;
        //     // if(isset($price[0]) && is_numeric($price[0])) $price[0]=floor(Helper::base_amount($price[0]));
        //     // if(isset($price[1]) && is_numeric($price[1])) $price[1]=ceil(Helper::base_amount($price[1]));
            
        //     $products->whereBetween('price',$price);
        // }

        // $recent_products=Product::where('status','active')->orderBy('id','DESC')->limit(3)->get();
        // Sort by number
        // if(!empty($_GET['show'])){
        //     $products=$products->where('status','active')->paginate($_GET['show']);
        // }
        // else{
        //     $products=$products->where('status','active')->paginate(6);
        // }
        // Sort by name , price, category

      
        return view('front.pages.product-lists')->with('products',$products)->with('cat_id',$cat_id);
    }
    public function productFilter(Request $request){
            $data= $request->all();
            // return $data;
            $showURL="";
            if(!empty($data['show'])){
                $showURL .='&show='.$data['show'];
            }

            $sortByURL='';
            if(!empty($data['sortBy'])){
                $sortByURL .='&sortBy='.$data['sortBy'];
            }

            $catURL="";
            if(!empty($data['category'])){
                foreach($data['category'] as $category){
                    if(empty($catURL)){
                        $catURL .='&category='.$category;
                    }
                    else{
                        $catURL .=','.$category;
                    }
                }
            }

            $brandURL="";
            if(!empty($data['brand'])){
                foreach($data['brand'] as $brand){
                    if(empty($brandURL)){
                        $brandURL .='&brand='.$brand;
                    }
                    else{
                        $brandURL .=','.$brand;
                    }
                }
            }
            // return $brandURL;

            $priceRangeURL="";
            if(!empty($data['price_range'])){
                $priceRangeURL .='&price='.$data['price_range'];
            }
            if(request()->is('e-shop.loc/product-grids')){
                return redirect()->route('product-grids',$catURL.$brandURL.$priceRangeURL.$showURL.$sortByURL);
            }
            else{
                return redirect()->route('product-lists',$catURL.$brandURL.$priceRangeURL.$showURL.$sortByURL);
            }
    }
    public function productSearch(Request $request){
       
        $recent_products=Product::where('status','active')->orderBy('id','DESC')->limit(3)->get();
        $products=Product::orwhere('title','like','%'.$request->search.'%')
                    ->orwhere('slug','like','%'.$request->search.'%')
                    ->orwhere('description','like','%'.$request->search.'%')
                    ->orwhere('summary','like','%'.$request->search.'%')
                    ->orwhere('price','like','%'.$request->search.'%')
                    ->orderBy('id','DESC')
                    ->paginate('9');
                    //  dd($products);
        return view('frontend.pages.product-grids')->with('products',$products)->with('recent_products',$recent_products);
    }

    public function productBrand(Request $request){
        $products=Brand::getProductByBrand($request->slug);
        $recent_products=Product::where('status','active')->orderBy('id','DESC')->limit(3)->get();
        if(request()->is('e-shop.loc/product-grids')){
            return view('frontend.pages.product-grids')->with('products',$products->products)->with('recent_products',$recent_products);
        }
        else{
            return view('frontend.pages.product-lists')->with('products',$products->products)->with('recent_products',$recent_products);
        }

    }
    public function productCat(Request $request){
        $products=Category::getProductByCat($request->slug);
        $recent_products=Product::where('status','active')->orderBy('id','DESC')->limit(3)->get();

        if(request()->is('e-shop.loc/product-grids')){
            return view('frontend.pages.product-grids')->with('products',$products->products)->with('recent_products',$recent_products);
        }
        else{
            return view('frontend.pages.product-lists')->with('products',$products->products)->with('recent_products',$recent_products);
        }

    }
    public function productSubCat(Request $request){
        $products=Category::getProductBySubCat($request->sub_slug);
        // return $products;
        $recent_products=Product::where('status','active')->orderBy('id','DESC')->limit(3)->get();

        if(request()->is('e-shop.loc/product-grids')){
            return view('frontend.pages.product-grids')->with('products',$products->sub_products)->with('recent_products',$recent_products);
        }
        else{
            return view('frontend.pages.product-lists')->with('products',$products->sub_products)->with('recent_products',$recent_products);
        }

    }

    public function blog(){
        $post=Post::query();
        
        if(!empty($_GET['category'])){
            $slug=explode(',',$_GET['category']);
            // dd($slug);
            $cat_ids=PostCategory::select('id')->whereIn('slug',$slug)->pluck('id')->toArray();
            return $cat_ids;
            $post->whereIn('post_cat_id',$cat_ids);
            // return $post;
        }
        if(!empty($_GET['tag'])){
            $slug=explode(',',$_GET['tag']);
            // dd($slug);
            $tag_ids=PostTag::select('id')->whereIn('slug',$slug)->pluck('id')->toArray();
            // return $tag_ids;
            $post->where('post_tag_id',$tag_ids);
            // return $post;
        }

        if(!empty($_GET['show'])){
            $post=$post->where('status','active')->orderBy('id','DESC')->paginate($_GET['show']);
        }
        else{
            $post=$post->where('status','active')->orderBy('id','DESC')->paginate(9);
        }
        // $post=Post::where('status','active')->paginate(8);
        $rcnt_post=Post::where('status','active')->orderBy('id','DESC')->limit(3)->get();
        return view('frontend.pages.blog')->with('posts',$post)->with('recent_posts',$rcnt_post);
    }

    public function blogDetail($slug){
        $post=Post::getPostBySlug($slug);
        $rcnt_post=Post::where('status','active')->orderBy('id','DESC')->limit(3)->get();
        // return $post;
        return view('frontend.pages.blog-detail')->with('post',$post)->with('recent_posts',$rcnt_post);
    }

    public function blogSearch(Request $request){
        // return $request->all();
        $rcnt_post=Post::where('status','active')->orderBy('id','DESC')->limit(3)->get();
        $posts=Post::orwhere('title','like','%'.$request->search.'%')
            ->orwhere('quote','like','%'.$request->search.'%')
            ->orwhere('summary','like','%'.$request->search.'%')
            ->orwhere('description','like','%'.$request->search.'%')
            ->orwhere('slug','like','%'.$request->search.'%')
            ->orderBy('id','DESC')
            ->paginate(8);
        return view('frontend.pages.blog')->with('posts',$posts)->with('recent_posts',$rcnt_post);
    }

    public function blogFilter(Request $request){
        $data=$request->all();
        // return $data;
        $catURL="";
        if(!empty($data['category'])){
            foreach($data['category'] as $category){
                if(empty($catURL)){
                    $catURL .='&category='.$category;
                }
                else{
                    $catURL .=','.$category;
                }
            }
        }

        $tagURL="";
        if(!empty($data['tag'])){
            foreach($data['tag'] as $tag){
                if(empty($tagURL)){
                    $tagURL .='&tag='.$tag;
                }
                else{
                    $tagURL .=','.$tag;
                }
            }
        }
        // return $tagURL;
            // return $catURL;
        return redirect()->route('blog',$catURL.$tagURL);
    }

    public function blogByCategory(Request $request){
        $post=PostCategory::getBlogByCategory($request->slug);
        $rcnt_post=Post::where('status','active')->orderBy('id','DESC')->limit(3)->get();
        return view('frontend.pages.blog')->with('posts',$post->post)->with('recent_posts',$rcnt_post);
    }

    public function blogByTag(Request $request){
        // dd($request->slug);
        $post=Post::getBlogByTag($request->slug);
        // return $post;
        $rcnt_post=Post::where('status','active')->orderBy('id','DESC')->limit(3)->get();
        return view('frontend.pages.blog')->with('posts',$post)->with('recent_posts',$rcnt_post);
    }

    // Login
    public function login(){
        return view('frontend.pages.login');
    }
    public function loginSubmit(Request $request){
        $data= $request->all();
        if(Auth::attempt(['email' => $data['email'], 'password' => $data['password'],'status'=>'active'])){
            Session::put('user',$data['email']);
            request()->session()->flash('success','Successfully login');
            return redirect()->route('home');
        }
        else{
            request()->session()->flash('error','Invalid email and password pleas try again!');
            return redirect()->back();
        }
    }

    public function logout(){
        Session::forget('user');
        Auth::logout();
        request()->session()->flash('success','Logout successfully');
        return back();
    }

    public function register(){
        return view('frontend.pages.register');
    }
    public function registerSubmit(Request $request){
        // return $request->all();
        $this->validate($request,[
            'name'=>'string|required|min:2',
            'email'=>'string|required|unique:users,email',
            'password'=>'required|min:6|confirmed',
        ]);
        $data=$request->all();
        // dd($data);
        $check=$this->create($data);
        Session::put('user',$data['email']);
        if($check){
            request()->session()->flash('success','Successfully registered');
            return redirect()->route('home');
        }
        else{
            request()->session()->flash('error','Please try again!');
            return back();
        }
    }
    public function create(array $data){
        return User::create([
            'name'=>$data['name'],
            'email'=>$data['email'],
            'password'=>Hash::make($data['password']),
            'status'=>'active'
            ]);
    }
    // Reset password
    public function showResetForm(){
        return view('auth.passwords.old-reset');
    }

    public function subscribe(Request $request){
        if(! Newsletter::isSubscribed($request->email)){
                Newsletter::subscribePending($request->email);
                if(Newsletter::lastActionSucceeded()){
                    request()->session()->flash('success','Subscribed! Please check your email');
                    return redirect()->route('home');
                }
                else{
                    Newsletter::getLastError();
                    return back()->with('error','Something went wrong! please try again');
                }
            }
            else{
                request()->session()->flash('error','Already Subscribed');
                return back();
            }
    }
    
}
