<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\DisplayResolution;
use Illuminate\Support\Str;

class DisplayResolutionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $displayResolutions=DisplayResolution::orderBy('id','DESC')->paginate();
        return view('backend.display-resolution.index')->with('displayResolutions',$displayResolutions);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('backend.display-resolution.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request,[
            'title'=>'string|required',
            'title_ar'=>'string|required',
        ]);
        $data=$request->all();
        $slug=Str::slug($request->title);
        $count=DisplayResolution::where('slug',$slug)->count();
        if($count>0){
            $slug=$slug.'-'.date('ymdis').'-'.rand(0,999);
        }
        $data['slug']=$slug;
        // return $data;
        $status=DisplayResolution::create($data);
        if($status){
            request()->session()->flash('success','display resolution successfully created');
        }
        else{
            request()->session()->flash('error','Error, Please try again');
        }
        return redirect()->route('display-res.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $displayResolution=DisplayResolution::find($id);
        if(!$displayResolution){
            request()->session()->flash('error','display resolution not found');
        }
        return view('backend.display-resolution.edit')->with('displayResolution',$displayResolution);
    }


    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $displayResolution=DisplayResolution::find($id);
        $this->validate($request,[
            'title'=>'string|required',
            'title_ar'=>'string|required',
        ]);
        $data=$request->all();
       
        $status=$displayResolution->fill($data)->save();
        if($status){
            request()->session()->flash('success','display resolution successfully updated');
        }
        else{
            request()->session()->flash('error','Error, Please try again');
        }
        return redirect()->route('display-res.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $displayResolution=DisplayResolution::find($id);
        if($displayResolution){
            $status=$displayResolution->delete();
            if($status){
                request()->session()->flash('success','display resolution successfully deleted');
            }
            else{
                request()->session()->flash('error','Error, Please try again');
            }
            return redirect()->route('display-res.index');
        }
        else{
            request()->session()->flash('error','display resolution not found');
            return redirect()->back();
        }
    }
}
