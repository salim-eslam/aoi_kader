<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\ScreenSize;
use Illuminate\Support\Str;

class ScreenSizeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $screenSizes=ScreenSize::orderBy('id','DESC')->paginate();
        return view('backend.screen-size.index')->with('screenSizes',$screenSizes);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('backend.screen-size.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request,[
            'title'=>'string|required',
            'title_ar'=>'string|required',
        ]);
        $data=$request->all();
        $slug=Str::slug($request->title);
        $count=ScreenSize::where('slug',$slug)->count();
        if($count>0){
            $slug=$slug.'-'.date('ymdis').'-'.rand(0,999);
        }
        $data['slug']=$slug;
        // return $data;
        $status=ScreenSize::create($data);
        if($status){
            request()->session()->flash('success','screen size successfully created');
        }
        else{
            request()->session()->flash('error','Error, Please try again');
        }
        return redirect()->route('screen-size.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $screenSize=ScreenSize::find($id);
        if(!$screenSize){
            request()->session()->flash('error','screen size not found');
        }
        return view('backend.screen-size.edit')->with('screenSize',$screenSize);
    }


    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $screenSize=ScreenSize::find($id);
        $this->validate($request,[
            'title'=>'string|required',
            'title_ar'=>'string|required',
        ]);
        $data=$request->all();
       
        $status=$screenSize->fill($data)->save();
        if($status){
            request()->session()->flash('success','screen Size successfully updated');
        }
        else{
            request()->session()->flash('error','Error, Please try again');
        }
        return redirect()->route('screen-size.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $screenSize=ScreenSize::find($id);
        if($screenSize){
            $status=$screenSize->delete();
            if($status){
                request()->session()->flash('success','screen size successfully deleted');
            }
            else{
                request()->session()->flash('error','Error, Please try again');
            }
            return redirect()->route('screen-size.index');
        }
        else{
            request()->session()->flash('error','screen size not found');
            return redirect()->back();
        }
    }
}
