<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\IncludeComponents;
use Illuminate\Support\Str;

class IncludeComponentsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $includeComponents=IncludeComponents::orderBy('id','DESC')->paginate();
        return view('backend.include-components.index')->with('includeComponents',$includeComponents);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('backend.include-components.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request,[
            'title'=>'string|required',
            'title_ar'=>'string|required',
        ]);
        $data=$request->all();
        $slug=Str::slug($request->title);
        $count=IncludeComponents::where('slug',$slug)->count();
        if($count>0){
            $slug=$slug.'-'.date('ymdis').'-'.rand(0,999);
        }
        $data['slug']=$slug;
        // return $data;
        $status=IncludeComponents::create($data);
        if($status){
            request()->session()->flash('success','Cpu Type successfully created');
        }
        else{
            request()->session()->flash('error','Error, Please try again');
        }
        return redirect()->route('inc-comp.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $includeComponent=IncludeComponents::find($id);
        if(!$includeComponent){
            request()->session()->flash('error','include component not found');
        }
        return view('backend.include-components.edit')->with('includeComponent',$includeComponent);
    }


    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $includeComponent=IncludeComponents::find($id);
        $this->validate($request,[
            'title'=>'string|required',
            'title_ar'=>'string|required',
        ]);
        $data=$request->all();
       
        $status=$includeComponent->fill($data)->save();
        if($status){
            request()->session()->flash('success','include component successfully updated');
        }
        else{
            request()->session()->flash('error','Error, Please try again');
        }
        return redirect()->route('inc-comp.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $includeComponent=IncludeComponents::find($id);
        if($includeComponent){
            $status=$includeComponent->delete();
            if($status){
                request()->session()->flash('success','include component successfully deleted');
            }
            else{
                request()->session()->flash('error','Error, Please try again');
            }
            return redirect()->route('inc-comp.index');
        }
        else{
            request()->session()->flash('error','include component not found');
            return redirect()->back();
        }
    }
}
