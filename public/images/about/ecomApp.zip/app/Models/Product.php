<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Models\Cart;
class Product extends Model
{
    protected $fillable=['title','title_ar','slug','summary','summary_ar','description','cat_id','child_cat_id','child_child_cat_id','price','brand_id','discount','status','photo','size','stock','is_featured','condition','os_id','cpu_type_id',
    'graphics_corprocessor_id','installed_ram_id','hard_type_id','display_type_id','dedicated_graphics_memory_id','native_resolution_id','conn_tech_id','inc_comp_id','display_res_id','screen_size_id','monitor_feature_id','product_length_id'
    ,'usage_id','night_vision_range_id','wa_res_level_id'];

    public function cat_info(){
        return $this->hasOne('App\Models\Category','id','cat_id');
    }
    public function sub_cat_info(){
        return $this->hasOne('App\Models\Category','id','child_cat_id');
    }
    public static function getAllProduct(){
        return Product::with(['cat_info','sub_cat_info'])->orderBy('id','desc')->paginate(10);
    }
    public function rel_prods(){
        return $this->hasMany('App\Models\Product','cat_id','cat_id')->where('status','active')->orderBy('id','DESC')->limit(8);
    }
    public function getReview(){
        return $this->hasMany('App\Models\ProductReview','product_id','id')->with('user_info')->where('status','active')->orderBy('id','DESC');
    }
    public static function getProductBySlug($slug){
        return Product::with(['cat_info','rel_prods','getReview'])->where('slug',$slug)->first();
    }
    public static function countActiveProduct(){
        $data=Product::where('status','active')->count();
        if($data){
            return $data;
        }
        return 0;
    }

    public function carts(){
        return $this->hasMany(Cart::class)->whereNotNull('order_id');
    }

    public function wishlists(){
        return $this->hasMany(Wishlist::class)->whereNotNull('cart_id');
    }

    public function brand(){
        return $this->hasOne(Brand::class,'id','brand_id');
    }
     public function operatingSystem(){
        return $this->hasOne(OperatingSystems::class,'id','os_id');
    }
    public function cpuType(){
        return $this->hasOne(CpuType::class,'id','cpu_type_id');
    }
    public function graphicsCoprocessor(){
        return $this->hasOne(GraphicsCoprocessor::class,'id','graphics_corprocessor_id');
    }
    public function installedRAM(){
        return $this->hasOne(InstalledRAM::class,'id','installed_ram_id');
    }
    public function hardType(){
        return $this->hasOne(HardType::class,'id','hard_type_id');
    }
    public function dedicatedGraphicsMemory(){
        return $this->hasOne(DedicatedGraphicsMemory::class,'id','dedicated_graphics_memory_id');
    }
    public function hardCapacity(){
        return $this->hasOne(HardCapacity::class,'id','hard_capacity_id');
    }
    public function displayType(){
        return $this->hasOne(DisplayType::class,'id','display_type_id');
    }
    public function connectivityTechnology(){
        return $this->hasOne(ConnectivityTechnology::class,'id','conn_tech_id');
    }
    public function nativeResolution(){
        return $this->hasOne(NativeResolution::class,'id','natv_res_id'); 
    }
    public function includeComponents()
    {
        return $this->hasOne(IncludeComponents::class,'id','inc_comp_id'); 
    }
    public function displayResolution()
    {
        return $this->hasOne(DisplayResolution::class,'id','display_res_id'); 
    }
    public function screenSize()
    {
        return $this->hasOne(ScreenSize::class,'id','screen_size_id'); 
    }
    public function monitorFeatures()
    {
        return $this->hasOne(MonitorFeatures::class,'id','monitor_feature_id'); 
    }

}
